-- ============================================================
-- Savings Pockets Module
-- ============================================================

-- 1. Tables
CREATE TABLE IF NOT EXISTS public.savings_pockets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    emoji TEXT NOT NULL DEFAULT '🎯',
    target_amount NUMERIC(12, 2) NOT NULL DEFAULT 0,
    saved_amount NUMERIC(12, 2) NOT NULL DEFAULT 0,
    color BIGINT NOT NULL DEFAULT 4278255776,
    deadline TEXT NOT NULL DEFAULT 'No deadline',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.pocket_contributions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pocket_id UUID NOT NULL REFERENCES public.savings_pockets(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    amount NUMERIC(12, 2) NOT NULL,
    note TEXT NOT NULL DEFAULT 'Manual contribution',
    contributed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Indexes
CREATE INDEX IF NOT EXISTS idx_savings_pockets_user_id ON public.savings_pockets(user_id);
CREATE INDEX IF NOT EXISTS idx_pocket_contributions_pocket_id ON public.pocket_contributions(pocket_id);
CREATE INDEX IF NOT EXISTS idx_pocket_contributions_user_id ON public.pocket_contributions(user_id);

-- 3. Function to update saved_amount on pocket when contribution added/deleted
CREATE OR REPLACE FUNCTION public.update_pocket_saved_amount()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.savings_pockets
        SET saved_amount = saved_amount + NEW.amount,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = NEW.pocket_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.savings_pockets
        SET saved_amount = GREATEST(0, saved_amount - OLD.amount),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = OLD.pocket_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;

-- 4. Enable RLS
ALTER TABLE public.savings_pockets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pocket_contributions ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies
DROP POLICY IF EXISTS "users_manage_own_savings_pockets" ON public.savings_pockets;
CREATE POLICY "users_manage_own_savings_pockets"
ON public.savings_pockets
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "users_manage_own_pocket_contributions" ON public.pocket_contributions;
CREATE POLICY "users_manage_own_pocket_contributions"
ON public.pocket_contributions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 6. Triggers
DROP TRIGGER IF EXISTS on_contribution_change ON public.pocket_contributions;
CREATE TRIGGER on_contribution_change
    AFTER INSERT OR DELETE ON public.pocket_contributions
    FOR EACH ROW EXECUTE FUNCTION public.update_pocket_saved_amount();

-- 7. Mock Data
DO $$
DECLARE
    existing_user_id UUID;
    pocket1_id UUID := gen_random_uuid();
    pocket2_id UUID := gen_random_uuid();
    pocket3_id UUID := gen_random_uuid();
    pocket4_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'user_profiles'
    ) THEN
        SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;

        IF existing_user_id IS NOT NULL THEN
            INSERT INTO public.savings_pockets (id, user_id, name, emoji, target_amount, saved_amount, color, deadline)
            VALUES
                (pocket1_id, existing_user_id, 'New MacBook Pro', '💻', 4200.00, 2840.00, 7167696615, 'Dec 2026'),
                (pocket2_id, existing_user_id, 'Bali Vacation', '🌴', 8000.00, 3200.00, 4278255776, 'Mar 2027'),
                (pocket3_id, existing_user_id, 'Emergency Fund', '🛡️', 15000.00, 9500.00, 4284513803, 'Jun 2027'),
                (pocket4_id, existing_user_id, 'New Car', '🚗', 25000.00, 4750.00, 4283215696, 'Dec 2027')
            ON CONFLICT (id) DO NOTHING;

            INSERT INTO public.pocket_contributions (pocket_id, user_id, amount, note, contributed_at)
            VALUES
                (pocket1_id, existing_user_id, 500.00, 'Monthly contribution', now() - interval '1 day'),
                (pocket1_id, existing_user_id, 340.00, 'Bonus savings', now() - interval '7 days'),
                (pocket1_id, existing_user_id, 1000.00, 'Initial deposit', now() - interval '20 days'),
                (pocket1_id, existing_user_id, 1000.00, 'Starting goal', now() - interval '34 days'),
                (pocket2_id, existing_user_id, 800.00, 'Monthly savings', now() - interval '3 days'),
                (pocket2_id, existing_user_id, 1200.00, 'Tax refund', now() - interval '34 days'),
                (pocket2_id, existing_user_id, 1200.00, 'Initial deposit', now() - interval '65 days'),
                (pocket3_id, existing_user_id, 500.00, 'Regular contribution', now() - interval '1 day'),
                (pocket3_id, existing_user_id, 500.00, 'Regular contribution', now() - interval '32 days'),
                (pocket3_id, existing_user_id, 2000.00, 'Freelance income', now() - interval '50 days'),
                (pocket3_id, existing_user_id, 6500.00, 'Year-start goal', now() - interval '215 days'),
                (pocket4_id, existing_user_id, 750.00, 'Monthly savings', now() - interval '2 days'),
                (pocket4_id, existing_user_id, 4000.00, 'Initial deposit', now() - interval '25 days')
            ON CONFLICT (id) DO NOTHING;
        ELSE
            RAISE NOTICE 'No existing users found. Skipping mock data.';
        END IF;
    ELSE
        RAISE NOTICE 'Table user_profiles does not exist. Skipping mock data.';
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Mock data insertion failed: %', SQLERRM;
END $$;
