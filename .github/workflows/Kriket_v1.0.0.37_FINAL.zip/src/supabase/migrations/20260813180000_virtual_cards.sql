-- Virtual Cards table
-- Stores virtual debit card data per user.
-- Card numbers, CVV, expiry are stored as-is (in production these would come from a card issuer API).
-- This table is intentionally empty by default — no fake card data is inserted.
-- Cards are only created when a real card issuer integration provisions them.

CREATE TABLE IF NOT EXISTS public.virtual_cards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    card_number TEXT NOT NULL,
    card_holder_name TEXT NOT NULL,
    expiry_month TEXT NOT NULL,
    expiry_year TEXT NOT NULL,
    cvv TEXT NOT NULL,
    card_network TEXT NOT NULL DEFAULT 'VISA',
    is_frozen BOOLEAN NOT NULL DEFAULT false,
    card_label TEXT NOT NULL DEFAULT 'Virtual Card',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_virtual_cards_user_id ON public.virtual_cards(user_id);

-- Update trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_virtual_cards_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_virtual_cards_updated_at ON public.virtual_cards;
CREATE TRIGGER trg_virtual_cards_updated_at
    BEFORE UPDATE ON public.virtual_cards
    FOR EACH ROW
    EXECUTE FUNCTION public.update_virtual_cards_updated_at();

-- Enable RLS
ALTER TABLE public.virtual_cards ENABLE ROW LEVEL SECURITY;

-- RLS Policies: users can only access their own cards
DROP POLICY IF EXISTS "users_manage_own_virtual_cards" ON public.virtual_cards;
CREATE POLICY "users_manage_own_virtual_cards"
ON public.virtual_cards
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());
