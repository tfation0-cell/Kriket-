-- ============================================================
-- Kriket: Transactions Table Migration
-- ============================================================

-- 1. Create user_profiles table if it doesn't exist (needed for FK)
CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL DEFAULT '',
    avatar_url TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create transaction status enum
DROP TYPE IF EXISTS public.transaction_status CASCADE;
CREATE TYPE public.transaction_status AS ENUM ('completed', 'pending', 'failed');

-- 3. Create transactions table
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT '',
    transaction_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    amount NUMERIC(12, 2) NOT NULL,
    is_credit BOOLEAN NOT NULL DEFAULT false,
    status public.transaction_status NOT NULL DEFAULT 'completed',
    icon TEXT NOT NULL DEFAULT 'receipt_long_outlined',
    avatar_color BIGINT NOT NULL DEFAULT 4283215696,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Indexes
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON public.transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON public.transactions(transaction_date DESC);

-- 5. Trigger function to auto-create user_profiles on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, avatar_url)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', '')
    )
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
END;
$$;

-- 6. Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- 7. RLS Policies for user_profiles
DROP POLICY IF EXISTS "users_manage_own_user_profiles" ON public.user_profiles;
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- 8. RLS Policies for transactions
DROP POLICY IF EXISTS "users_manage_own_transactions" ON public.transactions;
CREATE POLICY "users_manage_own_transactions"
ON public.transactions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 9. Trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 10. Backfill user_profiles for any existing auth users
DO $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, avatar_url)
    SELECT
        au.id,
        au.email,
        COALESCE(au.raw_user_meta_data->>'full_name', split_part(au.email, '@', 1)),
        COALESCE(au.raw_user_meta_data->>'avatar_url', '')
    FROM auth.users au
    WHERE NOT EXISTS (
        SELECT 1 FROM public.user_profiles up WHERE up.id = au.id
    );
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Backfill skipped: %', SQLERRM;
END $$;

-- 11. Seed mock transactions for existing users
DO $$
DECLARE
    existing_user_id UUID;
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'user_profiles'
    ) THEN
        SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;

        IF existing_user_id IS NOT NULL THEN
            INSERT INTO public.transactions (id, user_id, name, category, transaction_date, amount, is_credit, status, icon, avatar_color)
            VALUES
                (gen_random_uuid(), existing_user_id, 'From Albert Flores', 'Transfer In',
                 NOW() - INTERVAL '0 days', 12600.00, true, 'completed', 'arrow_downward_rounded', 7131367143),
                (gen_random_uuid(), existing_user_id, 'To Jenny Wilson', 'Transfer Out',
                 NOW() - INTERVAL '1 day', 824.00, false, 'completed', 'arrow_upward_rounded', 570425331),
                (gen_random_uuid(), existing_user_id, 'Netflix Subscription', 'Entertainment',
                 NOW() - INTERVAL '2 days', 15.99, false, 'completed', 'play_circle_outline_rounded', 4283215636),
                (gen_random_uuid(), existing_user_id, 'Mailchimp Support', 'Business Tools',
                 NOW() - INTERVAL '3 days', 746.00, false, 'completed', 'mail_outline_rounded', 43669),
                (gen_random_uuid(), existing_user_id, 'Salary — Acme Corp', 'Income',
                 NOW() - INTERVAL '4 days', 8500.00, true, 'completed', 'business_center_outlined', 58784),
                (gen_random_uuid(), existing_user_id, 'Grocery — Whole Foods', 'Food and Drink',
                 NOW() - INTERVAL '5 days', 127.83, false, 'completed', 'shopping_cart_outlined', 49364),
                (gen_random_uuid(), existing_user_id, 'Electricity Bill', 'Utilities',
                 NOW() - INTERVAL '6 days', 94.50, false, 'pending', 'bolt_rounded', 4284955403),
                (gen_random_uuid(), existing_user_id, 'Uber Ride', 'Transport',
                 NOW() - INTERVAL '7 days', 22.40, false, 'completed', 'directions_car_outlined', 437323802)
            ON CONFLICT (id) DO NOTHING;
        ELSE
            RAISE NOTICE 'No users found in user_profiles. Skipping mock transactions.';
        END IF;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Mock transaction seeding failed: %', SQLERRM;
END $$;
