-- ── KYC Verifications Module ──────────────────────────────────────────────────
-- Stores Didit KYC session data and verification status per user.
-- The Edge Function writes to this table; the Flutter app reads from it.

-- 1. Add kyc_status column to user_profiles (if not already present)
ALTER TABLE public.user_profiles
  ADD COLUMN IF NOT EXISTS kyc_status TEXT DEFAULT 'unverified';

-- 2. Create kyc_verifications table
CREATE TABLE IF NOT EXISTS public.kyc_verifications (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  session_id   TEXT,
  status       TEXT NOT NULL DEFAULT 'pending',
  didit_status TEXT,
  didit_url    TEXT,
  created_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Unique constraint: one active KYC record per user
CREATE UNIQUE INDEX IF NOT EXISTS idx_kyc_verifications_user_id
  ON public.kyc_verifications (user_id);

CREATE INDEX IF NOT EXISTS idx_kyc_verifications_session_id
  ON public.kyc_verifications (session_id);

-- 3. Enable RLS
ALTER TABLE public.kyc_verifications ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policies
DROP POLICY IF EXISTS "users_read_own_kyc" ON public.kyc_verifications;
CREATE POLICY "users_read_own_kyc"
  ON public.kyc_verifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS "users_insert_own_kyc" ON public.kyc_verifications;
CREATE POLICY "users_insert_own_kyc"
  ON public.kyc_verifications
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Service role (Edge Function) can update any row
DROP POLICY IF EXISTS "service_update_kyc" ON public.kyc_verifications;
CREATE POLICY "service_update_kyc"
  ON public.kyc_verifications
  FOR UPDATE
  TO service_role
  USING (true)
  WITH CHECK (true);

-- 5. Trigger to keep updated_at fresh
CREATE OR REPLACE FUNCTION public.set_kyc_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS kyc_verifications_updated_at ON public.kyc_verifications;
CREATE TRIGGER kyc_verifications_updated_at
  BEFORE UPDATE ON public.kyc_verifications
  FOR EACH ROW
  EXECUTE FUNCTION public.set_kyc_updated_at();
