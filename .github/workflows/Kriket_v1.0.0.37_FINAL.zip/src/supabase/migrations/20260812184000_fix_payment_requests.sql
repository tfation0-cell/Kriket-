-- Fix payment_requests: change recipient_avatar_color from int4 to bigint
-- Flutter Color values (e.g. 0xFF6C5CE7 = 4284779239) exceed int4 max (2147483647)

ALTER TABLE public.payment_requests
  ALTER COLUMN recipient_avatar_color TYPE BIGINT USING recipient_avatar_color::BIGINT;

-- Ensure user_profiles row exists for authenticated users before insert
-- This function is called by the request_step_widget as a safety upsert
CREATE OR REPLACE FUNCTION public.ensure_user_profile_exists(
  p_user_id UUID,
  p_email TEXT DEFAULT NULL,
  p_full_name TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name)
  VALUES (
    p_user_id,
    COALESCE(p_email, ''),
    COALESCE(p_full_name, '')
  )
  ON CONFLICT (id) DO NOTHING;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'ensure_user_profile_exists failed: %', SQLERRM;
END;
$$;
