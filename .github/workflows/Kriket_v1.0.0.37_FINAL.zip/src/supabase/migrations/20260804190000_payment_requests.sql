-- payment_requests: receive money flow
-- Tracks money requests sent to contacts and incoming payment requests

DROP TYPE IF EXISTS public.payment_request_status CASCADE;
CREATE TYPE public.payment_request_status AS ENUM ('pending', 'paid', 'declined', 'expired', 'cancelled');

CREATE TABLE IF NOT EXISTS public.payment_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    requester_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    recipient_name TEXT NOT NULL,
    recipient_handle TEXT NOT NULL,
    recipient_avatar_color INTEGER NOT NULL DEFAULT 0xFF6C5CE7,
    recipient_initials TEXT NOT NULL DEFAULT '??',
    amount NUMERIC(12, 2) NOT NULL,
    note TEXT DEFAULT '',
    request_status public.payment_request_status DEFAULT 'pending'::public.payment_request_status,
    receive_link TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ DEFAULT (CURRENT_TIMESTAMP + INTERVAL '7 days')
);

CREATE INDEX IF NOT EXISTS idx_payment_requests_requester_id ON public.payment_requests(requester_id);
CREATE INDEX IF NOT EXISTS idx_payment_requests_status ON public.payment_requests(request_status);
CREATE INDEX IF NOT EXISTS idx_payment_requests_created_at ON public.payment_requests(created_at DESC);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.update_payment_request_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

ALTER TABLE public.payment_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_manage_own_payment_requests" ON public.payment_requests;
CREATE POLICY "users_manage_own_payment_requests"
ON public.payment_requests
FOR ALL
TO authenticated
USING (requester_id = auth.uid())
WITH CHECK (requester_id = auth.uid());

DROP TRIGGER IF EXISTS update_payment_requests_timestamp ON public.payment_requests;
CREATE TRIGGER update_payment_requests_timestamp
    BEFORE UPDATE ON public.payment_requests
    FOR EACH ROW
    EXECUTE FUNCTION public.update_payment_request_timestamp();

-- Seed mock payment requests for existing user
DO $$
DECLARE
    existing_user_id UUID;
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'user_profiles'
    ) THEN
        SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;

        IF existing_user_id IS NOT NULL THEN
            INSERT INTO public.payment_requests (
                id, requester_id, recipient_name, recipient_handle,
                recipient_avatar_color, recipient_initials,
                amount, note, request_status, receive_link,
                created_at, expires_at
            ) VALUES
            (
                gen_random_uuid(), existing_user_id, 'Jenny Wilson', '@jennyw',
                0xFF6C5CE7, 'JW',
                45.00, 'Dinner split last Friday', 'paid'::public.payment_request_status,
                'https://kriket7980.builtwithrocket.new/pay/' || gen_random_uuid()::TEXT,
                CURRENT_TIMESTAMP - INTERVAL '3 days',
                CURRENT_TIMESTAMP + INTERVAL '4 days'
            ),
            (
                gen_random_uuid(), existing_user_id, 'Albert Flores', '@albertf',
                0xFF2196F3, 'AF',
                120.00, 'Monthly utilities', 'pending'::public.payment_request_status,
                'https://kriket7980.builtwithrocket.new/pay/' || gen_random_uuid()::TEXT,
                CURRENT_TIMESTAMP - INTERVAL '1 day',
                CURRENT_TIMESTAMP + INTERVAL '6 days'
            ),
            (
                gen_random_uuid(), existing_user_id, 'Priya Nair', '@priyan',
                0xFFE91E63, 'PN',
                30.00, 'Coffee and snacks', 'pending'::public.payment_request_status,
                'https://kriket7980.builtwithrocket.new/pay/' || gen_random_uuid()::TEXT,
                CURRENT_TIMESTAMP - INTERVAL '2 hours',
                CURRENT_TIMESTAMP + INTERVAL '7 days'
            ),
            (
                gen_random_uuid(), existing_user_id, 'Marcus Lee', '@marcusl',
                0xFF00BCD4, 'ML',
                200.00, 'Concert tickets', 'declined'::public.payment_request_status,
                'https://kriket7980.builtwithrocket.new/pay/' || gen_random_uuid()::TEXT,
                CURRENT_TIMESTAMP - INTERVAL '5 days',
                CURRENT_TIMESTAMP + INTERVAL '2 days'
            ),
            (
                gen_random_uuid(), existing_user_id, 'Fatima Hassan', '@fatimah',
                0xFFF59E0B, 'FH',
                75.50, 'Grocery run', 'paid'::public.payment_request_status,
                'https://kriket7980.builtwithrocket.new/pay/' || gen_random_uuid()::TEXT,
                CURRENT_TIMESTAMP - INTERVAL '7 days',
                CURRENT_TIMESTAMP + INTERVAL '0 days'
            )
            ON CONFLICT (id) DO NOTHING;
        ELSE
            RAISE NOTICE 'No users found in user_profiles. Skipping mock payment requests.';
        END IF;
    ELSE
        RAISE NOTICE 'Table user_profiles does not exist. Skipping mock payment requests.';
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Mock payment requests insertion failed: %', SQLERRM;
END $$;
