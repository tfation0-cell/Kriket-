import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

serve(async (req) => {
  // ✅ CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*",
      },
    });
  }

  try {
    const { type, to, name, amount, recipient, resetLink, device, location } =
      await req.json();

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") ?? "";

    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not configured.");
    }

    let subject = "";
    let html = "";

    const baseStyle = `
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background-color: #0A0A0F;
      color: #E8E8F0;
      padding: 0;
      margin: 0;
    `;

    const containerStyle = `
      max-width: 560px;
      margin: 0 auto;
      background-color: #13131A;
      border-radius: 16px;
      overflow: hidden;
      border: 1px solid #2A2A3A;
    `;

    const headerStyle = `
      background: linear-gradient(135deg, #00C896 0%, #00A875 100%);
      padding: 32px 40px;
      text-align: center;
    `;

    const bodyStyle = `
      padding: 32px 40px;
    `;

    const footerStyle = `
      padding: 20px 40px;
      text-align: center;
      border-top: 1px solid #2A2A3A;
      color: #6B7280;
      font-size: 12px;
    `;

    const btnStyle = `
      display: inline-block;
      background: linear-gradient(135deg, #00C896 0%, #00A875 100%);
      color: #003322 !important;
      font-weight: 700;
      font-size: 15px;
      padding: 14px 32px;
      border-radius: 10px;
      text-decoration: none;
      margin-top: 24px;
    `;

    const alertBoxStyle = `
      background-color: #1E1E2A;
      border: 1px solid #2A2A3A;
      border-radius: 10px;
      padding: 16px 20px;
      margin: 20px 0;
    `;

    const greeting = name ? `Hi ${name},` : "Hello,";

    switch (type) {
      case "registration":
        subject = "Welcome to Kriket 🎉";
        html = `
          <div style="${baseStyle}">
            <div style="${containerStyle}">
              <div style="${headerStyle}">
                <h1 style="color:#003322;margin:0;font-size:28px;font-weight:800;letter-spacing:-0.5px;">Kriket</h1>
                <p style="color:#003322;margin:8px 0 0;font-size:14px;opacity:0.8;">Your money, your control</p>
              </div>
              <div style="${bodyStyle}">
                <h2 style="color:#E8E8F0;font-size:22px;font-weight:700;margin:0 0 12px;">Welcome aboard! 🚀</h2>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 8px;">${greeting}</p>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 20px;">
                  Your Kriket account has been successfully created. You now have access to fast, secure money transfers, savings pockets, and more.
                </p>
                <div style="${alertBoxStyle}">
                  <p style="color:#00C896;font-weight:700;margin:0 0 8px;font-size:14px;">✅ Account Created</p>
                  <p style="color:#9CA3AF;font-size:13px;margin:0;">You can now log in and start managing your finances with Kriket.</p>
                </div>
                <p style="color:#6B7280;font-size:13px;margin:20px 0 0;">If you did not create this account, please contact our support team immediately.</p>
              </div>
              <div style="${footerStyle}">
                <p style="margin:0;">© 2026 Kriket · All rights reserved</p>
                <p style="margin:4px 0 0;">This is an automated message, please do not reply.</p>
              </div>
            </div>
          </div>
        `;
        break;

      case "transfer":
        subject = `Transfer of €${amount} confirmed`;
        html = `
          <div style="${baseStyle}">
            <div style="${containerStyle}">
              <div style="${headerStyle}">
                <h1 style="color:#003322;margin:0;font-size:28px;font-weight:800;letter-spacing:-0.5px;">Kriket</h1>
                <p style="color:#003322;margin:8px 0 0;font-size:14px;opacity:0.8;">Transfer Confirmation</p>
              </div>
              <div style="${bodyStyle}">
                <h2 style="color:#E8E8F0;font-size:22px;font-weight:700;margin:0 0 12px;">Transfer Sent ✅</h2>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 8px;">${greeting}</p>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 20px;">
                  Your transfer has been processed successfully.
                </p>
                <div style="${alertBoxStyle}">
                  <table style="width:100%;border-collapse:collapse;">
                    <tr>
                      <td style="color:#6B7280;font-size:13px;padding:6px 0;">Amount</td>
                      <td style="color:#00C896;font-size:18px;font-weight:800;text-align:right;">€${amount}</td>
                    </tr>
                    <tr>
                      <td style="color:#6B7280;font-size:13px;padding:6px 0;">Recipient</td>
                      <td style="color:#E8E8F0;font-size:14px;font-weight:600;text-align:right;">${recipient ?? "—"}</td>
                    </tr>
                    <tr>
                      <td style="color:#6B7280;font-size:13px;padding:6px 0;">Status</td>
                      <td style="color:#00C896;font-size:13px;font-weight:700;text-align:right;">Completed</td>
                    </tr>
                  </table>
                </div>
                <p style="color:#6B7280;font-size:13px;margin:20px 0 0;">If you did not authorize this transfer, please contact support immediately.</p>
              </div>
              <div style="${footerStyle}">
                <p style="margin:0;">© 2026 Kriket · All rights reserved</p>
                <p style="margin:4px 0 0;">This is an automated message, please do not reply.</p>
              </div>
            </div>
          </div>
        `;
        break;

      case "password_reset":
        subject = "Reset your Kriket password";
        html = `
          <div style="${baseStyle}">
            <div style="${containerStyle}">
              <div style="${headerStyle}">
                <h1 style="color:#003322;margin:0;font-size:28px;font-weight:800;letter-spacing:-0.5px;">Kriket</h1>
                <p style="color:#003322;margin:8px 0 0;font-size:14px;opacity:0.8;">Password Reset</p>
              </div>
              <div style="${bodyStyle}">
                <h2 style="color:#E8E8F0;font-size:22px;font-weight:700;margin:0 0 12px;">Reset Your Password 🔑</h2>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 8px;">${greeting}</p>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 20px;">
                  We received a request to reset your Kriket account password. Click the button below to set a new password.
                </p>
                <div style="text-align:center;">
                  <a href="${resetLink ?? "#"}" style="${btnStyle}">Reset Password</a>
                </div>
                <div style="${alertBoxStyle}">
                  <p style="color:#F59E0B;font-weight:700;margin:0 0 6px;font-size:13px;">⚠️ This link expires in 1 hour</p>
                  <p style="color:#9CA3AF;font-size:13px;margin:0;">If you did not request a password reset, you can safely ignore this email. Your password will not change.</p>
                </div>
              </div>
              <div style="${footerStyle}">
                <p style="margin:0;">© 2026 Kriket · All rights reserved</p>
                <p style="margin:4px 0 0;">This is an automated message, please do not reply.</p>
              </div>
            </div>
          </div>
        `;
        break;

      case "security_alert":
        subject = "⚠️ Security Alert — Kriket";
        html = `
          <div style="${baseStyle}">
            <div style="${containerStyle}">
              <div style="background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);padding: 32px 40px;text-align: center;">
                <h1 style="color:#fff;margin:0;font-size:28px;font-weight:800;letter-spacing:-0.5px;">Kriket</h1>
                <p style="color:#fff;margin:8px 0 0;font-size:14px;opacity:0.85;">Security Alert</p>
              </div>
              <div style="${bodyStyle}">
                <h2 style="color:#EF4444;font-size:22px;font-weight:700;margin:0 0 12px;">⚠️ Suspicious Activity Detected</h2>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 8px;">${greeting}</p>
                <p style="color:#9CA3AF;font-size:15px;line-height:1.6;margin:0 0 20px;">
                  We detected a login attempt to your Kriket account from an unrecognized device or location.
                </p>
                <div style="${alertBoxStyle}">
                  <table style="width:100%;border-collapse:collapse;">
                    <tr>
                      <td style="color:#6B7280;font-size:13px;padding:6px 0;">Device</td>
                      <td style="color:#E8E8F0;font-size:13px;font-weight:600;text-align:right;">${device ?? "Unknown Device"}</td>
                    </tr>
                    <tr>
                      <td style="color:#6B7280;font-size:13px;padding:6px 0;">Location</td>
                      <td style="color:#E8E8F0;font-size:13px;font-weight:600;text-align:right;">${location ?? "Unknown Location"}</td>
                    </tr>
                    <tr>
                      <td style="color:#6B7280;font-size:13px;padding:6px 0;">Time</td>
                      <td style="color:#E8E8F0;font-size:13px;font-weight:600;text-align:right;">${new Date().toUTCString()}</td>
                    </tr>
                  </table>
                </div>
                <p style="color:#9CA3AF;font-size:14px;line-height:1.6;">
                  If this was you, no action is needed. If you don't recognize this activity, please change your password immediately and contact our support team.
                </p>
              </div>
              <div style="${footerStyle}">
                <p style="margin:0;">© 2026 Kriket · All rights reserved</p>
                <p style="margin:4px 0 0;">This is an automated security notification.</p>
              </div>
            </div>
          </div>
        `;
        break;

      default:
        throw new Error(`Unknown email type: ${type}`);
    }

    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: [to],
        subject,
        html,
      }),
    });

    const resendData = await resendResponse.json();

    if (!resendResponse.ok) {
      throw new Error(resendData.message ?? "Failed to send email via Resend");
    }

    return new Response(
      JSON.stringify({ success: true, id: resendData.id }),
      {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      }
    );
  }
});
