import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const diditApiKey = Deno.env.get("DIDIT_API_KEY")!;
    const diditWorkflowId = Deno.env.get("DIDIT_WORKFLOW_ID") ?? "";

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Parse body first so we can detect webhook vs authenticated requests
    let body: Record<string, unknown> = {};
    try {
      body = await req.json();
    } catch {
      body = {};
    }

    // ── Didit Webhook callback ──────────────────────────────────────
    // Didit sends POST with webhook_type field — no Supabase JWT
    const webhookType = body.webhook_type as string | undefined;
    if (webhookType === "status.updated" || webhookType === "data.updated") {
      const sessionId = body.session_id as string | undefined;
      const diditStatus = (body.status as string ?? "");

      if (!sessionId) {
        console.error("Webhook missing session_id");
        return new Response(JSON.stringify({ received: true }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Map Didit's capitalized statuses to our internal statuses
      // Didit statuses: "Approved", "Declined", "In Review", "In Progress",
      //                 "Not Started", "Expired", "Abandoned", "Resubmitted"
      let internalStatus = "pending";
      const statusLower = diditStatus.toLowerCase();
      if (statusLower === "approved") {
        internalStatus = "verified";
      } else if (
        statusLower === "declined" ||
        statusLower === "expired" ||
        statusLower === "abandoned"
      ) {
        internalStatus = "declined";
      } else if (statusLower === "in review") {
        internalStatus = "in_review";
      } else if (statusLower === "in progress" || statusLower === "not started" || statusLower === "resubmitted") {
        internalStatus = "pending";
      }

      console.log(`Webhook: session=${sessionId} didit_status="${diditStatus}" -> internal="${internalStatus}"`);

      // Update kyc_verifications
      const { error: updateError } = await supabase
        .from("kyc_verifications")
        .update({
          status: internalStatus,
          didit_status: diditStatus,
          updated_at: new Date().toISOString(),
        })
        .eq("session_id", sessionId);

      if (updateError) {
        console.error("Webhook update error:", updateError);
      }

      // Also update user_profiles kyc_status for terminal states
      if (internalStatus === "verified" || internalStatus === "declined" || internalStatus === "in_review") {
        const { data: kycRow, error: fetchErr } = await supabase
          .from("kyc_verifications")
          .select("user_id")
          .eq("session_id", sessionId)
          .maybeSingle();

        if (fetchErr) console.error("Fetch user_id error:", fetchErr);

        if (kycRow?.user_id) {
          const { error: profileErr } = await supabase
            .from("user_profiles")
            .update({
              kyc_status: internalStatus,
              updated_at: new Date().toISOString(),
            })
            .eq("id", kycRow.user_id);

          if (profileErr) console.error("Profile update error:", profileErr);
        }
      }

      return new Response(JSON.stringify({ received: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── All other actions require authenticated user ────────────────
    if (!diditApiKey) {
      return new Response(
        JSON.stringify({ error: "DIDIT_API_KEY is not configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const action = body.action as string;

    // ── Action: create-session ──────────────────────────────────────
    if (action === "create-session") {
      const workflowId = (body.workflow_id as string | undefined) ?? diditWorkflowId;

      if (!workflowId) {
        return new Response(
          JSON.stringify({
            error:
              "workflow_id is required. Set DIDIT_WORKFLOW_ID secret or pass workflow_id in request.",
          }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      const callbackUrl = `${supabaseUrl}/functions/v1/didit-kyc`;

      console.log(`Creating Didit session for user=${user.id} workflow=${workflowId}`);

      // Call Didit API to create a verification session
      const diditResponse = await fetch(
        "https://verification.didit.me/v3/session/",
        {
          method: "POST",
          headers: {
            "x-api-key": diditApiKey,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            workflow_id: workflowId,
            vendor_data: user.id,
            callback: callbackUrl,
            callback_method: "both",
          }),
        }
      );

      const responseText = await diditResponse.text();
      console.log(`Didit API response status: ${diditResponse.status}`);
      console.log(`Didit API response body: ${responseText}`);

      if (!diditResponse.ok) {
        console.error("Didit API error:", responseText);
        return new Response(
          JSON.stringify({
            error: "Failed to create Didit session",
            details: responseText,
            didit_status: diditResponse.status,
          }),
          {
            status: 502,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      let session: Record<string, unknown>;
      try {
        session = JSON.parse(responseText);
      } catch {
        return new Response(
          JSON.stringify({ error: "Invalid JSON from Didit API", raw: responseText }),
          {
            status: 502,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      const sessionId = session.session_id as string;
      const sessionUrl = session.url as string;

      if (!sessionId || !sessionUrl) {
        console.error("Didit response missing session_id or url:", session);
        return new Response(
          JSON.stringify({ error: "Didit response missing session_id or url", raw: session }),
          {
            status: 502,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      // Upsert KYC record in Supabase
      const { error: dbError } = await supabase
        .from("kyc_verifications")
        .upsert(
          {
            user_id: user.id,
            session_id: sessionId,
            status: "pending",
            didit_url: sessionUrl,
            updated_at: new Date().toISOString(),
          },
          { onConflict: "user_id" }
        );

      if (dbError) {
        console.error("DB upsert error:", dbError);
        // Non-fatal: still return the URL so the user can proceed
      }

      return new Response(
        JSON.stringify({
          session_id: sessionId,
          url: sessionUrl,
          status: session.status ?? "Not Started",
        }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // ── Action: get-status ──────────────────────────────────────────
    if (action === "get-status") {
      const { data, error: dbError } = await supabase
        .from("kyc_verifications")
        .select("status, session_id, didit_url, updated_at")
        .eq("user_id", user.id)
        .maybeSingle();

      if (dbError) {
        return new Response(JSON.stringify({ error: dbError.message }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ kyc: data }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(JSON.stringify({ error: "Internal server error", detail: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
