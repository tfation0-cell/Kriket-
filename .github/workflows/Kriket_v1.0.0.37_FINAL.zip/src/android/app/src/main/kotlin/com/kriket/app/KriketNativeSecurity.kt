package com.kriket.app

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.provider.Settings
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.StandardIntegrityManager.PrepareIntegrityTokenRequest
import com.google.android.play.core.integrity.StandardIntegrityManager.StandardIntegrityTokenProvider
import com.google.android.play.core.integrity.StandardIntegrityManager.StandardIntegrityTokenRequest
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

object KriketNativeSecurity {
    private const val KEY_ALIAS = "kriket_device_key"
    private var integrityProvider: StandardIntegrityTokenProvider? = null

    fun attach(activity: Activity, channel: MethodChannel) {
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "initializeSecureKey" -> {
                    try {
                        ensureKey()
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("KEYSTORE_ERROR", e.message, null)
                    }
                }
                "getSecurityStatus" -> result.success(securityStatus(activity))
                "getInitialDeepLink" -> result.success(activity.intent?.data?.toString())
                "preparePlayIntegrity" -> {
                    val projectNumber = call.argument<Number>("cloudProjectNumber")?.toLong()
                    if (projectNumber == null || projectNumber <= 0) {
                        result.error("INTEGRITY_CONFIG", "Google Cloud project number is required", null)
                        return@setMethodCallHandler
                    }
                    try {
                        val manager = IntegrityManagerFactory.createStandard(activity.applicationContext)
                        manager.prepareIntegrityToken(
                            PrepareIntegrityTokenRequest.builder()
                                .setCloudProjectNumber(projectNumber)
                                .build()
                        ).addOnSuccessListener { provider ->
                            integrityProvider = provider
                            result.success(true)
                        }.addOnFailureListener { e ->
                            result.error("INTEGRITY_PREPARE", e.message, null)
                        }
                    } catch (e: Exception) {
                        result.error("INTEGRITY_PREPARE", e.message, null)
                    }
                }
                "requestPlayIntegrity" -> {
                    val requestHash = call.argument<String>("requestHash").orEmpty()
                    if (requestHash.isEmpty()) {
                        result.error("INTEGRITY_HASH", "requestHash is required", null)
                        return@setMethodCallHandler
                    }
                    val provider = integrityProvider
                    if (provider == null) {
                        result.error("INTEGRITY_NOT_READY", "Play Integrity provider is not prepared", null)
                        return@setMethodCallHandler
                    }
                    try {
                        provider.request(
                            StandardIntegrityTokenRequest.builder()
                                .setRequestHash(requestHash)
                                .build()
                        ).addOnSuccessListener { response ->
                            result.success(response.token())
                        }.addOnFailureListener { e ->
                            result.error("INTEGRITY_REQUEST", e.message, null)
                        }
                    } catch (e: Exception) {
                        result.error("INTEGRITY_REQUEST", e.message, null)
                    }
                }
                "isDeviceLocked" -> {
                    val keyguard = activity.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                    result.success(keyguard.isKeyguardLocked)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun ensureKey() {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        if (ks.containsAlias(KEY_ALIAS)) return
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(
            android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        generator.generateKey()
    }

    private fun securityStatus(activity: Activity): Map<String, Any> {
        return mapOf(
            "keystoreAvailable" to try { ensureKey(); true } catch (_: Exception) { false },
            "debuggerAttached" to Debug.isDebuggerConnected(),
            "rootLikely" to rootLikely(),
            "emulatorLikely" to emulatorLikely(),
            "developerOptions" to developerOptions(activity),
            "signatureSha256" to signingCertificateSha256(activity)
        )
    }

    private fun developerOptions(activity: Activity): Boolean {
        return try {
            Settings.Global.getInt(
                activity.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                0
            ) == 1
        } catch (_: Exception) { false }
    }

    private fun rootLikely(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/data/adb/magisk", "/data/adb/ksu"
        )
        return paths.any { java.io.File(it).exists() } ||
            Build.TAGS?.contains("test-keys") == true
    }

    private fun emulatorLikely(): Boolean {
        val fingerprint = Build.FINGERPRINT.orEmpty().lowercase()
        val model = Build.MODEL.orEmpty().lowercase()
        val product = Build.PRODUCT.orEmpty().lowercase()
        return fingerprint.contains("generic") ||
            fingerprint.contains("emulator") ||
            model.contains("emulator") ||
            model.contains("android sdk") ||
            product.contains("sdk")
    }

    private fun signingCertificateSha256(activity: Activity): String {
        return try {
            val pm = activity.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pm.getPackageInfo(
                    activity.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(activity.packageName, PackageManager.GET_SIGNATURES)
            }
            val bytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.signatures?.firstOrNull()?.toByteArray()
            } ?: return ""
            MessageDigest.getInstance("SHA-256").digest(bytes)
                .joinToString(":") { "%02X".format(it) }
        } catch (_: Exception) { "" }
    }
}
