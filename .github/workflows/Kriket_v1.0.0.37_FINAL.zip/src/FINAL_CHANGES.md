# Kriket final-pass changes from v1.0.0.35

- Home card now prefers the same `virtual_cards` source used by the Cards screen.
- Savings live balance display refreshes server data every 15 seconds and interpolates accrued yield every second from the latest synced APY/position.
- EURC and USDC catalog Deposit/Withdraw buttons route to their existing real execution flows; unsupported assets remain explicitly unavailable rather than fake.
- Home notification bell now opens recent real transactions instead of showing a permanent fake red dot.
- Support screen uses the newly supplied support image asset.
- Exchange Rates keeps the existing rate/converter screen and now clearly states it is rate display only.
- Spending Analytics now reads completed debit transactions from Supabase instead of hard-coded sample numbers.

Note: Flutter SDK was not installed in the build container, so a local `flutter analyze`/AAB build could not be executed here.

- Final v1.0.0+37: IBAN section now shows connected state from the stored real profile IBAN, includes copy action, and explicitly avoids demo IBANs.
