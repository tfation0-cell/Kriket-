#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/opt/hostedtoolcache/flutter/stable-3.47.5-x64/flutter"
export "FLUTTER_APPLICATION_PATH=/home/runner/work/Kriket-/Kriket-/extracted/kriket"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/home/runner/work/Kriket-/Kriket-/extracted/kriket/ios/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=35"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
