import 'services/native_security_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import './core/app_export.dart';
import './providers/app_providers.dart';
import './services/biometric_service.dart';
import './services/session_service.dart';
import './services/supabase_service.dart';
import './services/push_notification_service.dart';
import './widgets/custom_error_widget.dart';
import 'services/kriket_wallet_bootstrap.dart';



@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint('[FCM] Background message: ${message.messageId}');
  try {
    await PushNotificationService.showBackgroundDataNotification(message);
  } catch (e) {
    debugPrint('[FCM] Background notification display failed: $e');
  }
}

class KriketPasswordRecovery {
  static final navigatorKey = GlobalKey<NavigatorState>();
  static Future<void> handleRecovery() async {
    final context = navigatorKey.currentState?.overlay?.context;
    if (context == null) return;
    final password = TextEditingController();
    final confirm = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Vendos fjalëkalimin e ri'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: password, obscureText: true),
          const SizedBox(height: 12),
          TextField(controller: confirm, obscureText: true),
        ]),
        actions: [
          FilledButton(
            onPressed: () async {
              if (password.text.length < 8 || password.text != confirm.text) return;
              await Supabase.instance.client.auth.updateUser(UserAttributes(password: password.text));
              if (dialogContext.mounted) Navigator.of(dialogContext).pop(true);
            },
            child: const Text('Ruaj fjalëkalimin'),
          ),
        ],
      ),
    );
    password.dispose();
    confirm.dispose();
    if (ok == true) navigatorKey.currentState?.popUntil((route) => route.isFirst);
  }
}

void initializeKriketPasswordRecoveryListener() {
  Supabase.instance.client.auth.onAuthStateChange.listen((data) {
    if (data.event == AuthChangeEvent.passwordRecovery) {
      Future.microtask(KriketPasswordRecovery.handleRecovery);
    }
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  KriketWalletBootstrap.initialize();
  KriketNativeSecurityService.initialize();

  // Initialize Firebase
  try {
    await Firebase.initializeApp();
    // Register the background handler before runApp so FCM can deliver
    // messages while the app is in the background or terminated.
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  } catch (e) {
    debugPrint('[FCM] Firebase initialization failed: $e');
  }

  // Initialize Supabase
  try {
    await SupabaseService.initialize();
  } catch (e) {
    debugPrint('Failed to initialize Supabase: $e');
  }

  // Register FCM only after Supabase is ready.
  if (!kIsWeb) {
    try {
      await PushNotificationService.initialize();
    } catch (e) {
      debugPrint('[FCM] Push service initialization failed: $e');
    }
  }


  bool hasShownError = false;

  // 🚨 CRITICAL: Custom error handling - DO NOT REMOVE
  ErrorWidget.builder = (FlutterErrorDetails details) {
    if (!hasShownError) {
      hasShownError = true;

      // Reset flag after 3 seconds to allow error widget on new screens
      Future.delayed(Duration(seconds: 5), () {
        hasShownError = false;
      });

      return CustomErrorWidget(errorDetails: details);
    }
    return SizedBox.shrink();
  };

  GoRouter.optionURLReflectsImperativeAPIs = true;

  // 🚨 CRITICAL: Device orientation lock — skip on web (not supported)
  if (!kIsWeb) {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  }

  initializeKriketPasswordRecoveryListener();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => LocaleProvider()),
        ChangeNotifierProvider(create: (_) => BiometricProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();

    // Listen for password recovery deep link
    Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      if (data.event == AuthChangeEvent.passwordRecovery) {
        appRouter.go(AppRoutes.resetPassword);
      }

      // Persist session on sign-in / token refresh
      if (data.event == AuthChangeEvent.signedIn ||
          data.event == AuthChangeEvent.tokenRefreshed) {
        if (data.session != null) {
          SessionService.instance.persistSession(data.session!);
          // Keep biometric session tokens fresh
          _updateBiometricSessionIfEnabled(data.session!);
        }
      }

      // Clear stored session on sign-out or user deletion
      if (data.event == AuthChangeEvent.signedOut ||
          data.event == AuthChangeEvent.userDeleted) {
        SessionService.instance.clearSession();
        BiometricService.instance.setEnabled(false);
      }
    });
  }

  Future<void> _updateBiometricSessionIfEnabled(session) async {
    try {
      final enabled = await BiometricService.instance.isEnabled();
      if (enabled && session != null) {
        final accessToken = session.accessToken as String?;
        final refreshToken = session.refreshToken as String?;
        if (accessToken != null &&
            accessToken.isNotEmpty &&
            refreshToken != null &&
            refreshToken.isNotEmpty) {
          await BiometricService.instance.storeBiometricSession(
            accessToken: accessToken,
            refreshToken: refreshToken,
          );
          debugPrint('[main] Biometric session tokens refreshed.');
        }
      }
    } catch (e) {
      debugPrint('[main] Failed to update biometric session: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return Sizer(
      builder: (context, orientation, screenType) {
        return MaterialApp.router(
          title: 'kriket',
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          themeMode: themeProvider.themeMode,
          // 🚨 CRITICAL: NEVER REMOVE OR MODIFY
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(
                context,
              ).copyWith(textScaler: TextScaler.linear(1.0)),
              child: child!,
            );
          },
          // 🚨 END CRITICAL SECTION
          debugShowCheckedModeBanner: false,
          routerConfig: appRouter,
        );
      },
    );
  }
}
