import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── Theme Provider ─────────────────────────────────────────────────
class ThemeProvider extends ChangeNotifier {
  static const String _key = 'theme_mode';
  ThemeMode _themeMode = ThemeMode.dark;

  ThemeMode get themeMode => _themeMode;
  bool get isDark => _themeMode == ThemeMode.dark;

  ThemeProvider() {
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_key);
    if (saved == 'light') {
      _themeMode = ThemeMode.light;
    } else {
      _themeMode = ThemeMode.dark;
    }
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _themeMode = _themeMode == ThemeMode.dark
        ? ThemeMode.light
        : ThemeMode.dark;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      _themeMode == ThemeMode.dark ? 'dark' : 'light',
    );
    notifyListeners();
  }
}

// ── Locale Provider ────────────────────────────────────────────────
class LocaleProvider extends ChangeNotifier {
  static const String _key = 'locale';

  static const Map<String, String> supportedLanguages = {
    'en': 'English', 'es': 'Spanish', 'fr': 'French', 'de': 'German', 'it': 'Italian',
    'pt': 'Portuguese', 'nl': 'Dutch', 'el': 'Greek', 'sq': 'Albanian', 'ar': 'Arabic',
    'tr': 'Turkish', 'zh': 'Chinese', 'ja': 'Japanese', 'ko': 'Korean', 'ru': 'Russian',
    'uk': 'Ukrainian', 'pl': 'Polish', 'cs': 'Czech', 'sk': 'Slovak', 'hu': 'Hungarian',
    'ro': 'Romanian', 'bg': 'Bulgarian', 'sr': 'Serbian', 'hr': 'Croatian', 'bs': 'Bosnian',
    'sl': 'Slovenian', 'mk': 'Macedonian', 'cnr': 'Montenegrin', 'lt': 'Lithuanian', 'lv': 'Latvian',
    'et': 'Estonian', 'fi': 'Finnish', 'sv': 'Swedish', 'no': 'Norwegian', 'da': 'Danish',
    'is': 'Icelandic', 'ga': 'Irish', 'cy': 'Welsh', 'eu': 'Basque', 'ca': 'Catalan', 'gl': 'Galician',
    'mt': 'Maltese', 'he': 'Hebrew', 'fa': 'Persian', 'ur': 'Urdu', 'hi': 'Hindi', 'bn': 'Bengali',
    'pa': 'Punjabi', 'gu': 'Gujarati', 'mr': 'Marathi', 'ta': 'Tamil', 'te': 'Telugu', 'kn': 'Kannada',
    'ml': 'Malayalam', 'ne': 'Nepali', 'si': 'Sinhala', 'th': 'Thai', 'vi': 'Vietnamese', 'id': 'Indonesian',
    'ms': 'Malay', 'fil': 'Filipino', 'sw': 'Swahili', 'af': 'Afrikaans', 'am': 'Amharic', 'hy': 'Armenian',
    'az': 'Azerbaijani', 'be': 'Belarusian', 'my': 'Burmese', 'ka': 'Georgian', 'kk': 'Kazakh', 'ky': 'Kyrgyz',
    'mn': 'Mongolian', 'tg': 'Tajik', 'tk': 'Turkmen', 'uz': 'Uzbek', 'ku': 'Kurdish', 'ps': 'Pashto',
    'prs': 'Dari', 'so': 'Somali', 'ha': 'Hausa', 'yo': 'Yoruba', 'ig': 'Igbo', 'zu': 'Zulu', 'xh': 'Xhosa',
    'st': 'Sesotho', 'tn': 'Setswana', 'sn': 'Shona', 'rw': 'Kinyarwanda', 'rn': 'Kirundi', 'mg': 'Malagasy',
    'mi': 'Maori', 'sm': 'Samoan', 'to': 'Tongan', 'fj': 'Fijian', 'ht': 'Haitian Creole', 'jam': 'Jamaican Creole',
    'lo': 'Lao', 'km': 'Khmer', 'bo': 'Tibetan', 'ug': 'Uyghur', 'tt': 'Tatar', 'ba': 'Bashkir', 'ce': 'Chechen',
    'ab': 'Abkhaz', 'os': 'Ossetian', 'mo': 'Moldovan', 'yi': 'Yiddish', 'la': 'Latin', 'eo': 'Esperanto',
    'ia': 'Interlingua', 'io': 'Ido', 'oc': 'Occitan', 'co': 'Corsican', 'fy': 'Frisian', 'lb': 'Luxembourgish',
    'br': 'Breton', 'gd': 'Scottish Gaelic', 'gv': 'Manx', 'fo': 'Faroese', 'kl': 'Greenlandic', 'sc': 'Sardinian',
    'rm': 'Romansh', 'an': 'Aragonese', 'ast': 'Asturian', 'ay': 'Aymara', 'qu': 'Quechua', 'gn': 'Guarani',
    'nah': 'Nahuatl', 'myn': 'Mayan', 'hmn': 'Hmong', 'dz': 'Dzongkha', 'dv': 'Dhivehi', 'as': 'Assamese',
    'or': 'Odia', 'mai': 'Maithili', 'bho': 'Bhojpuri', 'ks': 'Kashmiri', 'sd': 'Sindhi', 'sa': 'Sanskrit',
    'pi': 'Pali', 'kok': 'Konkani', 'mni': 'Manipuri', 'lus': 'Mizo', 'bm': 'Bambara', 'wo': 'Wolof', 'ff': 'Fulah',
    'tw': 'Twi', 'ee': 'Ewe', 'gaa': 'Ga', 'ln': 'Lingala', 'kg': 'Kongo', 'ny': 'Chichewa', 'ts': 'Tsonga',
    've': 'Venda', 'nso': 'Northern Sotho', 'om': 'Oromo', 'ti': 'Tigrinya', 'ak': 'Akan', 'ber': 'Berber',
    'kab': 'Kabyle', 'wal': 'Wolaytta', 'bi': 'Bislama', 'tpi': 'Tok Pisin', 'mh': 'Marshallese', 'pau': 'Palauan',
    'ch': 'Chamorro', 'haw': 'Hawaiian', 'iu': 'Inuktitut', 'ik': 'Inupiaq', 'nv': 'Navajo', 'chr': 'Cherokee',
    'oj': 'Ojibwe', 'crh': 'Crimean Tatar',
    'ace': 'Acehnese',
    'ada': 'Adangme',
    'ady': 'Adyghe',
    'agq': 'Aghem',
    'ain': 'Ainu',
    'ale': 'Aleut',
    'alt': 'Southern Altai',
    'anp': 'Angika',
    'arn': 'Mapudungun',
    'arp': 'Arapaho',
    'asa': 'Asu',
    'av': 'Avaric',
    'awa': 'Awadhi',
    'ban': 'Balinese',
    'bas': 'Basaa',
    'bej': 'Beja',
    'bem': 'Bemba',
    'bik': 'Bikol',
    'bin': 'Bini',
    'bla': 'Siksika',
    'bnt': 'Bantu',
    'bug': 'Buginese',
    'byn': 'Blin',
    'cad': 'Caddo',
    'car': 'Carib',
    'ceb': 'Cebuano',
    'cgg': 'Chiga',
  };

  Locale _locale = const Locale('en');

  Locale get locale => _locale;
  String get languageCode => _locale.languageCode;
  String get languageName =>
      supportedLanguages[_locale.languageCode] ?? 'English';

  LocaleProvider() {
    _loadLocale();
  }

  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_key) ?? 'en';
    _locale = Locale(saved);
    notifyListeners();
  }

  Future<void> setLocale(String languageCode) async {
    if (!supportedLanguages.containsKey(languageCode)) return;
    _locale = Locale(languageCode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, languageCode);
    notifyListeners();
  }
}

// ── Biometric Provider ─────────────────────────────────────────────
class BiometricProvider extends ChangeNotifier {
  static const String _key = 'biometric_enabled';
  bool _biometricEnabled = false;

  bool get biometricEnabled => _biometricEnabled;

  BiometricProvider() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _biometricEnabled = prefs.getBool(_key) ?? false;
    notifyListeners();
  }

  Future<void> setBiometric(bool value) async {
    _biometricEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_key, value);
    notifyListeners();
  }
}
