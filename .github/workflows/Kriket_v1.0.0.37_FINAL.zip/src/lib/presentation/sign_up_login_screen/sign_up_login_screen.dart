import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../routes/app_routes.dart';
import './widgets/auth_form_widget.dart';
import './widgets/particle_background_widget.dart';

class SignUpLoginScreen extends StatelessWidget {
  const SignUpLoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: Stack(
        children: [
          // Animated particle background — V2 Particle / Dot Field LOCKED
          const ParticleBackgroundWidget(),

          // Auth form content
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 32,
                ),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: AuthFormWidget(
                    onLoginSuccess: () => context.go(AppRoutes.home),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
