import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../theme/app_theme.dart';

class PdfStatementsScreen extends StatefulWidget {
  const PdfStatementsScreen({super.key});
  @override
  State<PdfStatementsScreen> createState() => _PdfStatementsScreenState();
}

class _PdfStatementsScreenState extends State<PdfStatementsScreen> {
  bool _generating = false;

  Future<void> _generatePdf() async {
    if (_generating) return;
    setState(() => _generating = true);
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      final name = (user?.userMetadata?['full_name'] ?? user?.email ?? 'Kriket user').toString();
      final email = user?.email ?? '—';
      List<Map<String, dynamic>> rows = [];
      if (user != null) {
        try {
          final data = await client.from('transactions').select('name, amount, is_credit, status, transaction_date').eq('user_id', user.id).order('transaction_date', ascending: false).limit(50);
          rows = List<Map<String, dynamic>>.from(data);
        } catch (_) {}
      }
      final doc = pw.Document();
      final logoBytes = (await rootBundle.load('assets/images/kriket_logo.png')).buffer.asUint8List();
      final logo = pw.MemoryImage(logoBytes);
      doc.addPage(pw.MultiPage(
        build: (context) => [
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Image(logo, width: 42, height: 42),
              pw.SizedBox(width: 12),
              pw.Text('Kriket — Account Statement', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
            ],
          ),
          pw.SizedBox(height: 8),
          pw.Text(name, style: pw.TextStyle(fontSize: 14)),
          pw.Text(email, style: const pw.TextStyle(fontSize: 11)),
          pw.SizedBox(height: 20),
          pw.Text('Generated: ${DateTime.now().toLocal().toString().split('.').first}'),
          pw.SizedBox(height: 18),
          if (rows.isEmpty)
            pw.Text('No transactions available yet.')
          else
            pw.Table.fromTextArray(
              headers: ['Date', 'Description', 'Amount', 'Status'],
              data: rows.map((r) {
                final date = DateTime.tryParse(r['transaction_date']?.toString() ?? '')?.toLocal();
                final amount = (r['amount'] ?? 0).toString();
                final signed = r['is_credit'] == true ? '+$amount' : '-$amount';
                return [date?.toString().split('.').first ?? '—', r['name']?.toString() ?? '—', signed, r['status']?.toString() ?? '—'];
              }).toList(),
            ),
          pw.SizedBox(height: 24),
          pw.Text('Kriket Technologies', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        ],
      ));
      await Printing.layoutPdf(onLayout: (_) async => doc.save(), name: 'kriket_statement.pdf');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF nuk u gjenerua: $e')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.backgroundDark,
    appBar: AppBar(title: const Text('PDF Statements'), backgroundColor: AppTheme.backgroundDark, elevation: 0),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 78, height: 78, decoration: BoxDecoration(color: AppTheme.primaryContainer, borderRadius: BorderRadius.circular(24)), child: const Icon(Icons.picture_as_pdf_rounded, color: AppTheme.primary, size: 40)),
          const SizedBox(height: 18),
          const Text('Gjenero pasqyrën e llogarisë', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Manrope', color: AppTheme.textPrimaryDark, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('Krijo një PDF me të dhënat e llogarisë dhe transaksionet e tua.', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Manrope', color: AppTheme.textMutedDark, fontSize: 13, height: 1.45)),
          const SizedBox(height: 24),
          SizedBox(width: double.infinity, height: 52, child: ElevatedButton.icon(onPressed: _generating ? null : _generatePdf, icon: _generating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.picture_as_pdf_rounded), label: Text(_generating ? 'Po gjenerohet...' : 'Gjenero PDF'))),
        ]),
      ),
    ),
  );
}
