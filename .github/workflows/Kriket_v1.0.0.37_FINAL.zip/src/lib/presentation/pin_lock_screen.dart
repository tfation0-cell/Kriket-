import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:local_auth/local_auth.dart';
import '../routes/app_routes.dart';
import '../services/pin_service.dart';
import '../services/biometric_service.dart';
import '../services/session_service.dart';
import '../theme/app_theme.dart';

class PinLockScreen extends StatefulWidget {
  const PinLockScreen({super.key});
  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen> {
  int _length = 6;
  String _pin = '';
  String? _error;
  bool _biometricAvailable = false;
  bool _biometricEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadLength();
    _loadBiometric();
  }

  Future<void> _loadLength() async {
    final length = await PinService.instance.getLength();
    if (mounted) setState(() => _length = length);
  }


  Future<void> _loadBiometric() async {
    final available = await BiometricService.instance.isAvailable();
    final enabled = await BiometricService.instance.isEnabled();
    if (mounted) {
      setState(() {
        _biometricAvailable = available;
        _biometricEnabled = enabled;
      });
    }
  }

  Future<void> _useBiometric() async {
    if (!_biometricAvailable || !_biometricEnabled) return;
    if (mounted) context.go(AppRoutes.biometricLock);
  }

  Future<void> _verify() async {
    final ok = await PinService.instance.verify(_pin);
    if (!mounted) return;
    if (ok) {
      context.go(AppRoutes.home);
    } else {
      setState(() { _pin = ''; _error = 'Incorrect code. Try again.'; });
    }
  }

  void _add(String d) {
    if (_pin.length >= _length) return;
    setState(() { _pin += d; _error = null; });
    if (_pin.length == _length) _verify();
  }

  void _delete() {
    if (_pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Future<void> _authenticateFingerprint() async {
    try {
      final auth = LocalAuthentication();
      final available = await auth.canCheckBiometrics || await auth.isDeviceSupported();
      if (!available) return;
      final ok = await auth.authenticate(
        localizedReason: 'Use your fingerprint to unlock Kriket',
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      if (ok && mounted) context.go(AppRoutes.home);
    } catch (_) {}
  }

  Future<void> _logout() async {
    await SessionService.instance.clearSession();
    await PinService.instance.clear();
    try { await Supabase.instance.client.auth.signOut(); } catch (_) {}
    if (mounted) context.go(AppRoutes.signUpLogin);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            ClipRRect(borderRadius: BorderRadius.circular(22), child: Image.asset('assets/images/kriket_logo.png', width: 88, height: 88, fit: BoxFit.cover)),
            const SizedBox(height: 24),
            const Text('Welcome back', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('Enter your $_length-digit code', style: const TextStyle(color: AppTheme.textSecondaryDark)),
            const SizedBox(height: 28),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(_length, (i) => Container(width: 14, height: 14, margin: const EdgeInsets.symmetric(horizontal: 7), decoration: BoxDecoration(shape: BoxShape.circle, color: i < _pin.length ? AppTheme.primary : const Color(0xFF26343A))))),
            if (_error != null) ...[const SizedBox(height: 18), Text(_error!, style: const TextStyle(color: AppTheme.error))],
            const Spacer(),
            Padding(padding: const EdgeInsets.fromLTRB(28, 0, 28, 12), child: _LockKeypad(onDigit: _add, onDelete: _delete, onBiometric: _useBiometric, biometricAvailable: _biometricAvailable, biometricEnabled: _biometricEnabled)),
            TextButton(onPressed: _logout, child: const Text('Use account password / Sign out')),
            const SizedBox(height: 18),
          ],
        ),
      ),
    );
  }
}

class _LockKeypad extends StatelessWidget {
  final ValueChanged<String> onDigit;
  final VoidCallback onDelete;
  final VoidCallback onBiometric;
  final bool biometricAvailable;
  final bool biometricEnabled;
  const _LockKeypad({
    required this.onDigit,
    required this.onDelete,
    required this.onBiometric,
    required this.biometricAvailable,
    required this.biometricEnabled,
  });
  @override
  Widget build(BuildContext context) {
    final keys = ['1','2','3','4','5','6','7','8','9','biometric', '0', '⌫'];
    return GridView.builder(
      shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: 12,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.55),
      itemBuilder: (_, i) {
        final key = keys[i];
        if (key == 'biometric') {
          if (!biometricAvailable || !biometricEnabled) {
            return const SizedBox.shrink();
          }
          return Material(
            color: const Color(0xFF172229),
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: onBiometric,
              child: const Center(
                child: Icon(
                  Icons.fingerprint_rounded,
                  color: AppTheme.primary,
                  size: 32,
                ),
              ),
            ),
          );
        }
        return Material(color: const Color(0xFF172229), borderRadius: BorderRadius.circular(18), child: InkWell(borderRadius: BorderRadius.circular(18), onTap: key == '⌫' ? onDelete : () => onDigit(key), child: Center(child: Text(key, style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w600)))));
      },
    );
  }
}

