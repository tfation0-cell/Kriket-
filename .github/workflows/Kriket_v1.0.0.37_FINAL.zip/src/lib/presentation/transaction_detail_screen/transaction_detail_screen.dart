import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../theme/app_theme.dart';
import '../../widgets/status_badge_widget.dart';

class TransactionDetailScreen extends StatelessWidget {
  final Map<String, dynamic> transaction;

  const TransactionDetailScreen({super.key, required this.transaction});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isCredit = transaction['isCredit'] as bool;
    final amount = transaction['amount'] as double;
    final statusStr = transaction['status'] as String;
    final name = transaction['name'] as String;
    final category = transaction['category'] as String? ?? '';
    final date = transaction['date'] as String;
    final avatarColor = transaction['avatarColor'] as int;
    final iconName = transaction['icon'] as String;

    final status = statusStr == 'pending'
        ? TransactionStatus.pending
        : statusStr == 'failed'
        ? TransactionStatus.failed
        : TransactionStatus.completed;

    // Derive sender/receiver from transaction direction
    final currentUserLabel = 'You';
    final counterpartyLabel = name;
    final senderLabel = isCredit ? counterpartyLabel : currentUserLabel;
    final receiverLabel = isCredit ? currentUserLabel : counterpartyLabel;

    // Fee breakdown (indicative — no real fee data in schema)
    final double fee = _estimateFee(amount, category);
    final double total = isCredit ? amount : amount + fee;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        backgroundColor: AppTheme.backgroundDark,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
          color: AppTheme.textPrimaryDark,
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'Transaction Details',
          style: GoogleFonts.manrope(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimaryDark,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined, size: 20),
            color: AppTheme.textSecondaryDark,
            onPressed: () =>
                _shareReceipt(context, name, amount, isCredit, date, statusStr),
            tooltip: 'Share receipt',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 8),

            // ── Hero amount card ──────────────────────────────────
            _HeroAmountCard(
              amount: amount,
              isCredit: isCredit,
              status: status,
              avatarColor: avatarColor,
              iconName: iconName,
              name: name,
              category: category,
            ),

            const SizedBox(height: 20),

            // ── Sender / Receiver ─────────────────────────────────
            _DetailCard(
              title: 'Transfer Details',
              children: [
                _DetailRow(
                  icon: Icons.person_outline_rounded,
                  label: 'From',
                  value: senderLabel,
                  iconColor: isCredit
                      ? AppTheme.success
                      : AppTheme.textSecondaryDark,
                ),
                _Divider(),
                _DetailRow(
                  icon: Icons.person_pin_outlined,
                  label: 'To',
                  value: receiverLabel,
                  iconColor: isCredit
                      ? AppTheme.textSecondaryDark
                      : AppTheme.primary,
                ),
                _Divider(),
                _DetailRow(
                  icon: Icons.category_outlined,
                  label: 'Category',
                  value: category.isEmpty ? 'Uncategorized' : category,
                  iconColor: AppTheme.secondary,
                ),
                _Divider(),
                _DetailRow(
                  icon: Icons.schedule_outlined,
                  label: 'Date & Time',
                  value: date,
                  iconColor: AppTheme.textSecondaryDark,
                ),
              ],
            ),

            const SizedBox(height: 16),

            // ── Fee breakdown ─────────────────────────────────────
            _DetailCard(
              title: 'Amount Breakdown',
              children: [
                _DetailRow(
                  icon: Icons.attach_money_rounded,
                  label: isCredit ? 'Amount Received' : 'Amount Sent',
                  value: '\$${_formatAmount(amount)}',
                  iconColor: isCredit
                      ? AppTheme.success
                      : AppTheme.textPrimaryDark,
                  valueStyle: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: isCredit
                        ? AppTheme.success
                        : AppTheme.textPrimaryDark,
                  ),
                ),
                _Divider(),
                _DetailRow(
                  icon: Icons.receipt_outlined,
                  label: 'Transaction Fee',
                  value: fee == 0.0 ? 'Free' : '\$${_formatAmount(fee)}',
                  iconColor: AppTheme.textSecondaryDark,
                  valueStyle: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: fee == 0.0
                        ? AppTheme.success
                        : AppTheme.textSecondaryDark,
                  ),
                ),
                _Divider(),
                _DetailRow(
                  icon: Icons.account_balance_wallet_outlined,
                  label: isCredit ? 'Total Credited' : 'Total Debited',
                  value: '\$${_formatAmount(total)}',
                  iconColor: AppTheme.primary,
                  valueStyle: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.primary,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // ── Transaction ID ────────────────────────────────────
            _DetailCard(
              title: 'Reference',
              children: [
                _TransactionIdRow(
                  transactionId: transaction['id'] as String? ?? '—',
                ),
              ],
            ),

            const SizedBox(height: 24),

            // ── Receipt button ────────────────────────────────────
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => _showReceiptSheet(
                  context,
                  name: name,
                  amount: amount,
                  isCredit: isCredit,
                  date: date,
                  status: statusStr,
                  category: category,
                  fee: fee,
                  total: total,
                  transactionId: transaction['id'] as String? ?? '—',
                ),
                icon: const Icon(Icons.receipt_long_outlined, size: 18),
                label: const Text('View Receipt'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.primary,
                  side: const BorderSide(color: AppTheme.primary),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  textStyle: GoogleFonts.manrope(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  double _estimateFee(double amount, String category) {
    // Indicative fee logic — transfers have small fee, income/salary is free
    final lower = category.toLowerCase();
    if (lower.contains('income') ||
        lower.contains('salary') ||
        lower.contains('transfer in')) {
      return 0.0;
    }
    if (amount > 1000) return (amount * 0.005).roundToDouble();
    if (amount > 100) return 0.99;
    return 0.0;
  }

  String _formatAmount(double amount) {
    if (amount >= 1000) {
      final parts = amount.toStringAsFixed(2).split('.');
      final intPart = parts[0];
      final buffer = StringBuffer();
      for (int i = 0; i < intPart.length; i++) {
        if (i > 0 && (intPart.length - i) % 3 == 0) buffer.write(',');
        buffer.write(intPart[i]);
      }
      return '$buffer.${parts[1]}';
    }
    return amount.toStringAsFixed(2);
  }

  void _shareReceipt(
    BuildContext context,
    String name,
    double amount,
    bool isCredit,
    String date,
    String status,
  ) {
    final text =
        'Kriket Transaction\n'
        '${isCredit ? 'Received from' : 'Sent to'}: $name\n'
        'Amount: \$${_formatAmount(amount)}\n'
        'Date: $date\n'
        'Status: $status';
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Receipt copied to clipboard',
          style: GoogleFonts.manrope(
            color: AppTheme.backgroundDark,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: AppTheme.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showReceiptSheet(
    BuildContext context, {
    required String name,
    required double amount,
    required bool isCredit,
    required String date,
    required String status,
    required String category,
    required double fee,
    required double total,
    required String transactionId,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _ReceiptSheet(
        name: name,
        amount: amount,
        isCredit: isCredit,
        date: date,
        status: status,
        category: category,
        fee: fee,
        total: total,
        transactionId: transactionId,
      ),
    );
  }
}

// ── Hero amount card ───────────────────────────────────────────────
class _HeroAmountCard extends StatelessWidget {
  final double amount;
  final bool isCredit;
  final TransactionStatus status;
  final int avatarColor;
  final String iconName;
  final String name;
  final String category;

  const _HeroAmountCard({
    required this.amount,
    required this.isCredit,
    required this.status,
    required this.avatarColor,
    required this.iconName,
    required this.name,
    required this.category,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF1E1E2A)),
      ),
      child: Column(
        children: [
          // Icon circle
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: Color(avatarColor).withAlpha(46),
              shape: BoxShape.circle,
            ),
            child: Icon(
              _iconFromName(iconName),
              color: Color(avatarColor),
              size: 28,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            name,
            style: GoogleFonts.manrope(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryDark,
            ),
            textAlign: TextAlign.center,
          ),
          if (category.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              category,
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: AppTheme.textSecondaryDark,
              ),
            ),
          ],
          const SizedBox(height: 16),
          Text(
            '${isCredit ? '+' : '-'}\$${_formatAmount(amount)}',
            style: GoogleFonts.manrope(
              fontSize: 32,
              fontWeight: FontWeight.w800,
              color: isCredit ? AppTheme.success : AppTheme.textPrimaryDark,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(height: 12),
          StatusBadgeWidget(status: status),
        ],
      ),
    );
  }

  String _formatAmount(double amount) {
    if (amount >= 1000) {
      final parts = amount.toStringAsFixed(2).split('.');
      final intPart = parts[0];
      final buffer = StringBuffer();
      for (int i = 0; i < intPart.length; i++) {
        if (i > 0 && (intPart.length - i) % 3 == 0) buffer.write(',');
        buffer.write(intPart[i]);
      }
      return '$buffer.${parts[1]}';
    }
    return amount.toStringAsFixed(2);
  }

  IconData _iconFromName(String name) {
    switch (name) {
      case 'arrow_downward_rounded':
        return Icons.arrow_downward_rounded;
      case 'arrow_upward_rounded':
        return Icons.arrow_upward_rounded;
      case 'play_circle_outline_rounded':
        return Icons.play_circle_outline_rounded;
      case 'mail_outline_rounded':
        return Icons.mail_outline_rounded;
      case 'business_center_outlined':
        return Icons.business_center_outlined;
      case 'shopping_cart_outlined':
        return Icons.shopping_cart_outlined;
      case 'bolt_rounded':
        return Icons.bolt_rounded;
      case 'directions_car_outlined':
        return Icons.directions_car_outlined;
      default:
        return Icons.receipt_long_outlined;
    }
  }
}

// ── Detail card container ──────────────────────────────────────────
class _DetailCard extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _DetailCard({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF1E1E2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Text(
              title,
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.textMutedDark,
                letterSpacing: 0.8,
              ),
            ),
          ),
          const SizedBox(height: 8),
          ...children,
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

// ── Single detail row ──────────────────────────────────────────────
class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color iconColor;
  final TextStyle? valueStyle;

  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.iconColor,
    this.valueStyle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: iconColor.withAlpha(26),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 16, color: iconColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: GoogleFonts.manrope(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppTheme.textSecondaryDark,
              ),
            ),
          ),
          Flexible(
            child: Text(
              value,
              style:
                  valueStyle ??
                  GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimaryDark,
                  ),
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Transaction ID row with copy ───────────────────────────────────
class _TransactionIdRow extends StatelessWidget {
  final String transactionId;

  const _TransactionIdRow({required this.transactionId});

  @override
  Widget build(BuildContext context) {
    final shortId = transactionId.length > 16
        ? '${transactionId.substring(0, 8)}...${transactionId.substring(transactionId.length - 8)}'
        : transactionId;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: AppTheme.secondary.withAlpha(26),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.tag_rounded, size: 16, color: AppTheme.secondary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Transaction ID',
              style: GoogleFonts.manrope(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppTheme.textSecondaryDark,
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: transactionId));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Transaction ID copied',
                    style: GoogleFonts.manrope(
                      color: AppTheme.backgroundDark,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  backgroundColor: AppTheme.primary,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  margin: const EdgeInsets.all(16),
                  duration: const Duration(seconds: 2),
                ),
              );
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  shortId,
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textSecondaryDark,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
                const SizedBox(width: 6),
                Icon(Icons.copy_rounded, size: 14, color: AppTheme.primary),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Divider ────────────────────────────────────────────────────────
class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Divider(
      height: 1,
      thickness: 1,
      color: Color(0xFF1E1E2A),
      indent: 16,
      endIndent: 16,
    );
  }
}

// ── Receipt bottom sheet ───────────────────────────────────────────
class _ReceiptSheet extends StatelessWidget {
  final String name;
  final double amount;
  final bool isCredit;
  final String date;
  final String status;
  final String category;
  final double fee;
  final double total;
  final String transactionId;

  const _ReceiptSheet({
    required this.name,
    required this.amount,
    required this.isCredit,
    required this.date,
    required this.status,
    required this.category,
    required this.fee,
    required this.total,
    required this.transactionId,
  });

  @override
  Widget build(BuildContext context) {
    final statusEnum = status == 'pending'
        ? TransactionStatus.pending
        : status == 'failed'
        ? TransactionStatus.failed
        : TransactionStatus.completed;

    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0xFF1E1E2A)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.textMutedDark,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),

          // Receipt header
          Text(
            'Receipt',
            style: GoogleFonts.manrope(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryDark,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Kriket · Indicative record',
            style: GoogleFonts.manrope(
              fontSize: 12,
              color: AppTheme.textMutedDark,
            ),
          ),
          const SizedBox(height: 20),

          // Dashed separator
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: List.generate(
                30,
                (i) => Expanded(
                  child: Container(
                    height: 1,
                    color: i.isEven
                        ? AppTheme.textMutedDark.withAlpha(80)
                        : Colors.transparent,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Receipt rows
          _ReceiptRow(label: isCredit ? 'From' : 'To', value: name),
          _ReceiptRow(
            label: 'Category',
            value: category.isEmpty ? 'Uncategorized' : category,
          ),
          _ReceiptRow(label: 'Date', value: date),
          _ReceiptRow(label: 'Amount', value: '\$${_fmt(amount)}'),
          _ReceiptRow(
            label: 'Fee',
            value: fee == 0.0 ? 'Free' : '\$${_fmt(fee)}',
          ),
          _ReceiptRow(
            label: isCredit ? 'Total Credited' : 'Total Debited',
            value: '\$${_fmt(total)}',
            highlight: true,
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Status',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    color: AppTheme.textSecondaryDark,
                  ),
                ),
                StatusBadgeWidget(status: statusEnum),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Dashed separator
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: List.generate(
                30,
                (i) => Expanded(
                  child: Container(
                    height: 1,
                    color: i.isEven
                        ? AppTheme.textMutedDark.withAlpha(80)
                        : Colors.transparent,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Transaction ID
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              'Ref: ${transactionId.length > 20 ? transactionId.substring(0, 20) + '...' : transactionId}',
              style: GoogleFonts.manrope(
                fontSize: 11,
                color: AppTheme.textMutedDark,
                letterSpacing: 0.3,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),

          // Close button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                style: FilledButton.styleFrom(
                  backgroundColor: AppTheme.primary,
                  foregroundColor: const Color(0xFF003322),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: Text(
                  'Close',
                  style: GoogleFonts.manrope(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  String _fmt(double v) {
    if (v >= 1000) {
      final parts = v.toStringAsFixed(2).split('.');
      final intPart = parts[0];
      final buffer = StringBuffer();
      for (int i = 0; i < intPart.length; i++) {
        if (i > 0 && (intPart.length - i) % 3 == 0) buffer.write(',');
        buffer.write(intPart[i]);
      }
      return '$buffer.${parts[1]}';
    }
    return v.toStringAsFixed(2);
  }
}

class _ReceiptRow extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;

  const _ReceiptRow({
    required this.label,
    required this.value,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 7),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.manrope(
              fontSize: 13,
              color: AppTheme.textSecondaryDark,
            ),
          ),
          Text(
            value,
            style: GoogleFonts.manrope(
              fontSize: 13,
              fontWeight: highlight ? FontWeight.w800 : FontWeight.w600,
              color: highlight ? AppTheme.primary : AppTheme.textPrimaryDark,
            ),
          ),
        ],
      ),
    );
  }
}
