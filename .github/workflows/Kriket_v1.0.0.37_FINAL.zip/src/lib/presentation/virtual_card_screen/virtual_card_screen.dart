import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../services/supabase_service.dart';
import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';

class VirtualCardScreen extends StatefulWidget {
  const VirtualCardScreen({super.key});
  @override
  State<VirtualCardScreen> createState() => _VirtualCardScreenState();
}

class _VirtualCardScreenState extends State<VirtualCardScreen> {
  bool loading = true;
  bool kycApproved = false;
  bool detailsVisible = false;
  bool onlinePayments = true;
  bool contactlessPayments = true;
  bool internationalPayments = true;
  bool frozen = false;
  String? error;
  String? cardId;
  String cardNumber = '';
  String lastFour = '----';
  String expiry = '••/••';
  String cvv = '•••';
  String holder = 'KRIKET USER';
  String network = 'VISA';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final client = SupabaseService.instance.client;
      final user = client.auth.currentUser;
      if (user == null) throw Exception('Please sign in.');

      final profile = await client
          .from('user_profiles')
          .select('kyc_status, full_name')
          .eq('id', user.id)
          .maybeSingle();
      final kyc = (profile?['kyc_status'] ?? '').toString().toLowerCase();
      if (!['approved', 'verified', 'completed'].contains(kyc)) {
        if (mounted) setState(() { kycApproved = false; loading = false; });
        return;
      }

      final name = (profile?['full_name'] ?? '').toString().trim();
      final local = await client
          .from('virtual_cards')
          .select('id, card_number, card_holder_name, expiry_month, expiry_year, cvv, card_network, is_frozen')
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (local != null) {
        final number = (local['card_number'] ?? '').toString();
        final last = number.length >= 4 ? number.substring(number.length - 4) : '----';
        final month = (local['expiry_month'] ?? '').toString();
        final year = (local['expiry_year'] ?? '').toString();
        if (mounted) setState(() {
          kycApproved = true;
          loading = false;
          cardId = local['id']?.toString();
          cardNumber = number;
          lastFour = last;
          holder = (local['card_holder_name'] ?? name).toString().toUpperCase();
          expiry = month.isNotEmpty && year.isNotEmpty ? '$month/$year' : '••/••';
          cvv = (local['cvv'] ?? '•••').toString();
          network = (local['card_network'] ?? 'VISA').toString().toUpperCase();
          frozen = local['is_frozen'] == true;
        });
        return;
      }

      final response = await client.functions.invoke('marqeta-card', body: {});
      final data = response.data;
      if (data is! Map || data['card'] is! Map) throw Exception('Card data is not available yet.');
      final card = Map<String, dynamic>.from(data['card'] as Map);
      if (mounted) setState(() {
        kycApproved = true;
        loading = false;
        holder = name.isNotEmpty ? name.toUpperCase() : holder;
        cardNumber = card['card_number']?.toString() ?? '';
        lastFour = card['last_four']?.toString() ?? '----';
        expiry = card['expiration']?.toString() ?? '••/••';
        cvv = card['cvv']?.toString() ?? '•••';
        network = (card['card_network'] ?? 'VISA').toString().toUpperCase();
        frozen = card['is_frozen'] == true;
      });
    } catch (e) {
      if (mounted) setState(() {
        loading = false;
        error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _toggleFrozen() async {
    final value = !frozen;
    try {
      if (cardId != null) {
        await SupabaseService.instance.client
            .from('virtual_cards')
            .update({'is_frozen': value})
            .eq('id', cardId!);
      }
      if (mounted) {
        setState(() => frozen = value);
        _message(value ? 'Card blocked' : 'Card unblocked');
      }
    } catch (_) {
      _message('Could not update card status.');
    }
  }

  void _message(String message) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _copy(String value, String label) {
    if (value.isEmpty) return;
    Clipboard.setData(ClipboardData(text: value));
    _message('$label copied');
  }

  String _formatCardNumber(String value) {
    final clean = value.replaceAll(RegExp(r'\s+'), '');
    final parts = <String>[];
    for (var i = 0; i < clean.length; i += 4) {
      parts.add(clean.substring(i, i + 4 > clean.length ? clean.length : i + 4));
    }
    return parts.join('  ');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080B0A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Cards'),
      ),
      body: SafeArea(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : !kycApproved
                ? _kyc()
                : error != null
                    ? Center(child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)))
                    : SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                        child: Column(children: [
                          _card(),
                          const SizedBox(height: 18),
                          Row(children: [
                            Expanded(child: FilledButton.icon(
                              onPressed: () => setState(() => detailsVisible = !detailsVisible),
                              icon: Icon(detailsVisible ? Icons.visibility_off_rounded : Icons.visibility_rounded),
                              label: Text(detailsVisible ? 'Hide details' : 'View details'),
                            )),
                            const SizedBox(width: 10),
                            Expanded(child: OutlinedButton.icon(
                              onPressed: _toggleFrozen,
                              icon: Icon(frozen ? Icons.lock_open_rounded : Icons.lock_outline_rounded),
                              label: Text(frozen ? 'Unblock card' : 'Block card'),
                            )),
                          ]),
                          const SizedBox(height: 18),
                          _controls(),
                        ]),
                      ),
      ),
    );
  }

  Widget _kyc() => Center(child: Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.verified_user_outlined, size: 64, color: Colors.white38),
      const SizedBox(height: 16),
      const Text('KYC verification is required', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w700), textAlign: TextAlign.center),
      const SizedBox(height: 18),
      ElevatedButton.icon(onPressed: () => context.push(AppRoutes.kyc), icon: const Icon(Icons.verified_user_outlined), label: const Text('Complete KYC')),
    ]),
  ));

  Widget _card() => AspectRatio(
    aspectRatio: 1.58,
    child: Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF001C14), Color(0xFF063B2A), Color(0xFF00120D)]),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset('assets/images/kriket_logo.png', width: 56, height: 56, fit: BoxFit.cover),
          ),
          const Spacer(),
          const Text('VIRTUAL DEBIT', style: TextStyle(fontSize: 10, letterSpacing: 1.5)),
        ]),
        const Spacer(),
        Row(children: [
          const Icon(Icons.contactless, color: Colors.white70, size: 28),
          const SizedBox(width: 10),
          if (frozen) const Text('BLOCKED', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
        ]),
        const SizedBox(height: 12),
        Text(detailsVisible && cardNumber.isNotEmpty ? _formatCardNumber(cardNumber) : '••••  ••••  ••••  $lastFour',
            style: const TextStyle(fontSize: 20, letterSpacing: 1.6)),
        const SizedBox(height: 12),
        Text(holder, style: const TextStyle(fontSize: 13, letterSpacing: 1.2)),
        const SizedBox(height: 6),
        Row(children: [
          Text(detailsVisible ? 'VALID THRU  $expiry   CVV $cvv' : 'VALID THRU  ••/••', style: const TextStyle(fontSize: 11)),
          const Spacer(),
          Text(network, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
        ]),
      ]),
    ),
  );

  Widget _controls() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: AppTheme.surfaceDark,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: const Color(0xFF2A2A3A)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Card controls', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      _switch('Online payments', 'Allow online card payments', onlinePayments, (v) => setState(() => onlinePayments = v)),
      _switch('Contactless', 'Allow contactless payments', contactlessPayments, (v) => setState(() => contactlessPayments = v)),
      _switch('International payments', 'Allow payments outside your home country', internationalPayments, (v) => setState(() => internationalPayments = v)),
      const Divider(height: 26),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.copy_rounded),
        title: const Text('Copy card number'),
        subtitle: Text(detailsVisible && cardNumber.isNotEmpty ? _formatCardNumber(cardNumber) : 'Reveal card details first'),
        onTap: detailsVisible && cardNumber.isNotEmpty ? () => _copy(cardNumber, 'Card number') : null,
      ),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.password_rounded),
        title: const Text('Copy CVV'),
        subtitle: const Text('Available when card details are revealed'),
        onTap: detailsVisible && cvv != '•••' ? () => _copy(cvv, 'CVV') : null,
      ),
    ]),
  );

  Widget _switch(String title, String subtitle, bool value, ValueChanged<bool> onChanged) => SwitchListTile(
    contentPadding: EdgeInsets.zero,
    title: Text(title),
    subtitle: Text(subtitle),
    value: value,
    onChanged: onChanged,
    activeThumbColor: AppTheme.primary,
  );
}
