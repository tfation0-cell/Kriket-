import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../theme/app_theme.dart';

class AccountSettingsScreen extends StatefulWidget {
  const AccountSettingsScreen({super.key});

  @override
  State<AccountSettingsScreen> createState() => _AccountSettingsScreenState();
}

class _AccountSettingsScreenState extends State<AccountSettingsScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _iban = TextEditingController();
  String _email = '—';
  bool _loading = true;
  bool _saving = false;
  bool _ibanConnected = false;

  SupabaseClient get _client => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _iban.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final user = _client.auth.currentUser;
    if (user == null) return;
    _email = user.email ?? '—';
    _name.text = (user.userMetadata?['full_name'] ?? '').toString();
    _phone.text = (user.userMetadata?['phone'] ?? '').toString();
    try {
      final row = await _client.from('user_profiles').select('full_name, phone, iban, email').eq('id', user.id).maybeSingle();
      if (row != null) {
        _name.text = (row['full_name'] ?? _name.text).toString();
        _phone.text = (row['phone'] ?? _phone.text).toString();
        _iban.text = (row['iban'] ?? '').toString();
        _ibanConnected = _iban.text.trim().isNotEmpty;
        _email = (row['email'] ?? _email).toString();
      } else {
        _ibanConnected = false;
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    final user = _client.auth.currentUser;
    if (user == null || _saving) return;
    final name = _name.text.trim();
    final phone = _phone.text.trim();
    final iban = _iban.text.trim().replaceAll(' ', '').toUpperCase();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Emri nuk mund të jetë bosh.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await _client.auth.updateUser(UserAttributes(data: {'full_name': name, 'phone': phone}));
      await _client.from('user_profiles').upsert({
        'id': user.id,
        'email': user.email,
        'full_name': name,
        'phone': phone,
        'iban': iban,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Të dhënat u ruajtën.')));
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Nuk u ruajtën: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _dec(String label, IconData icon, {String? hint}) => InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: Icon(icon, color: AppTheme.primary),
    filled: true,
    fillColor: AppTheme.surfaceVariantDark,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFF2A2A3A))),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: AppTheme.primary)),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(title: const Text('Të dhënat e llogarisë'), backgroundColor: AppTheme.backgroundDark, elevation: 0),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
              children: [
                const Text('Të dhënat personale', style: TextStyle(fontFamily: 'Manrope', fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.textPrimaryDark)),
                const SizedBox(height: 14),
                TextField(controller: _name, style: const TextStyle(color: Colors.white), decoration: _dec('Emri i plotë', Icons.person_outline_rounded)),
                const SizedBox(height: 12),
                TextField(controller: _phone, keyboardType: TextInputType.phone, style: const TextStyle(color: Colors.white), decoration: _dec('Numri i telefonit', Icons.phone_outlined)),
                const SizedBox(height: 12),
                TextField(controller: TextEditingController(text: _email), readOnly: true, style: const TextStyle(color: AppTheme.textMutedDark), decoration: _dec('Email', Icons.email_outlined)),
                const SizedBox(height: 26),
                const Text('Llogari bankare', style: TextStyle(fontFamily: 'Manrope', fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.textPrimaryDark)),
                const SizedBox(height: 14),
                TextField(
                  controller: _iban,
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.characters,
                  style: const TextStyle(color: Colors.white),
                  decoration: _dec('IBAN', Icons.account_balance_rounded, hint: 'GR00 0000 0000 0000 0000 0000 000'),
                  onChanged: (value) => setState(() => _ibanConnected = value.trim().isNotEmpty),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(_ibanConnected ? Icons.verified_rounded : Icons.link_rounded, size: 18, color: _ibanConnected ? Colors.greenAccent : AppTheme.primary),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _ibanConnected ? 'IBAN i lidhur' : 'Lidh IBAN-in tënd',
                        style: TextStyle(fontFamily: 'Manrope', fontSize: 13, fontWeight: FontWeight.w700, color: _ibanConnected ? Colors.greenAccent : AppTheme.textMutedDark),
                      ),
                    ),
                    if (_ibanConnected)
                      TextButton.icon(
                        onPressed: () async {
                          final value = _iban.text.trim().replaceAll(' ', '').toUpperCase();
                          await Clipboard.setData(ClipboardData(text: value));
                          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('IBAN-i u kopjua.')));
                        },
                        icon: const Icon(Icons.copy_rounded, size: 17),
                        label: const Text('Kopjo'),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text('Kur IBAN-i jepet nga partneri bankar, ai mund të ruhet këtu dhe të shfaqet si IBAN-i yt i lidhur. Mos përdor IBAN demo.', style: TextStyle(fontFamily: 'Manrope', fontSize: 12, height: 1.45, color: AppTheme.textMutedDark)),
                const SizedBox(height: 28),
                SizedBox(height: 52, child: ElevatedButton.icon(onPressed: _saving ? null : _save, icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded), label: const Text('Ruaj ndryshimet'))),
              ],
            ),
    );
  }
}
