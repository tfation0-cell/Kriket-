import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme/app_theme.dart';
import '../../providers/app_providers.dart';
import '../../l10n/app_strings.dart';

class SpendingAnalyticsScreen extends StatefulWidget {
  const SpendingAnalyticsScreen({super.key});

  @override
  State<SpendingAnalyticsScreen> createState() =>
      _SpendingAnalyticsScreenState();
}

class _SpendingAnalyticsScreenState extends State<SpendingAnalyticsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _touchedIndex = -1;

  List<Map<String, dynamic>> _categories = [];
  bool _loading = true;
  String? _error;
  double _thisMonthTotal = 0;
  double _lastMonthTotal = 0;

  List<Map<String, dynamic>> _monthlyData = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadAnalytics();
  }

  Future<void> _loadAnalytics() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) { setState(() { _loading = false; _error = 'Please sign in.'; }); return; }
    try {
      final rows = await Supabase.instance.client
          .from('transactions')
          .select('name, category, amount, is_credit, status, transaction_date')
          .eq('user_id', userId)
          .eq('status', 'completed')
          .eq('is_credit', false)
          .order('transaction_date', ascending: true);
      final now = DateTime.now();
      final monthStart = DateTime(now.year, now.month);
      final lastStart = DateTime(now.year, now.month - 1);
      final byCategory = <String, double>{};
      final byMonth = <String, double>{};
      for (final raw in rows) {
        final date = DateTime.tryParse(raw['transaction_date']?.toString() ?? '')?.toLocal();
        final amount = (raw['amount'] as num?)?.toDouble() ?? double.tryParse(raw['amount']?.toString() ?? '') ?? 0;
        if (date == null || amount <= 0) continue;
        if (date.year == now.year && date.month == now.month) {
          final key = (raw['category']?.toString().trim().isNotEmpty == true) ? raw['category'].toString() : 'Other';
          byCategory[key] = (byCategory[key] ?? 0) + amount;
        }
        if (!date.isBefore(lastStart) && date.isBefore(monthStart)) _lastMonthTotal += amount;
        if (!date.isBefore(monthStart)) _thisMonthTotal += amount;
        final key = '${date.year}-${date.month.toString().padLeft(2, '0')}';
        byMonth[key] = (byMonth[key] ?? 0) + amount;
      }
      final iconMap = <String, IconData>{
        'food': Icons.restaurant_rounded, 'food and drink': Icons.restaurant_rounded,
        'transport': Icons.directions_car_rounded, 'shopping': Icons.shopping_bag_rounded,
        'utilities': Icons.bolt_rounded, 'entertainment': Icons.movie_rounded,
      };
      final categories = byCategory.entries.map((e) {
        final key = e.key.toLowerCase();
        return {'label': e.key, 'amount': e.value, 'color': AppTheme.primary, 'icon': iconMap[key] ?? Icons.more_horiz_rounded};
      }).toList()..sort((a,b) => (b['amount'] as double).compareTo(a['amount'] as double));
      final months = <Map<String,dynamic>>[];
      final first = DateTime(now.year, now.month - 5);
      for (var i=0; i<6; i++) {
        final d = DateTime(first.year, first.month + i);
        final key='${d.year}-${d.month.toString().padLeft(2,'0')}';
        months.add({'month': _monthLabel(d.month), 'amount': byMonth[key] ?? 0.0});
      }
      if (!mounted) return;
      setState(() { _categories = categories; _monthlyData = months; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = 'Unable to load analytics.'; });
    }
  }

  String _monthLabel(int month) {
    const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return names[month - 1];
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  double get _totalSpending => _thisMonthTotal;

  @override
  Widget build(BuildContext context) {
    final locale = context.watch<LocaleProvider>().languageCode;
    final isDark = context.watch<ThemeProvider>().isDark;
    final bg = isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight;
    final surface = isDark ? AppTheme.surfaceVariantDark : Colors.white;
    final textPrimary = isDark
        ? AppTheme.textPrimaryDark
        : const Color(0xFF1A1A2E);
    final textSecondary = isDark
        ? AppTheme.textSecondaryDark
        : const Color(0xFF6B7280);

    if (_loading) return Scaffold(backgroundColor: bg, body: const Center(child: CircularProgressIndicator(color: AppTheme.primary)));
    if (_error != null) return Scaffold(backgroundColor: bg, body: Center(child: Text(_error!, style: TextStyle(color: textPrimary))));

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new_rounded,
            color: textPrimary,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          AppStrings.get('analytics', locale),
          style: TextStyle(
            fontFamily: 'Manrope',
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: textPrimary,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primary,
          labelColor: AppTheme.primary,
          unselectedLabelColor: textSecondary,
          labelStyle: const TextStyle(
            fontFamily: 'Manrope',
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
          tabs: [
            Tab(text: AppStrings.get('spending_overview', locale)),
            Tab(text: AppStrings.get('this_month', locale)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildPieTab(locale, isDark, bg, surface, textPrimary, textSecondary),
          _buildBarTab(locale, isDark, surface, textPrimary, textSecondary),
        ],
      ),
    );
  }

  Widget _buildPieTab(
    String locale,
    bool isDark,
    Color bg,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      child: Column(
        children: [
          // Total spending card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A3A2A), Color(0xFF0D2E40)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.primary.withAlpha(40)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.get('this_month', locale),
                        style: const TextStyle(
                          fontFamily: 'Manrope',
                          color: AppTheme.textSecondaryDark,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '€${_totalSpending.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontFamily: 'Manrope',
                          color: AppTheme.textPrimaryDark,
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(
                            Icons.trending_up_rounded,
                            color: AppTheme.primary,
                            size: 14,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            (_lastMonthTotal <= 0 ? '—' : '${((_thisMonthTotal - _lastMonthTotal) / _lastMonthTotal * 100).toStringAsFixed(0)}% vs last month'),
                            style: const TextStyle(
                              fontFamily: 'Manrope',
                              color: AppTheme.primary,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withAlpha(30),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(
                    Icons.bar_chart_rounded,
                    color: AppTheme.primary,
                    size: 28,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          // Pie chart
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isDark
                    ? const Color(0xFF2A2A3A)
                    : const Color(0xFFE5E7EB),
              ),
            ),
            child: Column(
              children: [
                Text(
                  AppStrings.get('spending_overview', locale),
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    color: textPrimary,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 200,
                  child: PieChart(
                    PieChartData(
                      pieTouchData: PieTouchData(
                        touchCallback: (event, response) {
                          setState(() {
                            if (!event.isInterestedForInteractions ||
                                response == null ||
                                response.touchedSection == null) {
                              _touchedIndex = -1;
                              return;
                            }
                            _touchedIndex =
                                response.touchedSection!.touchedSectionIndex;
                          });
                        },
                      ),
                      sections: _categories.asMap().entries.map((entry) {
                        final i = entry.key;
                        final cat = entry.value;
                        final isTouched = i == _touchedIndex;
                        final pct =
                            (cat['amount'] as double) / _totalSpending * 100;
                        return PieChartSectionData(
                          color: cat['color'] as Color,
                          value: cat['amount'] as double,
                          title: isTouched ? '${pct.toStringAsFixed(1)}%' : '',
                          radius: isTouched ? 70 : 55,
                          titleStyle: const TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        );
                      }).toList(),
                      centerSpaceRadius: 50,
                      sectionsSpace: 2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Category breakdown
          ...(_categories.map((cat) {
            final pct = (cat['amount'] as double) / _totalSpending;
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isDark
                        ? const Color(0xFF2A2A3A)
                        : const Color(0xFFE5E7EB),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: (cat['color'] as Color).withAlpha(30),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        cat['icon'] as IconData,
                        color: cat['color'] as Color,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            AppStrings.get(cat['label'] as String, locale),
                            style: TextStyle(
                              fontFamily: 'Manrope',
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                              color: textPrimary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: pct,
                              backgroundColor: isDark
                                  ? const Color(0xFF2A2A3A)
                                  : const Color(0xFFE5E7EB),
                              valueColor: AlwaysStoppedAnimation<Color>(
                                cat['color'] as Color,
                              ),
                              minHeight: 4,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '€${(cat['amount'] as double).toStringAsFixed(0)}',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList()),
        ],
      ),
    );
  }

  Widget _buildBarTab(
    String locale,
    bool isDark,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isDark
                    ? const Color(0xFF2A2A3A)
                    : const Color(0xFFE5E7EB),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppStrings.get('monthly_trend', locale),
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    color: textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Last 6 months',
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 12,
                    color: textSecondary,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 200,
                  child: BarChart(
                    BarChartData(
                      alignment: BarChartAlignment.spaceAround,
                      maxY: 1600,
                      barTouchData: BarTouchData(
                        touchTooltipData: BarTouchTooltipData(
                          tooltipBgColor: AppTheme.surfaceVariantDark,
                          getTooltipItem: (group, groupIndex, rod, rodIndex) {
                            return BarTooltipItem(
                              '€${rod.toY.toStringAsFixed(0)}',
                              const TextStyle(
                                fontFamily: 'Manrope',
                                color: AppTheme.primary,
                                fontWeight: FontWeight.w700,
                              ),
                            );
                          },
                        ),
                      ),
                      titlesData: FlTitlesData(
                        show: true,
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              final idx = value.toInt();
                              if (idx < 0 || idx >= _monthlyData.length) {
                                return const SizedBox();
                              }
                              return Text(
                                _monthlyData[idx]['month'] as String,
                                style: TextStyle(
                                  fontFamily: 'Manrope',
                                  fontSize: 11,
                                  color: textSecondary,
                                ),
                              );
                            },
                          ),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 40,
                            getTitlesWidget: (value, meta) {
                              return Text(
                                '€${value.toInt()}',
                                style: TextStyle(
                                  fontFamily: 'Manrope',
                                  fontSize: 10,
                                  color: textSecondary,
                                ),
                              );
                            },
                          ),
                        ),
                        topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                        rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                      ),
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        getDrawingHorizontalLine: (_) => FlLine(
                          color: isDark
                              ? const Color(0xFF2A2A3A)
                              : const Color(0xFFE5E7EB),
                          strokeWidth: 1,
                        ),
                      ),
                      borderData: FlBorderData(show: false),
                      barGroups: _monthlyData.asMap().entries.map((entry) {
                        return BarChartGroupData(
                          x: entry.key,
                          barRods: [
                            BarChartRodData(
                              toY: entry.value['amount'] as double,
                              gradient: const LinearGradient(
                                colors: [AppTheme.primary, Color(0xFF00A875)],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                              ),
                              width: 20,
                              borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(6),
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Stats row
          Row(
            children: [
              Expanded(
                child: _statCard(
                  'Avg/Month',
                  '€1,103',
                  Icons.calendar_month_rounded,
                  isDark,
                  surface,
                  textPrimary,
                  textSecondary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _statCard(
                  'Highest',
                  '€1,340',
                  Icons.arrow_upward_rounded,
                  isDark,
                  surface,
                  textPrimary,
                  textSecondary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _statCard(
                  'Lowest',
                  '€890',
                  Icons.arrow_downward_rounded,
                  isDark,
                  surface,
                  textPrimary,
                  textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statCard(
    String label,
    String value,
    IconData icon,
    bool isDark,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? const Color(0xFF2A2A3A) : const Color(0xFFE5E7EB),
        ),
      ),
      child: Column(
        children: [
          Icon(icon, color: AppTheme.primary, size: 20),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontFamily: 'Manrope',
              fontWeight: FontWeight.w700,
              fontSize: 14,
              color: textPrimary,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 10,
              color: textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
