import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../routes/app_routes.dart';
import '../services/pin_service.dart';
import '../theme/app_theme.dart';

class PinSetupScreen extends StatefulWidget {
  const PinSetupScreen({super.key});

  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  int _length = 6;
  String _pin = '';
  String _confirm = '';
  bool _confirming = false;
  String? _error;

  void _addDigit(String digit) {
    if (_confirming) {
      if (_confirm.length >= _length) return;
      setState(() {
        _confirm += digit;
        _error = null;
      });
      if (_confirm.length == _length) _finish();
    } else {
      if (_pin.length >= _length) return;
      setState(() {
        _pin += digit;
        _error = null;
      });
      if (_pin.length == _length) {
        setState(() => _confirming = true);
      }
    }
  }

  void _removeDigit() {
    setState(() {
      if (_confirming && _confirm.isNotEmpty) {
        _confirm = _confirm.substring(0, _confirm.length - 1);
      } else if (!_confirming && _pin.isNotEmpty) {
        _pin = _pin.substring(0, _pin.length - 1);
      }
      _error = null;
    });
  }

  Future<void> _finish() async {
    if (_confirm != _pin) {
      setState(() {
        _error = 'Codes do not match. Try again.';
        _confirm = '';
      });
      return;
    }
    await PinService.instance.setPin(_pin);
    if (mounted) context.go(AppRoutes.home);
  }

  Widget _dots(String value) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(_length, (i) {
          final filled = i < value.length;
          return Container(
            width: 14,
            height: 14,
            margin: const EdgeInsets.symmetric(horizontal: 7),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: filled ? AppTheme.primary : const Color(0xFF26343A),
              border: Border.all(
                color: filled ? AppTheme.primary : const Color(0xFF40515A),
              ),
            ),
          );
        }),
      );

  @override
  Widget build(BuildContext context) {
    final title = _confirming ? 'Confirm your code' : 'Create your code';
    final value = _confirming ? _confirm : _pin;
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Image.asset('assets/images/kriket_logo.png', width: 82, height: 82, fit: BoxFit.cover),
            ),
            const SizedBox(height: 24),
            Text(title, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(
              _confirming ? 'Enter the same $_length-digit code again' : 'Choose a 4 or 6 digit code for quick access',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondaryDark),
            ),
            const SizedBox(height: 28),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 4, label: Text('4 digits')),
                ButtonSegment(value: 6, label: Text('6 digits')),
              ],
              selected: {_length},
              onSelectionChanged: _confirming ? null : (s) => setState(() { _length = s.first; _pin = ''; }),
            ),
            const SizedBox(height: 30),
            _dots(value),
            if (_error != null) ...[
              const SizedBox(height: 18),
              Text(_error!, style: const TextStyle(color: AppTheme.error)),
            ],
            const Spacer(),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 0, 28, 28),
              child: _Keypad(onDigit: _addDigit, onDelete: _removeDigit),
            ),
          ],
        ),
      ),
    );
  }
}

class _Keypad extends StatelessWidget {
  final ValueChanged<String> onDigit;
  final VoidCallback onDelete;
  const _Keypad({required this.onDigit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final keys = ['1','2','3','4','5','6','7','8','9','', '0', '⌫'];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: keys.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.55),
      itemBuilder: (_, i) {
        final key = keys[i];
        if (key.isEmpty) return const SizedBox.shrink();
        return Material(
          color: const Color(0xFF172229),
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: key == '⌫' ? onDelete : () => onDigit(key),
            child: Center(child: Text(key, style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w600))),
          ),
        );
      },
    );
  }
}
