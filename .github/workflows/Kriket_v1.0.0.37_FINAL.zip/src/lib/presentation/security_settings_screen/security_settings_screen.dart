import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:qr/qr.dart';
import '../../services/kriket_mfa_service.dart';

import '../../theme/app_theme.dart';
import '../../providers/app_providers.dart';
import '../../l10n/app_strings.dart';
import '../../services/email_service.dart';
import '../../services/biometric_service.dart';

class SecuritySettingsScreen extends StatefulWidget {
  const SecuritySettingsScreen({super.key});

  @override
  State<SecuritySettingsScreen> createState() => _SecuritySettingsScreenState();
}

class _SecuritySettingsScreenState extends State<SecuritySettingsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _twoFaEnabled = false;
  bool _smsAuth = true;
  bool _appAuth = false;
  bool _loading2FA = false;

  // Biometric state
  bool _biometricEnabled = false;
  bool _biometricAvailable = false;
  bool _loadingBiometric = false;

  final List<Map<String, dynamic>> _trustedDevices = [
    {
      'name': 'iPhone 15 Pro',
      'location': 'Tirana, Albania',
      'lastSeen': '2 hours ago',
      'current': true,
      'icon': Icons.phone_iphone_rounded,
    },
    {
      'name': 'MacBook Pro',
      'location': 'Tirana, Albania',
      'lastSeen': '1 day ago',
      'current': false,
      'icon': Icons.laptop_mac_rounded,
    },
    {
      'name': 'iPad Air',
      'location': 'Thessaloniki, Greece',
      'lastSeen': '5 days ago',
      'current': false,
      'icon': Icons.tablet_mac_rounded,
    },
  ];

  final List<Map<String, dynamic>> _loginHistory = [
    {
      'device': 'iPhone 15 Pro',
      'location': 'Tirana, Albania',
      'time': 'Today, 14:32',
      'success': true,
      'ip': '185.x.x.x',
    },
    {
      'device': 'MacBook Pro',
      'location': 'Tirana, Albania',
      'time': 'Yesterday, 09:15',
      'success': true,
      'ip': '185.x.x.x',
    },
    {
      'device': 'Unknown Device',
      'location': 'Sofia, Bulgaria',
      'time': '3 days ago, 22:41',
      'success': false,
      'ip': '92.x.x.x',
    },
    {
      'device': 'iPad Air',
      'location': 'Thessaloniki, Greece',
      'time': '5 days ago, 11:20',
      'success': true,
      'ip': '94.x.x.x',
    },
    {
      'device': 'iPhone 15 Pro',
      'location': 'Tirana, Albania',
      'time': '7 days ago, 08:05',
      'success': true,
      'ip': '185.x.x.x',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadPrefs();
    _loadBiometricState();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _twoFaEnabled = prefs.getBool('2fa_enabled') ?? false;
      _smsAuth = prefs.getBool('2fa_sms') ?? true;
      _appAuth = prefs.getBool('2fa_app') ?? false;
    });
  }

  Future<void> _loadBiometricState() async {
    final available = await BiometricService.instance.isAvailable();
    final enabled = await BiometricService.instance.isEnabled();
    if (!mounted) return;
    setState(() {
      _biometricAvailable = available;
      _biometricEnabled = enabled;
    });
  }

  Future<void> _toggleBiometric(bool value) async {
    if (_loadingBiometric) return;
    setState(() => _loadingBiometric = true);

    try {
      if (value) {
        // Require biometric auth to confirm enabling
        final confirmed = await BiometricService.instance.authenticate(
          reason: 'Confirm your identity to enable biometric login',
        );
        if (!confirmed) {
          if (mounted) setState(() => _loadingBiometric = false);
          return;
        }

        // Store the current session tokens for biometric-protected retrieval
        final session = Supabase.instance.client.auth.currentSession;
        if (session != null) {
          await BiometricService.instance.storeBiometricSession(
            accessToken: session.accessToken,
            refreshToken: session.refreshToken ?? '',
          );
        }

        await BiometricService.instance.setEnabled(true);
        // Update the provider so other parts of the app reflect the change
        if (mounted) {
          context.read<BiometricProvider>().setBiometric(true);
        }
      } else {
        await BiometricService.instance.setEnabled(false);
        if (mounted) {
          context.read<BiometricProvider>().setBiometric(false);
        }
      }

      if (!mounted) return;
      setState(() {
        _biometricEnabled = value;
        _loadingBiometric = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loadingBiometric = false);
    }
  }

  Future<void> _setupAuthenticator() async {
    if (_loading2FA) return;
    setState(() => _loading2FA = true);
    try {
      final enrolled = await KriketMfaService.enroll();
      final factorId = enrolled.id;
      final totp = enrolled.totp;
      final uri = totp?.uri ?? '';
      final secret = totp?.secret ?? '';
      if (factorId == null || secret.isEmpty) throw StateError('Authenticator setup data was not returned.');
      if (!mounted) return;
      final controller = TextEditingController();
      final verified = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Set up Authenticator'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (uri.isNotEmpty)
                  Container(width: 210, height: 210, padding: const EdgeInsets.all(12), color: Colors.white, child: CustomPaint(painter: _TotpQrPainter(uri))),
                const SizedBox(height: 12),
                const Text('Scan this QR code with Google Authenticator.', textAlign: TextAlign.center),
                const SizedBox(height: 12),
                SelectableText(secret, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                const SizedBox(height: 16),
                TextField(controller: controller, keyboardType: TextInputType.number, maxLength: 6, autofocus: true, decoration: const InputDecoration(labelText: '6-digit code')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
            FilledButton(onPressed: () async {
              final code = controller.text.trim();
              if (code.length != 6) return;
              try {
                await KriketMfaService.verifyEnrollment(factorId: factorId, code: code);
                if (dialogContext.mounted) Navigator.pop(dialogContext, true);
              } catch (_) {
                if (dialogContext.mounted) ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(content: Text('Invalid authenticator code.')));
              }
            }, child: const Text('Verify')),
          ],
        ),
      );
      if (verified == true) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('2fa_app', true);
        if (mounted) setState(() => _appAuth = true);
      } else {
        try { await KriketMfaService.unenroll(factorId); } catch (_) {}
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Authenticator setup failed: $e')));
    } finally {
      if (mounted) setState(() => _loading2FA = false);
    }
  }

  Future<void> _toggle2FA(bool value) async {
    setState(() => _loading2FA = true);
    await Future.delayed(const Duration(milliseconds: 800));
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('2fa_enabled', value);
    if (!mounted) return;
    setState(() {
      _twoFaEnabled = value;
      _loading2FA = false;
    });

    // Send security alert email when 2FA is toggled
    try {
      final user = Supabase.instance.client.auth.currentUser;
      final userEmail = user?.email;
      final userName = user?.userMetadata?['full_name'] as String? ?? 'there';
      if (userEmail != null) {
        EmailService.instance.sendSecurityAlertEmail(
          to: userEmail,
          name: userName,
          device: 'Your device',
          location: 'Account settings',
        );
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final locale = context.watch<LocaleProvider>().languageCode;
    final isDark = context.watch<ThemeProvider>().isDark;
    final bg = isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight;
    final surface = isDark ? AppTheme.surfaceVariantDark : Colors.white;
    final textPrimary = isDark
        ? AppTheme.textPrimaryDark
        : const Color(0xFF1A1A2E);
    final textSecondary = isDark
        ? AppTheme.textSecondaryDark
        : const Color(0xFF6B7280);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new_rounded,
            color: textPrimary,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          AppStrings.get('security', locale),
          style: TextStyle(
            fontFamily: 'Manrope',
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: textPrimary,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primary,
          labelColor: AppTheme.primary,
          unselectedLabelColor: textSecondary,
          labelStyle: const TextStyle(
            fontFamily: 'Manrope',
            fontWeight: FontWeight.w600,
            fontSize: 12,
          ),
          tabs: [
            Tab(text: AppStrings.get('two_fa', locale).split(' ').first),
            Tab(
              text: AppStrings.get('trusted_devices', locale).split(' ').first,
            ),
            Tab(text: AppStrings.get('login_history', locale).split(' ').first),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _build2FATab(locale, isDark, surface, textPrimary, textSecondary),
          _buildTrustedDevicesTab(
            locale,
            isDark,
            surface,
            textPrimary,
            textSecondary,
          ),
          _buildLoginHistoryTab(
            locale,
            isDark,
            surface,
            textPrimary,
            textSecondary,
          ),
        ],
      ),
    );
  }

  Widget _build2FATab(
    String locale,
    bool isDark,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      child: Column(
        children: [
          // 2FA status card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _twoFaEnabled
                    ? [const Color(0xFF1A3A2A), const Color(0xFF0D2E40)]
                    : [const Color(0xFF2A1A1A), const Color(0xFF1A0D0D)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: (_twoFaEnabled ? AppTheme.primary : AppTheme.error)
                    .withAlpha(40),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: (_twoFaEnabled ? AppTheme.primary : AppTheme.error)
                        .withAlpha(30),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    _twoFaEnabled
                        ? Icons.shield_rounded
                        : Icons.shield_outlined,
                    color: _twoFaEnabled ? AppTheme.primary : AppTheme.error,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.get('two_fa', locale),
                        style: const TextStyle(
                          fontFamily: 'Manrope',
                          color: AppTheme.textPrimaryDark,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _twoFaEnabled
                            ? AppStrings.get('two_fa_enabled', locale)
                            : AppStrings.get('two_fa_desc', locale),
                        style: TextStyle(
                          fontFamily: 'Manrope',
                          color: _twoFaEnabled
                              ? AppTheme.primary
                              : AppTheme.error,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                _loading2FA
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.primary,
                        ),
                      )
                    : Switch(
                        value: _twoFaEnabled,
                        onChanged: _toggle2FA,
                        activeThumbColor: AppTheme.primary,
                      ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          // Biometric Login section (only shown if device supports it)
          if (_biometricAvailable) ...[
            Text(
              'Biometric Login',
              style: TextStyle(
                fontFamily: 'Manrope',
                fontWeight: FontWeight.w700,
                fontSize: 16,
                color: textPrimary,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _biometricEnabled
                      ? AppTheme.primary.withAlpha(80)
                      : (isDark
                            ? const Color(0xFF2A2A3A)
                            : const Color(0xFFE5E7EB)),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withAlpha(20),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.fingerprint_rounded,
                      color: AppTheme.primary,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Biometric Login',
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: textPrimary,
                          ),
                        ),
                        Text(
                          _biometricEnabled
                              ? 'Fingerprint / Face ID active'
                              : 'Use fingerprint or Face ID to sign in',
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 12,
                            color: _biometricEnabled
                                ? AppTheme.primary
                                : textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _loadingBiometric
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppTheme.primary,
                          ),
                        )
                      : Switch(
                          value: _biometricEnabled,
                          onChanged: _toggleBiometric,
                          activeThumbColor: AppTheme.primary,
                        ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
          // Auth methods
          Text(
            AppStrings.get('two_fa', locale),
            style: TextStyle(
              fontFamily: 'Manrope',
              fontWeight: FontWeight.w700,
              fontSize: 16,
              color: textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          _authMethodTile(
            Icons.sms_rounded,
            AppStrings.get('sms_auth', locale),
            'Receive a code via SMS',
            _smsAuth,
            (v) async {
              setState(() => _smsAuth = v);
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('2fa_sms', v);
            },
            isDark,
            surface,
            textPrimary,
            textSecondary,
          ),
          const SizedBox(height: 8),
          _authMethodTile(
            Icons.qr_code_rounded,
            AppStrings.get('app_auth', locale),
            'Use Google Authenticator or similar',
            _appAuth,
            (v) async {
              if (v) {
                await _setupAuthenticator();
              } else {
                final factors = await KriketMfaService.verifiedTotpFactors();
                if (factors.isNotEmpty) {
                  await KriketMfaService.unenroll(factors.first.id);
                }
                final prefs = await SharedPreferences.getInstance();
                await prefs.setBool('2fa_app', false);
                if (mounted) setState(() => _appAuth = false);
              }
            },
            isDark,
            surface,
            textPrimary,
            textSecondary,
          ),
          const SizedBox(height: 20),
          // Security tips
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.primary.withAlpha(10),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primary.withAlpha(40)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.lightbulb_rounded,
                      color: AppTheme.primary,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Security Tips',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: textPrimary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                ...[
                  'Enable 2FA for maximum account security',
                  'Never share your OTP codes with anyone',
                  'Use a strong, unique password',
                  'Review login history regularly',
                ].map(
                  (tip) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '• ',
                          style: TextStyle(
                            color: AppTheme.primary,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Expanded(
                          child: Text(
                            tip,
                            style: TextStyle(
                              fontFamily: 'Manrope',
                              fontSize: 12,
                              color: textSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _authMethodTile(
    IconData icon,
    String title,
    String subtitle,
    bool value,
    ValueChanged<bool> onChanged,
    bool isDark,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? const Color(0xFF2A2A3A) : const Color(0xFFE5E7EB),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.primary.withAlpha(20),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: AppTheme.primary, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: textPrimary,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 12,
                    color: textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: AppTheme.primary,
          ),
        ],
      ),
    );
  }

  Widget _buildTrustedDevicesTab(
    String locale,
    bool isDark,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      itemCount: _trustedDevices.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final device = _trustedDevices[index];
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: device['current'] as bool
                  ? AppTheme.primary.withAlpha(60)
                  : (isDark
                        ? const Color(0xFF2A2A3A)
                        : const Color(0xFFE5E7EB)),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color:
                      (device['current'] as bool
                              ? AppTheme.primary
                              : textSecondary)
                          .withAlpha(20),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  device['icon'] as IconData,
                  color: device['current'] as bool
                      ? AppTheme.primary
                      : textSecondary,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          device['name'] as String,
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: textPrimary,
                          ),
                        ),
                        if (device['current'] as bool) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withAlpha(30),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              AppStrings.get('current_device', locale),
                              style: const TextStyle(
                                fontFamily: 'Manrope',
                                color: AppTheme.primary,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${device['location']} • ${device['lastSeen']}',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 12,
                        color: textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              if (!(device['current'] as bool))
                TextButton(
                  onPressed: () {
                    setState(() => _trustedDevices.removeAt(index));
                  },
                  child: Text(
                    AppStrings.get('remove', locale),
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      color: AppTheme.error,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLoginHistoryTab(
    String locale,
    bool isDark,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      itemCount: _loginHistory.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final login = _loginHistory[index];
        final success = login['success'] as bool;
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: success
                  ? (isDark ? const Color(0xFF2A2A3A) : const Color(0xFFE5E7EB))
                  : AppTheme.error.withAlpha(60),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: (success ? AppTheme.success : AppTheme.error)
                      .withAlpha(20),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  success ? Icons.check_circle_rounded : Icons.cancel_rounded,
                  color: success ? AppTheme.success : AppTheme.error,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      login['device'] as String,
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${login['location']} • IP: ${login['ip']}',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 12,
                        color: textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    success
                        ? AppStrings.get('success', locale)
                        : AppStrings.get('failed', locale),
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: success ? AppTheme.success : AppTheme.error,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    login['time'] as String,
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 10,
                      color: textSecondary,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}


class _TotpQrPainter extends CustomPainter {
  final String data;
  _TotpQrPainter(this.data);
  @override
  void paint(Canvas canvas, Size size) {
    final code = QrCode(4, QrErrorCorrectLevel.M)..addData(data);
    final image = QrImage(code);
    final modules = image.moduleCount;
    final cell = size.shortestSide / modules;
    final dark = Paint()..color = Colors.black;
    for (var y = 0; y < modules; y++) {
      for (var x = 0; x < modules; x++) {
        if (image.isDark(y, x)) canvas.drawRect(Rect.fromLTWH(x * cell, y * cell, cell + .2, cell + .2), dark);
      }
    }
  }
  @override bool shouldRepaint(covariant _TotpQrPainter oldDelegate) => oldDelegate.data != data;
}
