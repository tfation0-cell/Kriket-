import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../theme/app_theme.dart';

/// Functional user-to-support chat backed by Supabase support_messages.
/// Admin replies are rows with is_user=false and are visible only to the
/// authenticated user who owns the conversation.
class LiveSupportChatScreen extends StatefulWidget {
  const LiveSupportChatScreen({super.key});

  @override
  State<LiveSupportChatScreen> createState() => _LiveSupportChatScreenState();
}

class _LiveSupportChatScreenState extends State<LiveSupportChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  Timer? _pollTimer;
  List<Map<String, dynamic>> _messages = [];
  bool _loading = true;
  bool _sending = false;
  String? _error;

  SupabaseClient get _client => Supabase.instance.client;
  String? get _userId => _client.auth.currentUser?.id;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _loadMessages(silent: true));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadMessages({bool silent = false}) async {
    final userId = _userId;
    if (userId == null) return;
    try {
      final rows = await _client
          .from('support_messages')
          .select('id, user_id, message, is_user, created_at')
          .eq('user_id', userId)
          .order('created_at', ascending: true);
      if (!mounted) return;
      setState(() {
        _messages = List<Map<String, dynamic>>.from(rows);
        if (!silent) _loading = false;
        _error = null;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    } catch (e) {
      if (!mounted) return;
      if (!silent) setState(() { _loading = false; _error = 'Unable to load support messages.'; });
    }
  }

  void _scrollToBottom() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
    );
  }

  Future<void> _send() async {
    final userId = _userId;
    final text = _controller.text.trim();
    if (userId == null || text.isEmpty || _sending) return;

    setState(() => _sending = true);
    try {
      await _client.from('support_messages').insert({
        'user_id': userId,
        'message': text,
        'is_user': true,
      });
      _controller.clear();
      await _loadMessages();
    } catch (e) {
      if (mounted) setState(() => _error = 'Message could not be sent. Please try again.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  String _time(dynamic value) {
    final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
    if (date == null) return '';
    final h = date.hour.toString().padLeft(2, '0');
    final m = date.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        title: Row(children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: const Color(0xFF12352C),
            child: ClipOval(
              child: Image.asset(
                'assets/images/kriket_support_final.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Center(
                  child: Text('F', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800, fontSize: 16)),
                ),
              ),
            ),
          ),
          SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Fation · Live Support', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            Text('Support team · We are here to help', style: TextStyle(fontSize: 11, color: AppTheme.textSecondaryDark)),
          ]),
        ]),
        backgroundColor: const Color(0xFF0A0A0F),
        elevation: 0,
      ),
      body: Column(
        children: [
          if (_error != null)
            Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(16, 8, 16, 0), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppTheme.errorContainer, borderRadius: BorderRadius.circular(12)), child: Text(_error!, style: const TextStyle(color: AppTheme.error, fontSize: 12))),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
                : _messages.isEmpty
                    ? const _EmptySupportState()
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
                        itemCount: _messages.length,
                        itemBuilder: (_, i) {
                          final m = _messages[i];
                          final isUser = m['is_user'] == true;
                          return Align(
                            alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .80),
                              margin: const EdgeInsets.only(bottom: 10),
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                              decoration: BoxDecoration(
                                color: isUser ? AppTheme.primary : const Color(0xFF18242A),
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
                                  bottomLeft: Radius.circular(isUser ? 16 : 4), bottomRight: Radius.circular(isUser ? 4 : 16),
                                ),
                              ),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                                Align(alignment: Alignment.centerLeft, child: Text(m['message']?.toString() ?? '', style: TextStyle(color: isUser ? const Color(0xFF003322) : Colors.white, fontSize: 15, height: 1.3))),
                                const SizedBox(height: 4),
                                Text(_time(m['created_at']), style: TextStyle(color: isUser ? const Color(0xFF145A44) : AppTheme.textMutedDark, fontSize: 10)),
                              ]),
                            ),
                          );
                        },
                      ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(children: [
                Expanded(child: TextField(
                  controller: _controller,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.newline,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(hintText: 'Type a message...', filled: true, fillColor: const Color(0xFF18242A), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)),
                )),
                const SizedBox(width: 8),
                Material(color: AppTheme.primary, shape: const CircleBorder(), child: IconButton(onPressed: _sending ? null : _send, icon: _sending ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF003322))) : const Icon(Icons.send_rounded, color: Color(0xFF003322)))),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptySupportState extends StatelessWidget {
  const _EmptySupportState();
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircleAvatar(
          radius: 34,
          backgroundColor: const Color(0xFF12352C),
          child: ClipOval(
            child: Image.asset(
              'assets/images/kriket_support_final.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Text(
                'F',
                style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800, fontSize: 28),
              ),
            ),
          ),
        ),
        SizedBox(height: 18),
        Text('Si mund të të ndihmoj?', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
        SizedBox(height: 8),
        Text('Dërgo një mesazh dhe Fation ose ekipi i support-it do të përgjigjet këtu.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondaryDark, height: 1.4)),
      ]),
    ),
  );
}
