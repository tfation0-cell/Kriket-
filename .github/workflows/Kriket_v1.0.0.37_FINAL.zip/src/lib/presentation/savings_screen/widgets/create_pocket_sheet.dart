import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../theme/app_theme.dart';
import '../../../services/supabase_service.dart';

class CreatePocketSheet extends StatefulWidget {
  final void Function(Map<String, dynamic> pocket) onCreate;

  const CreatePocketSheet({super.key, required this.onCreate});

  @override
  State<CreatePocketSheet> createState() => _CreatePocketSheetState();
}

class _CreatePocketSheetState extends State<CreatePocketSheet> {
  final _nameController = TextEditingController();
  final _targetController = TextEditingController();
  final _deadlineController = TextEditingController();
  String _selectedEmoji = '🎯';
  bool _isCreating = false;
  String? _errorMessage;

  final List<String> _emojis = [
    '🎯',
    '💻',
    '🌴',
    '🚗',
    '🏠',
    '✈️',
    '🛡️',
    '💍',
    '📚',
    '🎓',
    '🎸',
    '🏋️',
    '🐶',
    '👶',
    '🎮',
    '💎',
  ];

  SupabaseClient get _client => SupabaseService.instance.client;

  @override
  void dispose() {
    _nameController.dispose();
    _targetController.dispose();
    _deadlineController.dispose();
    super.dispose();
  }

  Future<void> _handleCreate() async {
    if (_nameController.text.trim().isEmpty ||
        _targetController.text.trim().isEmpty) {
      return;
    }
    final double? target = double.tryParse(
      _targetController.text.replaceAll(',', ''),
    );
    if (target == null || target <= 0) return;

    setState(() {
      _isCreating = true;
      _errorMessage = null;
    });

    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) {
        setState(() {
          _isCreating = false;
          _errorMessage = 'Not signed in';
        });
        return;
      }

      final deadline = _deadlineController.text.trim().isEmpty
          ? 'No deadline'
          : _deadlineController.text.trim();

      final response = await _client
          .from('savings_pockets')
          .insert({
            'user_id': userId,
            'name': _nameController.text.trim(),
            'emoji': _selectedEmoji,
            'target_amount': target,
            'saved_amount': 0.0,
            'color': 4278255776,
            'deadline': deadline,
          })
          .select()
          .single();

      final pocket = {
        'id': response['id'] as String,
        'name': response['name'] as String,
        'emoji': response['emoji'] as String,
        'targetAmount': (response['target_amount'] as num).toDouble(),
        'savedAmount': (response['saved_amount'] as num).toDouble(),
        'color': (response['color'] as num).toInt(),
        'deadline': response['deadline'] as String,
        'contributions': <Map<String, dynamic>>[],
      };

      if (mounted) {
        setState(() => _isCreating = false);
        widget.onCreate(pocket);
      }
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() {
          _isCreating = false;
          _errorMessage = e.message;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isCreating = false;
          _errorMessage = 'Failed to create pocket. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28.0)),
      ),
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 32,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A3A),
                borderRadius: BorderRadius.circular(100.0),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'New Savings Pocket',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryDark,
            ),
          ),
          if (_errorMessage != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.error.withAlpha(25),
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(color: AppTheme.error.withAlpha(80)),
              ),
              child: Text(
                _errorMessage!,
                style: const TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 13,
                  color: AppTheme.error,
                ),
              ),
            ),
          ],
          const SizedBox(height: 20),
          const Text(
            'Choose an icon',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryDark,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _emojis.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final emoji = _emojis[index];
                final isSelected = emoji == _selectedEmoji;
                return GestureDetector(
                  onTap: () {
                    HapticFeedback.selectionClick();
                    setState(() => _selectedEmoji = emoji);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.primaryContainer
                          : AppTheme.surfaceVariantDark,
                      borderRadius: BorderRadius.circular(14.0),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.primary
                            : const Color(0xFF2A2A3A),
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: Center(
                      child: Text(emoji, style: const TextStyle(fontSize: 22)),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          _buildTextField(
            controller: _nameController,
            label: 'Pocket name',
            hint: 'e.g. New iPhone, Dream Vacation',
          ),
          const SizedBox(height: 14),
          _buildTextField(
            controller: _targetController,
            label: 'Target amount (\$)',
            hint: 'e.g. 5000',
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 14),
          _buildTextField(
            controller: _deadlineController,
            label: 'Deadline (optional)',
            hint: 'e.g. Dec 2026',
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _isCreating ? null : _handleCreate,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                foregroundColor: const Color(0xFF003322),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
                elevation: 0,
              ),
              child: _isCreating
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Color(0xFF003322),
                      ),
                    )
                  : const Text(
                      'Create Pocket',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontFamily: 'Manrope',
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppTheme.textSecondaryDark,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: const TextStyle(
            fontFamily: 'Manrope',
            fontSize: 15,
            color: AppTheme.textPrimaryDark,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(
              fontFamily: 'Manrope',
              fontSize: 14,
              color: AppTheme.textMutedDark,
            ),
            filled: true,
            fillColor: AppTheme.surfaceVariantDark,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14.0),
              borderSide: const BorderSide(color: Color(0xFF2A2A3A)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14.0),
              borderSide: const BorderSide(color: Color(0xFF2A2A3A)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14.0),
              borderSide: const BorderSide(color: AppTheme.primary, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
}
