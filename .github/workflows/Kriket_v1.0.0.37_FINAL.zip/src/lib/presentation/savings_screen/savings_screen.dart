import 'dart:async';
import '../../services/native_security_service.dart';
import '../../services/kriket_i18n.dart';
import '../../services/savings/kriket_wallet_api.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/savings/kriket_morpho_usdc_api.dart';
import '../../services/kriket_mfa_service.dart';
import '../../../services/supabase_service.dart';
import '../../../services/savings/kriket_savings_api.dart';
import '../../../services/savings/aave_base_api.dart';
import '../../l10n/app_strings.dart';
import '../../providers/app_providers.dart';
import '../../theme/app_theme.dart';
import './models/savings_models.dart';
import './savings_pocket_detail_screen.dart';
import './widgets/create_pocket_sheet.dart';
import './widgets/savings_pocket_card_widget.dart';


class SavingsScreen extends StatefulWidget {
  const SavingsScreen({super.key});

  @override
  State<SavingsScreen> createState() => _SavingsScreenState();
}

class _SavingsScreenState extends State<SavingsScreen> {
  final Map<String, double> _kriketCatalogApy = {};

  Future<void> _loadKriketCatalogApy() async {
    const slugs = <String>[
      'eurc-savings',
      'eure-savings',
      'zchf-savings',
      'usdc-savings',
      'usdt-savings',
      'gbp-savings',
    ];
    final next = <String, double>{};
    for (final slug in slugs) {
      try {
        final response = await SupabaseService.instance.client.functions.invoke(
          'savings-api',
          body: <String, dynamic>{
            'action': 'product_position',
            'slug': slug,
          },
        );
        final data = response.data;
        if (data is Map) {
          final product = data['product'];
          final savings = data['savings'];
          final raw = product is Map
              ? product['effective_apy']
              : savings is Map
                  ? savings['apy']
                  : null;
          final apy = raw is num
              ? raw.toDouble()
              : double.tryParse(raw?.toString() ?? '');
          if (apy != null && apy >= 0) {
            next[slug] = apy;
          }
        }
      } catch (_) {
        // Keep APY — if a live protocol adapter is unavailable.
      }
    }
    if (mounted) {
      setState(() {
        _kriketCatalogApy
          ..clear()
          ..addAll(next);
      });
    }
  }

  String _kriketCatalogApyText(String asset, String fallback) {
    final slug = switch (asset) {
      'EURC' => 'eurc-savings',
      'EURe' => 'eure-savings',
      'ZCHF' => 'zchf-savings',
      'USDC' => 'usdc-savings',
      'USDT' => 'usdt-savings',
      'GBPe' => 'gbp-savings',
      _ => null,
    };
    final value = slug == null ? null : _kriketCatalogApy[slug];
    return value == null ? fallback : 'APY ' + value.toStringAsFixed(2) + '%';
  }


  List<SavingsPocket> _pockets = [];
  bool _isLoading = true;
  String? _errorMessage;
  final AaveBaseApi _kriketAaveApi = AaveBaseApi();
  double? _kriketLiveApy;
  bool _kriketApyLoading = true;
  final KriketSavingsApi _kriketSavingsApi = KriketSavingsApi();
  double _kriketSavingsBalance = 0;
  double _kriketSavingsYield = 0;
  String _kriketSavingsStatus = 'active';
  bool _kriketSavingsLoading = true;
  final KriketWalletApi _kriketWalletApi = KriketWalletApi();
  String? _kriketWalletAddress;
  bool _kriketWalletLoading = true;
  bool _kriketLiveDataStarted = false;
  Timer? _kriketLiveRefreshTimer;
  Timer? _kriketLiveTickerTimer;
  DateTime? _kriketPositionSyncedAt;
  double _kriketSyncedBalance = 0;
  bool _kriketLiveRefreshInFlight = false;
  String? _kriketSavingsError;
  double _kriketWalletEurcBalance = 0;
  double _kriketWalletEthBalance = 0;
  List<Map<String, dynamic>> _kriketSavingsHistory = [];
  bool _kriketHistoryLoading = false;

  // APY values are placeholders until the real provider APIs are connected.
  final List<_SavingsProduct> _bankProducts = const [
    _SavingsProduct(
      title: 'Euro',
      subtitle: 'EUR',
      apy: '—',
      icon: Icons.euro_rounded,
      kind: _SavingsProductKind.bank,
    ),
    _SavingsProduct(
      title: 'Pound',
      subtitle: 'GBP',
      apy: '—',
      icon: Icons.currency_pound_rounded,
      kind: _SavingsProductKind.bank,
    ),
    _SavingsProduct(
      title: 'Dollar',
      subtitle: 'USD',
      apy: '—',
      icon: Icons.attach_money_rounded,
      kind: _SavingsProductKind.bank,
    ),
  ];

  final List<_SavingsProduct> _defiProducts = const [
    _SavingsProduct(
      title: 'Aave',
      subtitle: 'DeFi',
      apy: 'Live',
      icon: Icons.account_balance_rounded,
      kind: _SavingsProductKind.defi,
    ),
    _SavingsProduct(
      title: 'Morpho',
      subtitle: 'DeFi',
      apy: 'Live',
      icon: Icons.auto_graph_rounded,
      kind: _SavingsProductKind.defi,
    ),
    _SavingsProduct(
      title: 'Spark',
      subtitle: 'DeFi',
      apy: 'Live',
      icon: Icons.bolt_rounded,
      kind: _SavingsProductKind.defi,
    ),
  ];

  SupabaseClient get _client => SupabaseService.instance.client;

  @override
  void initState() {
    _loadKriketCatalogApy();
    super.initState();
    _loadPockets();
    _loadKriketSavingsApy();
  }

  Future<void> _loadKriketWallet() async {
    try {
      final wallet = await _kriketWalletApi.getOrCreateWallet();
      if (!mounted) return;
      setState(() {
        _kriketWalletAddress = wallet.address;
        _kriketWalletLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _kriketWalletLoading = false);
    }
  }

  Future<void> _loadKriketSavingsPosition() async {
    if (_kriketLiveRefreshInFlight) return;
    _kriketLiveRefreshInFlight = true;
    try {
      final position = await _kriketSavingsApi.getPosition();
      if (!mounted) return;
      setState(() {
        _kriketSavingsBalance = position.balance;
        _kriketSyncedBalance = position.balance;
        _kriketPositionSyncedAt = DateTime.now();
        _kriketSavingsYield = position.accruedYield;
        _kriketSavingsStatus = position.status;
        _kriketLiveApy = position.apy;
        _kriketWalletEurcBalance = position.walletEurcBalance;
        _kriketWalletEthBalance = position.walletEthBalance;
        _kriketApyLoading = false;
        _kriketSavingsLoading = false;
        _kriketSavingsError = null;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _kriketSavingsLoading = false;
          _kriketApyLoading = false;
          _kriketSavingsError = e.toString();
        });
      }
    } finally {
      _kriketLiveRefreshInFlight = false;
    }
  }

  void _startKriketLiveRefresh() {
    _kriketLiveRefreshTimer?.cancel();
    _kriketLiveTickerTimer?.cancel();
    _kriketLiveTickerTimer?.cancel();
    _kriketLiveRefreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) _loadKriketSavingsPosition();
    });
    // Render accrued yield every second from the last server-synced position.
    // This keeps the displayed balance smooth without pretending that the
    // blockchain/backend is queried once per second.
    _kriketLiveTickerTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _kriketPositionSyncedAt == null || _kriketLiveApy == null) return;
      final elapsed = DateTime.now().difference(_kriketPositionSyncedAt!).inMilliseconds / 1000.0;
      final annualRate = _kriketLiveApy! / 100.0;
      final live = _kriketSyncedBalance * (1 + annualRate * elapsed / 31557600.0);
      if (live.isFinite && live >= 0) setState(() => _kriketSavingsBalance = live);
    });
  }

  Future<void> _loadKriketSavingsHistory() async {
    if (_kriketHistoryLoading) return;
    setState(() => _kriketHistoryLoading = true);
    try {
      final rows = await _kriketSavingsApi.getHistory();
      if (mounted) setState(() { _kriketSavingsHistory = rows; _kriketHistoryLoading = false; });
    } catch (_) { if (mounted) setState(() => _kriketHistoryLoading = false); }
  }

  Future<void> _refreshKriketLiveData() async {
    await _loadKriketSavingsPosition();
  }

  Future<void> _loadKriketSavingsApy() async {
    _loadKriketWallet();
    _loadKriketSavingsPosition();
    try {
      final reserves = await _kriketAaveApi.getReserves();
      final eligible = reserves.where((r) =>
          r.isActive &&
          (r.symbol.toUpperCase() == 'EURC')).toList();
      if (!mounted) return;
      setState(() {
        _kriketLiveApy = eligible.isEmpty ? null : eligible.first.supplyApy;
        _kriketApyLoading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _kriketLiveApy = null;
          _kriketApyLoading = false;
        });
      }
    }
  }

  Future<void> _loadPockets() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) {
        final locale = context.read<LocaleProvider>().languageCode;
        setState(() {
          _isLoading = false;
          _errorMessage = AppStrings.get('not_signed_in', locale);
        });
        return;
      }

      final response = await _client
          .from('savings_pockets')
          .select('*, pocket_contributions(*)')
          .eq('user_id', userId)
          .order('created_at', ascending: false);

      final pockets = (response as List<dynamic>)
          .map((p) => SavingsPocket.fromJson(p as Map<String, dynamic>))
          .toList();

      if (mounted) {
        setState(() {
          _pockets = pockets;
          _isLoading = false;
        });
      }
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = e.message;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = e.toString();
        });
      }
    }
  }

  double get _totalSaved => _pockets.fold(0.0, (sum, p) => sum + p.savedAmount);
  double get _totalTarget =>
      _pockets.fold(0.0, (sum, p) => sum + p.targetAmount);

  void _openCreateSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => CreatePocketSheet(
        onCreate: (pocket) async {
          Navigator.of(context).pop();
          await _loadPockets();
        },
      ),
    );
  }

  void _openPocketDetail(int index) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, animation, __) => SavingsPocketDetailScreen(
          pocket: _pockets[index].toDisplayMap(),
          pocketId: _pockets[index].id,
          onContributionAdded: (_) => _loadPockets(),
        ),
        transitionDuration: const Duration(milliseconds: 280),
        transitionsBuilder: (_, animation, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(1.0, 0),
            end: Offset.zero,
          ).animate(
            CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
          ),
          child: FadeTransition(opacity: animation, child: child),
        ),
      ),
    );
  }

  void _showProductInfo(_SavingsProduct product) {
    final isDefi = product.kind == _SavingsProductKind.defi;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
        decoration: const BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFF30303C),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  _ProductIcon(product: product, large: true),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          product.title,
                          style: const TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.textPrimaryDark,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          isDefi ? 'Kursime DeFi' : 'Kursime Bankare',
                          style: const TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 13,
                            color: AppTheme.textMutedDark,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceVariantDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFF2A2A3A)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'APY aktual',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 13,
                        color: AppTheme.textSecondaryDark,
                      ),
                    ),
                    Text(
                      product.apy == 'Live' ? 'Nga API' : product.apy,
                      style: const TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                isDefi
                    ? 'Norma do të merret nga API-ja e ofruesit dhe do të ndryshojë sipas tregut. Depozitat reale aktivizohen vetëm pasi të lidhet infrastruktura përkatëse.'
                    : 'Norma bankare do të vijë nga partneri financiar. Kjo kartë është gati për integrimin e ardhshëm.',
                style: const TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 13,
                  height: 1.45,
                  color: AppTheme.textMutedDark,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primary,
                    foregroundColor: const Color(0xFF003322),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  child: const Text(
                    'Shiko detajet',
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  @override
  void dispose() {
    _kriketLiveRefreshTimer?.cancel();
    _kriketLiveTickerTimer?.cancel();
    super.dispose();
  }

  Widget build(BuildContext context) {
    if (!_kriketLiveDataStarted) {
      _kriketLiveDataStarted = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _loadKriketWallet();
        _loadKriketSavingsPosition();
        _loadKriketSavingsHistory();
        _startKriketLiveRefresh();
      });
    }
    final locale = context.watch<LocaleProvider>().languageCode;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: SafeArea(
        bottom: false,
        child: _isLoading
            ? _buildLoadingState()
            : _errorMessage != null
                ? _buildErrorState(locale)
                : RefreshIndicator(
                    color: AppTheme.primary,
                    backgroundColor: AppTheme.surfaceDark,
                    onRefresh: _loadPockets,
                    child: CustomScrollView(
                      physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics(),
                      ),
                      slivers: [
                        SliverToBoxAdapter(child: _buildHeader(locale)),
                        SliverToBoxAdapter(child: _buildSummaryCard()),
                        const SliverToBoxAdapter(child: SizedBox(height: 26)),
                        SliverToBoxAdapter(child: _buildSectionTitle(
                          'Kursime Bankare',
                          'EUR • GBP • USD',
                        )),
                        const SliverToBoxAdapter(child: SizedBox(height: 12)),
                        SliverToBoxAdapter(
                          child: _buildProductsRow(_bankProducts),
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 26)),
                        SliverToBoxAdapter(child: _buildSectionTitle(
                          'Kriket Savings',
                          'Norma live',
                        )),
                        const SliverToBoxAdapter(child: SizedBox(height: 12)),
                        SliverToBoxAdapter(child: _buildKriketWalletCard()),
                        const SliverToBoxAdapter(child: SizedBox(height: 10)),
                        SliverToBoxAdapter(child: _buildKriketProductsCatalog()),
                        const SliverToBoxAdapter(child: SizedBox(height: 30)),
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  AppStrings.get('my_pockets', locale),
                                  style: const TextStyle(
                                    fontFamily: 'Manrope',
                                    fontSize: 17,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.textPrimaryDark,
                                  ),
                                ),
                                Text(
                                  '${_pockets.length} ${AppStrings.get('active', locale)}',
                                  style: const TextStyle(
                                    fontFamily: 'Manrope',
                                    fontSize: 13,
                                    color: AppTheme.textMutedDark,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 14)),
                        _pockets.isEmpty
                            ? SliverToBoxAdapter(child: _buildEmptyState(locale))
                            : SliverList(
                                delegate: SliverChildBuilderDelegate(
                                  (context, index) => Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                      20, 0, 20, 12,
                                    ),
                                    child: SavingsPocketCardWidget(
                                      pocket: _pockets[index].toDisplayMap(),
                                      onTap: () => _openPocketDetail(index),
                                    ),
                                  ),
                                  childCount: _pockets.length,
                                ),
                              ),
                        const SliverToBoxAdapter(child: SizedBox(height: 120)),
                      ],
                    ),
                  ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openCreateSheet,
        backgroundColor: AppTheme.primary,
        foregroundColor: const Color(0xFF003322),
        elevation: 0,
        icon: const Icon(Icons.add_rounded, size: 20),
        label: const Text(
          'Krijo qëllim',
          style: TextStyle(
            fontFamily: 'Manrope',
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(String locale) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            AppStrings.get('savings', locale),
            style: const TextStyle(
              fontFamily: 'Manrope',
              fontSize: 28,
              fontWeight: FontWeight.w800,
              color: AppTheme.textPrimaryDark,
            ),
          ),
          const SizedBox(height: 3),
          const Text(
            'Kursime bankare dhe DeFi, në një vend',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 13,
              color: AppTheme.textMutedDark,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A3A2A), Color(0xFF0D2E40)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppTheme.primary.withAlpha(40)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Totali i Kursyer',
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textSecondaryDark,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    '\$${_formatLargeAmount(_totalSaved)}',
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimaryDark,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    _pockets.isEmpty
                        ? 'Krijo ose zgjidh një kursim'
                        : 'Në qëllimet e tua',
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 12,
                      color: AppTheme.textMutedDark,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: AppTheme.primaryContainer,
                borderRadius: BorderRadius.circular(17),
              ),
              child: const Icon(
                Icons.savings_rounded,
                color: AppTheme.primary,
                size: 27,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppTheme.textPrimaryDark,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            subtitle,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontFamily: 'Manrope',
              fontSize: 11,
              color: AppTheme.textMutedDark,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _kriketSavingsAction(bool deposit) async {
    final controller = TextEditingController();
    final available = deposit ? _kriketWalletEurcBalance : _kriketSavingsBalance;
    final amount = await showDialog<double>(
      context: context,
      builder: (dialogContext) {
        double value = 0;
        return StatefulBuilder(builder: (context, setState) => AlertDialog(
          title: Text(deposit ? 'Deposit to Savings' : 'Withdraw to Account'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (v) => setState(() {}), decoration: InputDecoration(labelText: 'EURC', helperText: 'Available: ' + available.toStringAsFixed(2))),
            const SizedBox(height: 10),
            Text('APY: ' + (_kriketLiveApy ?? 0).toStringAsFixed(2) + '%'),
            const SizedBox(height: 4),
            const Text('Network fee: Base gas is paid separately in ETH', style: TextStyle(fontSize: 11)),
            const SizedBox(height: 8),
            Text('Final amount: ' + (double.tryParse(controller.text) ?? 0).toStringAsFixed(2) + ' EURC'),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            FilledButton(onPressed: () { final v = double.tryParse(controller.text.trim()) ?? 0; if (v > 0 && v <= available) Navigator.pop(context, v); }, child: const Text('Continue')),
          ],
        ));
      },
    );
    if (amount == null || !mounted) return;
    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      builder: (context) {
        double progress = 0;
        return StatefulBuilder(builder: (context, setState) => Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(deposit ? 'Confirm deposit' : 'Confirm withdrawal', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(amount.toStringAsFixed(2) + ' EURC'),
            Slider(value: progress, onChanged: (v) { setState(() => progress = v); if (v >= 1) Navigator.pop(context, true); }),
            const Text('Swipe the slider to confirm'),
            const SizedBox(height: 12),
          ]),
        ));
      },
    );
    if (confirmed != true || !mounted) return;
    setState(() => _kriketSavingsLoading = true);
    try {
      final txId = await _kriketSavingsApi.execute(deposit ? 'deposit' : 'withdraw', amount);
      String status = 'pending';
      for (var i = 0; i < 15 && mounted; i++) {
        await Future.delayed(const Duration(seconds: 2));
        final tx = await _kriketSavingsApi.syncDetailed(txId);
        status = tx['status']?.toString() ?? 'pending';
        if (status == 'confirmed' || status == 'finalized' || status == 'failed' || status == 'execution_reverted' || status == 'reverted' || status == 'cancelled') break;
      }
      if (!mounted) return;
      await Future.wait([_loadKriketSavingsPosition(), _loadKriketSavingsHistory()]);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(status == 'confirmed' || status == 'finalized' ? 'Transaction confirmed' : 'Status: ' + status)));
    } catch (e) {
      if (mounted) { setState(() => _kriketSavingsLoading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
    }
  }

  Widget _buildKriketWalletCard() {
    final wallet = _kriketWalletAddress;
    final address = _kriketWalletLoading
        ? 'Duke hapur wallet…'
        : (wallet == null || wallet.isEmpty ? 'Wallet unavailable' : wallet);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xFF2A2A3A)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: AppTheme.primaryContainer,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(Icons.account_balance_wallet_rounded, color: AppTheme.primary),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('Kriket Wallet',
                  style: TextStyle(fontFamily: 'Manrope', fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimaryDark)),
              ),
              const Text('BASE',
                style: TextStyle(fontFamily: 'Manrope', fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.primary)),
            ]),
            const SizedBox(height: 12),
            SelectableText(address, maxLines: 2,
              style: const TextStyle(fontFamily: 'Manrope', fontSize: 11, color: AppTheme.textMutedDark)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _kriketWalletChip('EURC', _kriketWalletEurcBalance.toStringAsFixed(2))),
              const SizedBox(width: 8),
              Expanded(child: _kriketWalletChip('ETH', _kriketWalletEthBalance.toStringAsFixed(5))),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _kriketWalletChip(String symbol, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF15151F),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        Expanded(child: Text(symbol, style: const TextStyle(fontFamily: 'Manrope', fontSize: 11, color: AppTheme.textMutedDark))),
        Text(value, style: const TextStyle(fontFamily: 'Manrope', fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textPrimaryDark)),
      ]),
    );
  }


  Future<Map<String, double>> _loadKriketCatalogApyFallback() async {
    final rows = await SupabaseService.instance.client
        .from('financial_products')
        .select('slug, apy')
        .order('sort_order');
    final result = <String, double>{};
    for (final row in rows) {
      final slug = row['slug']?.toString();
      final value = row['apy'];
      final apy = value is num ? value.toDouble() : double.tryParse(value?.toString() ?? '');
      if (slug != null && apy != null && apy > 0) result[slug] = apy;
    }
    return result;
  }

  String _kriketApyText(Map<String, double> apys, String slug) {
    final apy = apys[slug];
    return apy == null ? 'APY —' : 'APY ' + apy.toStringAsFixed(2) + '%';
  }

  Widget _buildKriketProductCard({
    required String asset,
    required String network,
    required String protocol,
    required String apy,
    required String balance,
    required String notes,
    bool depositEnabled = false,
    bool withdrawEnabled = false,
  }) {
    final actionStyle = Theme.of(context).textTheme.labelLarge;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    asset + ' Savings',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Text(_kriketCatalogApyText(asset, apy), style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 6),
            Text(network + ' • ' + protocol),
            const SizedBox(height: 8),
            Text('Balanca: ' + balance),
            const SizedBox(height: 10),
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              childrenPadding: EdgeInsets.zero,
              title: const Text('Shënime / Kushtet'),
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(notes),
                ),
                const SizedBox(height: 8),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: depositEnabled ? () => _kriketCatalogAction(asset, true) : null,
                    child: Text('Deposit', style: actionStyle),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: withdrawEnabled ? () => _kriketCatalogAction(asset, false) : null,
                    child: Text('Withdraw', style: actionStyle),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _kriketCatalogAction(String asset, bool deposit) async {
    if (asset == 'EURC') {
      await _kriketSavingsAction(deposit);
      return;
    }
    if (asset == 'USDC') {
      await _kriketMorphoUsdcAction(deposit);
      return;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$asset is available for rates/position display, but its execution adapter is not configured yet.')),
      );
    }
  }

  Widget _buildKriketProductsCatalog() {
    return FutureBuilder<Map<String, double>>(
      future: _loadKriketCatalogApyFallback(),
      builder: (context, snapshot) {
        final apys = snapshot.data ?? const <String, double>{};
        final loading = snapshot.connectionState == ConnectionState.waiting;
        final apy = (String slug) => loading ? 'APY —' : _kriketApyText(apys, slug);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Kriket Savings', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            _buildKriketProductCard(
              asset: 'EURC', network: 'Base', protocol: 'Aave V3',
              apy: apy('eurc-savings'),
              balance: _kriketSavingsBalance.toStringAsFixed(2) + ' EURC',
              depositEnabled: !_kriketSavingsLoading, withdrawEnabled: !_kriketSavingsLoading,
              notes: 'EURC • Base • Aave V3. APY merret nga Supabase financial_products.',
            ),
            _buildKriketProductCard(
              asset: 'EURe', network: 'Gnosis', protocol: 'Aave V3',
              apy: apy('eure-savings'), balance: '— EURe',
              notes: 'EURe • Gnosis • Aave V3. APY shfaqet vetëm kur produkti ka normë live të konfiguruar.',
            ),
            _buildKriketProductCard(
              asset: 'ZCHF', network: 'Gnosis', protocol: 'Frankencoin Savings Vault',
              apy: apy('zchf-savings'), balance: '— ZCHF',
              notes: 'ZCHF • Gnosis • Frankencoin Savings Vault. APY shfaqet nga Supabase kur produkti aktivizohet.',
            ),
            _buildKriketUsdcMorphoCard(),
            _buildKriketProductCard(
              asset: 'USDT', network: 'Base', protocol: 'Aave V3',
              apy: apy('usdt-savings'), balance: '— USDT',
              notes: 'USDT • Base • Aave V3. APY shfaqet vetëm pasi reserve address dhe tregu Base të jenë verifikuar live.',
            ),
            _buildKriketProductCard(
              asset: 'GBPe', network: 'Gnosis', protocol: 'Gnosis',
              apy: apy('gbp-savings'), balance: '— GBPe',
              notes: 'GBPe • Gnosis. APY shfaqet nga Supabase kur yield protocol aktivizohet.',
            ),
          ],
        );
      },
    );
  }


  Future<bool> _ensureKriketAal2() async {
    try {
      if (await KriketMfaService.isAal2()) return true;
      final factors = await KriketMfaService.verifiedTotpFactors();
      if (factors.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Aktivizo Authenticator MFA te Security para transaksionit.')),
          );
        }
        return false;
      }

      final controller = TextEditingController();
      final code = await showDialog<String>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Konfirmo MFA'),
          content: TextField(
            controller: controller,
            autofocus: true,
            keyboardType: TextInputType.number,
            maxLength: 6,
            decoration: const InputDecoration(
              labelText: 'Kodi 6-shifror',
              hintText: '123456',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Anulo'),
            ),
            FilledButton(
              onPressed: () {
                final value = controller.text.trim();
                if (value.length == 6) Navigator.pop(context, value);
              },
              child: const Text('Verifiko'),
            ),
          ],
        ),
      );
      if (code == null || code.length != 6 || !mounted) return false;

      try {
        await KriketMfaService.verifyCode(code);
        return await KriketMfaService.isAal2();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('MFA: ' + e.toString())),
          );
        }
        return false;
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('MFA: ' + e.toString())),
        );
      }
      return false;
    }
  }

  Future<void> _kriketMorphoUsdcAction(bool deposit) async {
    final controller = TextEditingController();
    final amount = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(deposit ? 'Deposit USDC' : 'Withdraw USDC'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Amount',
            hintText: '0.00 USDC',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final value = double.tryParse(controller.text.trim());
              if (value != null && value > 0) Navigator.pop(context, value);
            },
            child: Text(deposit ? 'Deposit' : 'Withdraw'),
          ),
        ],
      ),
    );
    if (amount == null || amount <= 0 || !mounted) return;

    final aal2 = await _ensureKriketAal2();
    if (!aal2 || !mounted) return;

    try {
      final api = KriketMorphoUsdcApi();
      final result = await api.execute(
        deposit ? 'deposit' : 'withdraw',
        amount,
      );
      final txId = result['transaction_id']?.toString();
      if (txId == null || txId.isEmpty) {
        throw StateError('Transaction ID was not returned');
      }

      var status = 'pending';
      for (var i = 0; i < 15 && mounted; i++) {
        await Future.delayed(const Duration(seconds: 2));
        status = await api.sync(txId);
        if (status == 'confirmed' || status == 'failed') break;
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            status == 'confirmed'
                ? (deposit ? 'USDC deposit completed' : 'USDC withdrawal completed')
                : 'USDC transaction: ' + status,
          ),
        ),
      );
      setState(() {});
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('USDC: ' + e.toString())),
        );
      }
    }
  }

  Widget _buildKriketUsdcMorphoCard() {
    return FutureBuilder<KriketMorphoUsdcData>(
      future: KriketMorphoUsdcApi().getLive(),
      builder: (context, snapshot) {
        final data = snapshot.data;
        final apy = data?.apy;
        final apyText = snapshot.connectionState == ConnectionState.waiting
            ? 'APY —'
            : (apy == null ? 'APY —' : 'APY ' + apy.toStringAsFixed(2) + '%');
        final balanceText =
            data == null ? '— USDC' : data.balance.toStringAsFixed(2) + ' USDC';

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'USDC Savings',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                    Text(
                      apyText,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  'Base • Morpho' +
                      (data?.vaultName == null
                          ? ''
                          : ' • ' + data!.vaultName),
                ),
                const SizedBox(height: 8),
                Text('Balance: ' + balanceText),
                const SizedBox(height: 8),
                const Text(
                  'Live APY from Morpho. Automatic compounding through vault share price. Withdrawals depend on vault liquidity.',
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton(
                        onPressed: () => _kriketMorphoUsdcAction(true),
                        child: const Text('Deposit'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _kriketMorphoUsdcAction(false),
                        child: const Text('Withdraw'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildKriketSavingsCard() {
    final apy = _kriketLiveApy == null
        ? (_kriketApyLoading ? '…' : '—')
        : _kriketLiveApy!.toStringAsFixed(2) + '%';
    final wallet = _kriketWalletAddress;
    final walletText = _kriketWalletLoading
        ? 'Wallet…'
        : (wallet == null || wallet.length < 10
            ? 'Wallet unavailable'
            : wallet.substring(0, 6) + '…' + wallet.substring(wallet.length - 4));

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xFF2A2A3A)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryContainer,
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: const Icon(Icons.savings_rounded, color: AppTheme.primary, size: 28),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Kriket Savings', maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontFamily: 'Manrope', fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimaryDark)),
                      const SizedBox(height: 4),
                      const Text('EURC • Base • Aave', maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontFamily: 'Manrope', fontSize: 12, color: AppTheme.textMutedDark)),
                      const SizedBox(height: 5),
                      Text(walletText, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontFamily: 'Manrope', fontSize: 10, color: AppTheme.textMutedDark)),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('APY', style: TextStyle(fontFamily: 'Manrope', fontSize: 11, color: AppTheme.textMutedDark)),
                    const SizedBox(height: 3),
                    Text(apy, style: const TextStyle(fontFamily: 'Manrope', fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.primary)),
                    const SizedBox(height: 6),
                    Text(_kriketSavingsLoading ? 'Loading…' : _kriketSavingsBalance.toStringAsFixed(2) + ' EURC',
                      style: const TextStyle(fontFamily: 'Manrope', fontSize: 11, color: AppTheme.textPrimaryDark)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _kriketSavingsLoading ? null : () => _kriketSavingsAction(false),
                    child: const Text('Withdraw'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton(
                    onPressed: _kriketSavingsLoading ? null : () => _kriketSavingsAction(true),
                    child: const Text('Deposit'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductsRow(List<_SavingsProduct> products) {
    return SizedBox(
      height: 136,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: products.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, index) {
          final product = products[index];
          return SizedBox(
            width: 142,
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => _showProductInfo(product),
              child: Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFF2A2A3A)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        _ProductIcon(product: product),
                        const Spacer(),
                        const Icon(
                          Icons.chevron_right_rounded,
                          size: 18,
                          color: AppTheme.textMutedDark,
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      product.title,
                      style: const TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimaryDark,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          product.subtitle,
                          style: const TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 11,
                            color: AppTheme.textMutedDark,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          product.apy == 'Live' ? 'API' : product.apy,
                          style: const TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(String locale) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 34),
      child: Center(
        child: Column(
          children: [
            Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(
                color: AppTheme.primaryContainer,
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Center(
                child: Text('🎯', style: TextStyle(fontSize: 30)),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              AppStrings.get('no_pockets', locale),
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimaryDark,
              ),
            ),
            const SizedBox(height: 7),
            Text(
              AppStrings.get('no_pockets_sub', locale),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 14,
                color: AppTheme.textMutedDark,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return const Center(
      child: CircularProgressIndicator(color: AppTheme.primary),
    );
  }

  Widget _buildErrorState(String locale) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              color: AppTheme.error,
              size: 48,
            ),
            const SizedBox(height: 16),
            Text(
              AppStrings.get('failed_load_pockets', locale),
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimaryDark,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorMessage ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 13,
                color: AppTheme.textMutedDark,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadPockets,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                foregroundColor: const Color(0xFF003322),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(AppStrings.get('retry', locale)),
            ),
          ],
        ),
      ),
    );
  }

  String _formatLargeAmount(double amount) {
    if (amount >= 1000) {
      final k = amount / 1000;
      return '${k % 1 == 0 ? k.toStringAsFixed(0) : k.toStringAsFixed(1)}k';
    }
    return amount.toStringAsFixed(2);
  }
}

enum _SavingsProductKind { bank, defi }

class _SavingsProduct {
  final String title;
  final String subtitle;
  final String apy;
  final IconData icon;
  final _SavingsProductKind kind;

  const _SavingsProduct({
    required this.title,
    required this.subtitle,
    required this.apy,
    required this.icon,
    required this.kind,
  });
}

class _ProductIcon extends StatelessWidget {
  final _SavingsProduct product;
  final bool large;

  const _ProductIcon({
    required this.product,
    this.large = false,
  });

  @override
  Widget build(BuildContext context) {
    final size = large ? 54.0 : 40.0;
    final iconSize = large ? 27.0 : 20.0;

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppTheme.primaryContainer,
        borderRadius: BorderRadius.circular(large ? 17 : 13),
      ),
      child: Icon(product.icon, color: AppTheme.primary, size: iconSize),
    );
  }
}
