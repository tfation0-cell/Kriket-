// Mock data removed — savings pockets are loaded from Supabase.
// This file is kept as an empty placeholder to avoid breaking any residual imports.
class SavingsMockData {
  // No mock data. Use real Supabase data only.
}
