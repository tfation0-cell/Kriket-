class PocketContribution {
  final String id;
  final String pocketId;
  final String userId;
  final double amount;
  final String note;
  final DateTime contributedAt;

  PocketContribution({
    required this.id,
    required this.pocketId,
    required this.userId,
    required this.amount,
    required this.note,
    required this.contributedAt,
  });

  factory PocketContribution.fromJson(Map<String, dynamic> json) {
    return PocketContribution(
      id: json['id'] as String,
      pocketId: json['pocket_id'] as String,
      userId: json['user_id'] as String,
      amount: (json['amount'] as num).toDouble(),
      note: json['note'] as String? ?? 'Manual contribution',
      contributedAt: DateTime.parse(json['contributed_at'] as String),
    );
  }

  Map<String, dynamic> toJson() => {
    'pocket_id': pocketId,
    'user_id': userId,
    'amount': amount,
    'note': note,
  };

  String get formattedDate {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${contributedAt.day.toString().padLeft(2, '0')} '
        '${months[contributedAt.month - 1]} ${contributedAt.year}';
  }
}

class SavingsPocket {
  final String id;
  final String userId;
  final String name;
  final String emoji;
  final double targetAmount;
  final double savedAmount;
  final int color;
  final String deadline;
  final DateTime createdAt;
  final List<PocketContribution> contributions;

  SavingsPocket({
    required this.id,
    required this.userId,
    required this.name,
    required this.emoji,
    required this.targetAmount,
    required this.savedAmount,
    required this.color,
    required this.deadline,
    required this.createdAt,
    this.contributions = const [],
  });

  factory SavingsPocket.fromJson(Map<String, dynamic> json) {
    final rawContributions = json['pocket_contributions'] as List<dynamic>?;
    final contributions =
        rawContributions
            ?.map((c) => PocketContribution.fromJson(c as Map<String, dynamic>))
            .toList() ??
        [];
    contributions.sort((a, b) => b.contributedAt.compareTo(a.contributedAt));

    return SavingsPocket(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      name: json['name'] as String,
      emoji: json['emoji'] as String,
      targetAmount: (json['target_amount'] as num).toDouble(),
      savedAmount: (json['saved_amount'] as num).toDouble(),
      color: (json['color'] as num).toInt(),
      deadline: json['deadline'] as String? ?? 'No deadline',
      createdAt: DateTime.parse(json['created_at'] as String),
      contributions: contributions,
    );
  }

  double get progress =>
      targetAmount > 0 ? (savedAmount / targetAmount).clamp(0.0, 1.0) : 0.0;
  int get percent => (progress * 100).round();

  SavingsPocket copyWith({
    double? savedAmount,
    List<PocketContribution>? contributions,
  }) {
    return SavingsPocket(
      id: id,
      userId: userId,
      name: name,
      emoji: emoji,
      targetAmount: targetAmount,
      savedAmount: savedAmount ?? this.savedAmount,
      color: color,
      deadline: deadline,
      createdAt: createdAt,
      contributions: contributions ?? this.contributions,
    );
  }

  /// Convert to the legacy Map format used by existing widgets
  Map<String, dynamic> toDisplayMap() => {
    'id': id,
    'name': name,
    'emoji': emoji,
    'targetAmount': targetAmount,
    'savedAmount': savedAmount,
    'color': color,
    'deadline': deadline,
    'contributions': contributions
        .map(
          (c) => {
            'id': c.id,
            'amount': c.amount,
            'date': c.formattedDate,
            'note': c.note,
          },
        )
        .toList(),
  };
}
