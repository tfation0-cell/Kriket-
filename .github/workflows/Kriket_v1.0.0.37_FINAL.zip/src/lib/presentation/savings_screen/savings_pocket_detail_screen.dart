import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../services/supabase_service.dart';
import '../../../theme/app_theme.dart';

class SavingsPocketDetailScreen extends StatefulWidget {
  final Map<String, dynamic> pocket;
  final String pocketId;
  final void Function(Map<String, dynamic> updatedPocket) onContributionAdded;

  const SavingsPocketDetailScreen({
    super.key,
    required this.pocket,
    required this.pocketId,
    required this.onContributionAdded,
  });

  @override
  State<SavingsPocketDetailScreen> createState() =>
      _SavingsPocketDetailScreenState();
}

class _SavingsPocketDetailScreenState extends State<SavingsPocketDetailScreen> {
  late Map<String, dynamic> _pocket;
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();
  bool _isAdding = false;
  final bool _isLoadingContributions = false;

  SupabaseClient get _client => SupabaseService.instance.client;

  @override
  void initState() {
    super.initState();
    _pocket = Map<String, dynamic>.from(widget.pocket);
    final contributions = _pocket['contributions'];
    if (contributions is List) {
      _pocket['contributions'] = List<Map<String, dynamic>>.from(
        contributions.map((c) => Map<String, dynamic>.from(c as Map)),
      );
    } else {
      _pocket['contributions'] = <Map<String, dynamic>>[];
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  double get _saved => (_pocket['savedAmount'] as num).toDouble();
  double get _target => (_pocket['targetAmount'] as num).toDouble();
  double get _progress =>
      _target > 0 ? (_saved / _target).clamp(0.0, 1.0) : 0.0;
  int get _percent => (_progress * 100).round();
  Color get _accentColor => Color(_pocket['color'] as int);

  List<Map<String, dynamic>> get _contributions =>
      (_pocket['contributions'] as List).cast<Map<String, dynamic>>();

  void _showAddContributionSheet() {
    _amountController.clear();
    _noteController.clear();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddContributionSheet(
        amountController: _amountController,
        noteController: _noteController,
        accentColor: _accentColor,
        isAdding: _isAdding,
        onAdd: _handleAddContribution,
      ),
    );
  }

  Future<void> _handleAddContribution() async {
    final double? amount = double.tryParse(
      _amountController.text.replaceAll(',', ''),
    );
    if (amount == null || amount <= 0) return;

    setState(() => _isAdding = true);

    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) return;

      final note = _noteController.text.trim().isEmpty
          ? 'Manual contribution'
          : _noteController.text.trim();

      // Insert contribution — trigger on DB will update saved_amount on pocket
      await _client.from('pocket_contributions').insert({
        'pocket_id': widget.pocketId,
        'user_id': userId,
        'amount': amount,
        'note': note,
      });

      // Fetch updated pocket data
      final pocketResponse = await _client
          .from('savings_pockets')
          .select('saved_amount')
          .eq('id', widget.pocketId)
          .single();

      final updatedSaved = (pocketResponse['saved_amount'] as num).toDouble();

      final now = DateTime.now();
      const months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      final dateStr =
          '${now.day.toString().padLeft(2, '0')} ${months[now.month - 1]} ${now.year}';

      final newContribution = {
        'id': 'local_${now.millisecondsSinceEpoch}',
        'amount': amount,
        'date': dateStr,
        'note': note,
      };

      final updatedContributions = [newContribution, ..._contributions];

      setState(() {
        _pocket = {
          ..._pocket,
          'savedAmount': updatedSaved,
          'contributions': updatedContributions,
        };
        _isAdding = false;
      });

      widget.onContributionAdded(_pocket);
      if (mounted) Navigator.of(context).pop();
    } on PostgrestException catch (e) {
      setState(() => _isAdding = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to add contribution: ${e.message}'),
            backgroundColor: AppTheme.error,
          ),
        );
      }
    } catch (e) {
      setState(() => _isAdding = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Something went wrong. Please try again.'),
            backgroundColor: AppTheme.error,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildHeader(context)),
            SliverToBoxAdapter(child: _buildProgressCard()),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Contribution History',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimaryDark,
                      ),
                    ),
                    Text(
                      '${_contributions.length} entries',
                      style: const TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textMutedDark,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 14)),
            _isLoadingContributions
                ? const SliverToBoxAdapter(
                    child: Center(
                      child: Padding(
                        padding: EdgeInsets.all(32),
                        child: CircularProgressIndicator(
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                  )
                : _contributions.isEmpty
                ? SliverToBoxAdapter(child: _buildEmptyContributions())
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                        child: _ContributionItem(
                          contribution: _contributions[index],
                          accentColor: _accentColor,
                          isFirst: index == 0,
                        ),
                      ),
                      childCount: _contributions.length,
                    ),
                  ),
            const SliverToBoxAdapter(child: SizedBox(height: 120)),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddContributionSheet,
        backgroundColor: _accentColor,
        foregroundColor: const Color(0xFF003322),
        elevation: 0,
        icon: const Icon(Icons.add_rounded, size: 20),
        label: const Text(
          'Add Funds',
          style: TextStyle(
            fontFamily: 'Manrope',
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.of(context).pop();
            },
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(12.0),
                border: Border.all(color: const Color(0xFF2A2A3A)),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: AppTheme.textPrimaryDark,
                size: 18,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Text(
            _pocket['emoji'] as String,
            style: const TextStyle(fontSize: 26),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _pocket['name'] as String,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppTheme.textPrimaryDark,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard() {
    final double remaining = (_target - _saved).clamp(0.0, double.infinity);

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(color: const Color(0xFF2A2A3A), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Saved so far',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textMutedDark,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '\$${_formatAmount(_saved)}',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: _accentColor,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: _accentColor.withAlpha(25),
                    borderRadius: BorderRadius.circular(100.0),
                  ),
                  child: Text(
                    '$_percent%',
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: _accentColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            ClipRRect(
              borderRadius: BorderRadius.circular(100.0),
              child: LinearProgressIndicator(
                value: _progress,
                minHeight: 10,
                backgroundColor: const Color(0xFF1E1E2A),
                valueColor: AlwaysStoppedAnimation<Color>(_accentColor),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _StatChip(
                    label: 'Goal',
                    value: '\$${_formatAmount(_target)}',
                    icon: Icons.flag_rounded,
                    color: AppTheme.textSecondaryDark,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatChip(
                    label: 'Remaining',
                    value: '\$${_formatAmount(remaining)}',
                    icon: Icons.hourglass_bottom_rounded,
                    color: AppTheme.warning,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatChip(
                    label: 'Deadline',
                    value: _pocket['deadline'] as String,
                    icon: Icons.calendar_today_rounded,
                    color: AppTheme.secondary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyContributions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
      child: Center(
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: _accentColor.withAlpha(25),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Icon(
                Icons.savings_outlined,
                color: _accentColor,
                size: 28,
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'No contributions yet',
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimaryDark,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Tap "Add Funds" to make your first contribution',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 13,
                fontWeight: FontWeight.w400,
                color: AppTheme.textMutedDark,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatAmount(double amount) {
    if (amount >= 1000) {
      final k = amount / 1000;
      return '${k % 1 == 0 ? k.toStringAsFixed(0) : k.toStringAsFixed(1)}k';
    }
    return amount.toStringAsFixed(0);
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatChip({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariantDark,
        borderRadius: BorderRadius.circular(14.0),
        border: Border.all(color: const Color(0xFF2A2A3A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: color,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'Manrope',
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: AppTheme.textMutedDark,
            ),
          ),
        ],
      ),
    );
  }
}

class _ContributionItem extends StatelessWidget {
  final Map<String, dynamic> contribution;
  final Color accentColor;
  final bool isFirst;

  const _ContributionItem({
    required this.contribution,
    required this.accentColor,
    required this.isFirst,
  });

  @override
  Widget build(BuildContext context) {
    final double amount = (contribution['amount'] as num).toDouble();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: isFirst ? accentColor.withAlpha(60) : const Color(0xFF2A2A3A),
          width: isFirst ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: accentColor.withAlpha(25),
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: Icon(
              Icons.arrow_downward_rounded,
              color: accentColor,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  contribution['note'] as String,
                  style: const TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimaryDark,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                const SizedBox(height: 2),
                Text(
                  contribution['date'] as String,
                  style: const TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: AppTheme.textMutedDark,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '+\$${amount >= 1000 ? '${(amount / 1000).toStringAsFixed(amount % 1000 == 0 ? 0 : 1)}k' : amount.toStringAsFixed(0)}',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: accentColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _AddContributionSheet extends StatefulWidget {
  final TextEditingController amountController;
  final TextEditingController noteController;
  final Color accentColor;
  final bool isAdding;
  final VoidCallback onAdd;

  const _AddContributionSheet({
    required this.amountController,
    required this.noteController,
    required this.accentColor,
    required this.isAdding,
    required this.onAdd,
  });

  @override
  State<_AddContributionSheet> createState() => _AddContributionSheetState();
}

class _AddContributionSheetState extends State<_AddContributionSheet> {
  bool _localAdding = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28.0)),
      ),
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 32,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A3A),
                borderRadius: BorderRadius.circular(100.0),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Add Funds',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryDark,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Amount (\$)',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryDark,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: widget.amountController,
            keyboardType: TextInputType.number,
            autofocus: true,
            style: const TextStyle(
              fontFamily: 'Manrope',
              fontSize: 15,
              color: AppTheme.textPrimaryDark,
            ),
            decoration: InputDecoration(
              hintText: 'e.g. 500',
              hintStyle: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 14,
                color: AppTheme.textMutedDark,
              ),
              filled: true,
              fillColor: AppTheme.surfaceVariantDark,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14.0),
                borderSide: const BorderSide(color: Color(0xFF2A2A3A)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14.0),
                borderSide: const BorderSide(color: Color(0xFF2A2A3A)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14.0),
                borderSide: BorderSide(color: widget.accentColor, width: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Note (optional)',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryDark,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: widget.noteController,
            style: const TextStyle(
              fontFamily: 'Manrope',
              fontSize: 15,
              color: AppTheme.textPrimaryDark,
            ),
            decoration: InputDecoration(
              hintText: 'e.g. Monthly savings',
              hintStyle: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 14,
                color: AppTheme.textMutedDark,
              ),
              filled: true,
              fillColor: AppTheme.surfaceVariantDark,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14.0),
                borderSide: const BorderSide(color: Color(0xFF2A2A3A)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14.0),
                borderSide: const BorderSide(color: Color(0xFF2A2A3A)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14.0),
                borderSide: BorderSide(color: widget.accentColor, width: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _localAdding
                  ? null
                  : () async {
                      setState(() => _localAdding = true);
                      widget.onAdd();
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.accentColor,
                foregroundColor: const Color(0xFF003322),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
                elevation: 0,
              ),
              child: _localAdding
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Color(0xFF003322),
                      ),
                    )
                  : const Text(
                      'Add Contribution',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
