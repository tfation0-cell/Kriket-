// Mock data removed — contacts are loaded from Supabase user_profiles.
// This file is kept as an empty placeholder to avoid breaking any residual imports.
class SendMockData {
  // No mock data. Use real Supabase data only.
}
