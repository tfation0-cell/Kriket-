import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class SendConfirmStepWidget extends StatelessWidget {
  final Map<String, dynamic> recipient;
  final String amount;
  final String note;
  final bool isSending;
  final VoidCallback onSend;

  const SendConfirmStepWidget({
    super.key,
    required this.recipient,
    required this.amount,
    required this.note,
    required this.isSending,
    required this.onSend,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final double parsedAmount = double.tryParse(amount) ?? 0;
    final double fee = parsedAmount > 0 ? 0.99 : 0.0;
    final double total = parsedAmount + fee;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Review Transfer',
            style: theme.textTheme.titleMedium?.copyWith(
              color: AppTheme.textPrimaryDark,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 20),

          // Recipient + amount card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.surfaceDark,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0xFF1E1E2A)),
            ),
            child: Column(
              children: [
                // Recipient row
                Row(
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: Color(
                          recipient['avatarColor'] as int,
                        ).withAlpha(51),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          recipient['initials'] as String,
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Color(recipient['avatarColor'] as int),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            recipient['name'] as String,
                            style: theme.textTheme.titleSmall?.copyWith(
                              color: AppTheme.textPrimaryDark,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${recipient['bank']}  ·  ${recipient['accountEnding']}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: AppTheme.textMutedDark,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),
                Container(height: 1, color: const Color(0xFF1E1E2A)),
                const SizedBox(height: 20),

                // Amount display
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      '\$',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 22,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textSecondaryDark,
                      ),
                    ),
                    Text(
                      amount,
                      style: const TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimaryDark,
                        fontFeatures: [FontFeature.tabularFigures()],
                        letterSpacing: -0.5,
                      ),
                    ),
                  ],
                ),

                if (note.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceVariantDark,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.notes_rounded,
                          size: 14,
                          color: AppTheme.textSecondaryDark,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          note,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textSecondaryDark,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Fee breakdown card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppTheme.surfaceDark,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF1E1E2A)),
            ),
            child: Column(
              children: [
                _FeeRow(
                  label: 'Transfer amount',
                  value: '\$$amount',
                  isBold: false,
                ),
                const SizedBox(height: 10),
                _FeeRow(
                  label: 'Processing fee',
                  value: '\$${fee.toStringAsFixed(2)}',
                  isBold: false,
                ),
                const SizedBox(height: 12),
                Container(height: 1, color: const Color(0xFF1E1E2A)),
                const SizedBox(height: 12),
                _FeeRow(
                  label: 'Total deducted',
                  value: '\$${total.toStringAsFixed(2)}',
                  isBold: true,
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Arrival estimate
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppTheme.successContainer,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppTheme.success.withAlpha(64)),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.schedule_rounded,
                  size: 16,
                  color: AppTheme.success,
                ),
                const SizedBox(width: 8),
                Text(
                  'Arrives instantly · Aug 04, 2026',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.success,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Confirm Send button
          SizedBox(
            height: 52,
            child: ElevatedButton(
              onPressed: isSending ? null : onSend,
              child: isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Color(0xFF003322),
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.send_rounded, size: 18),
                        SizedBox(width: 8),
                        Text('Confirm & Send'),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _FeeRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isBold;

  const _FeeRow({
    required this.label,
    required this.value,
    required this.isBold,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Manrope',
            fontSize: 13,
            fontWeight: isBold ? FontWeight.w700 : FontWeight.w400,
            color: isBold
                ? AppTheme.textPrimaryDark
                : AppTheme.textSecondaryDark,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: TextStyle(
            fontFamily: 'Manrope',
            fontSize: 13,
            fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
            color: isBold
                ? AppTheme.textPrimaryDark
                : AppTheme.textSecondaryDark,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
      ],
    );
  }
}
