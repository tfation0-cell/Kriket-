import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../theme/app_theme.dart';

class SendRecipientStepWidget extends StatefulWidget {
  final void Function(Map<String, dynamic>) onRecipientSelected;

  const SendRecipientStepWidget({super.key, required this.onRecipientSelected});

  @override
  State<SendRecipientStepWidget> createState() =>
      _SendRecipientStepWidgetState();
}

class _SendRecipientStepWidgetState extends State<SendRecipientStepWidget> {
  final _searchController = TextEditingController();
  List<Map<String, dynamic>> _allContacts = [];
  List<Map<String, dynamic>> _filteredContacts = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadContacts();
    _searchController.addListener(_onSearch);
  }

  Future<void> _loadContacts() async {
    try {
      final currentUserId = Supabase.instance.client.auth.currentUser?.id;
      if (currentUserId == null) {
        if (mounted) {
          setState(() {
            _loading = false;
            _error = 'Not signed in.';
          });
        }
        return;
      }

      // Load all user profiles except the current user
      final response = await Supabase.instance.client
          .from('user_profiles')
          .select('id, full_name, email, avatar_color')
          .neq('id', currentUserId)
          .order('full_name', ascending: true)
          .limit(50);

      final contacts = (response as List).map((row) {
        final map = row as Map<String, dynamic>;
        final name =
            (map['full_name'] as String? ??
                    map['email'] as String? ??
                    'Unknown')
                .trim();
        final email = map['email'] as String? ?? '';
        final initials = _initials(name);
        final color = (map['avatar_color'] as int?) ?? 0xFF6C5CE7;
        return {
          'id': map['id'] as String,
          'name': name,
          'handle': email.isNotEmpty ? '@${email.split('@').first}' : '',
          'avatarColor': color,
          'initials': initials,
          'bank': '',
          'accountEnding': '',
        };
      }).toList();

      if (mounted) {
        setState(() {
          _allContacts = contacts;
          _filteredContacts = contacts;
          _loading = false;
        });
      }
    } catch (e) {
      debugPrint('[SendRecipient] Failed to load contacts: $e');
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Could not load contacts.';
        });
      }
    }
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }

  void _onSearch() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredContacts = query.isEmpty
          ? _allContacts
          : _allContacts.where((c) {
              return (c['name'] as String).toLowerCase().contains(query) ||
                  (c['handle'] as String).toLowerCase().contains(query);
            }).toList();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Who are you sending to?',
            style: theme.textTheme.titleMedium?.copyWith(
              color: AppTheme.textPrimaryDark,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),

          // Search field
          Container(
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF2A2A3A)),
            ),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 14,
                color: AppTheme.textPrimaryDark,
              ),
              decoration: const InputDecoration(
                hintText: 'Search by name or @handle',
                hintStyle: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 14,
                  color: AppTheme.textMutedDark,
                ),
                prefixIcon: Icon(
                  Icons.search_rounded,
                  color: AppTheme.textSecondaryDark,
                  size: 20,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
              ),
            ),
          ),

          const SizedBox(height: 24),

          Row(
            children: [
              Text(
                'Contacts',
                style: theme.textTheme.titleSmall?.copyWith(
                  color: AppTheme.textPrimaryDark,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              if (!_loading)
                Text(
                  '${_filteredContacts.length} contacts',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.textMutedDark,
                  ),
                ),
            ],
          ),

          const SizedBox(height: 12),

          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  )
                : _error != null
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: AppTheme.error,
                          size: 40,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _error!,
                          style: const TextStyle(
                            color: AppTheme.textMutedDark,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              _loading = true;
                              _error = null;
                            });
                            _loadContacts();
                          },
                          child: const Text(
                            'Retry',
                            style: TextStyle(color: AppTheme.primary),
                          ),
                        ),
                      ],
                    ),
                  )
                : _filteredContacts.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.person_search_outlined,
                          size: 48,
                          color: AppTheme.textMutedDark,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _allContacts.isEmpty
                              ? 'No other users found'
                              : 'No contacts found',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: AppTheme.textSecondaryDark,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.separated(
                    itemCount: _filteredContacts.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) => _ContactItemWidget(
                      contact: _filteredContacts[index],
                      onTap: () =>
                          widget.onRecipientSelected(_filteredContacts[index]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

// ── Contact item ──────────────────────────────────────────────────
class _ContactItemWidget extends StatelessWidget {
  final Map<String, dynamic> contact;
  final VoidCallback onTap;

  const _ContactItemWidget({required this.contact, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: AppTheme.primary.withAlpha(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: AppTheme.surfaceDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFF1E1E2A), width: 1),
          ),
          child: Row(
            children: [
              // Avatar circle
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Color(contact['avatarColor'] as int).withAlpha(51),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    contact['initials'] as String,
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Color(contact['avatarColor'] as int),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // Name + handle
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      contact['name'] as String,
                      style: theme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.textPrimaryDark,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      contact['handle'] as String,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textMutedDark,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),

              const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: AppTheme.textMutedDark,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
