import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../theme/app_theme.dart';

class SendAmountStepWidget extends StatefulWidget {
  final Map<String, dynamic> recipient;
  final void Function(String amount, String note) onConfirmed;

  const SendAmountStepWidget({
    super.key,
    required this.recipient,
    required this.onConfirmed,
  });

  @override
  State<SendAmountStepWidget> createState() => _SendAmountStepWidgetState();
}

class _SendAmountStepWidgetState extends State<SendAmountStepWidget> {
  // TODO: Replace with Riverpod/Bloc for production
  String _amount = '0';
  final _noteController = TextEditingController();
  String? _amountError;

  void _onKeypadPress(String value) {
    HapticFeedback.selectionClick();
    setState(() {
      _amountError = null;
      if (value == 'del') {
        if (_amount.length > 1) {
          _amount = _amount.substring(0, _amount.length - 1);
        } else {
          _amount = '0';
        }
      } else if (value == '.') {
        if (!_amount.contains('.')) {
          _amount = '$_amount.';
        }
      } else {
        if (_amount == '0') {
          _amount = value;
        } else if (_amount.contains('.')) {
          final decimalPart = _amount.split('.')[1];
          if (decimalPart.length < 2) {
            _amount = '$_amount$value';
          }
        } else {
          if (_amount.length < 8) {
            _amount = '$_amount$value';
          }
        }
      }
    });
  }

  void _onContinue() {
    final amt = double.tryParse(_amount) ?? 0;
    if (amt <= 0) {
      setState(() => _amountError = 'Please enter a valid amount');
      return;
    }
    if (amt > 63786.50) {
      setState(() => _amountError = 'Insufficient balance');
      return;
    }
    widget.onConfirmed(_amount, _noteController.text.trim());
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          // Recipient chip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: const Color(0xFF2A2A3A)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: Color(
                      widget.recipient['avatarColor'] as int,
                    ).withAlpha(51),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      widget.recipient['initials'] as String,
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(widget.recipient['avatarColor'] as int),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'To ${widget.recipient['name']}',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: AppTheme.textPrimaryDark,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Amount display
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      '\$',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textSecondaryDark,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _amount,
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 52,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimaryDark,
                      fontFeatures: [FontFeature.tabularFigures()],
                      letterSpacing: -1,
                    ),
                  ),
                ],
              ),
              if (_amountError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    _amountError!,
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 12,
                      color: AppTheme.error,
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 16),

          // Note field
          Container(
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF2A2A3A)),
            ),
            child: TextField(
              controller: _noteController,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 13,
                color: AppTheme.textPrimaryDark,
              ),
              decoration: const InputDecoration(
                hintText: 'Add a note (optional)',
                hintStyle: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 13,
                  color: AppTheme.textMutedDark,
                ),
                prefixIcon: Icon(
                  Icons.notes_rounded,
                  size: 18,
                  color: AppTheme.textSecondaryDark,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Numpad
          Expanded(child: _NumpadWidget(onPress: _onKeypadPress)),

          const SizedBox(height: 12),

          // Continue button
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _onContinue,
              child: const Text('Continue'),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

// ── Numpad ────────────────────────────────────────────────────────
class _NumpadWidget extends StatelessWidget {
  final void Function(String) onPress;

  const _NumpadWidget({required this.onPress});

  @override
  Widget build(BuildContext context) {
    final keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', 'del'];

    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 6,
      crossAxisSpacing: 6,
      childAspectRatio: 2.6,
      children: keys
          .map((key) => _NumpadKey(label: key, onPress: onPress))
          .toList(),
    );
  }
}

class _NumpadKey extends StatefulWidget {
  final String label;
  final void Function(String) onPress;

  const _NumpadKey({required this.label, required this.onPress});

  @override
  State<_NumpadKey> createState() => _NumpadKeyState();
}

class _NumpadKeyState extends State<_NumpadKey>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scale = Tween<double>(
      begin: 1.0,
      end: 0.88,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onPress(widget.label);
      },
      onTapCancel: () => _controller.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          decoration: BoxDecoration(
            color: AppTheme.surfaceVariantDark,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Center(
            child: widget.label == 'del'
                ? const Icon(
                    Icons.backspace_outlined,
                    size: 20,
                    color: AppTheme.textSecondaryDark,
                  )
                : Text(
                    widget.label,
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimaryDark,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}