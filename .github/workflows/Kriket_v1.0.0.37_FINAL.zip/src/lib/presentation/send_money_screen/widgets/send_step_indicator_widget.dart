import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../send_money_screen.dart';

class SendStepIndicatorWidget extends StatelessWidget {
  final SendStep currentStep;

  const SendStepIndicatorWidget({super.key, required this.currentStep});

  @override
  Widget build(BuildContext context) {
    final steps = [
      _StepData(label: 'Recipient', step: SendStep.recipient),
      _StepData(label: 'Amount', step: SendStep.amount),
      _StepData(label: 'Confirm', step: SendStep.confirm),
    ];

    final currentIndex = steps.indexWhere((s) => s.step == currentStep);

    return Row(
      children: List.generate(steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          // Connector line
          final lineIndex = i ~/ 2;
          final isCompleted = lineIndex < currentIndex;
          return Expanded(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: 2,
              decoration: BoxDecoration(
                color: isCompleted
                    ? AppTheme.primary
                    : AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(1),
              ),
            ),
          );
        }

        final stepIndex = i ~/ 2;
        final step = steps[stepIndex];
        final isCompleted = stepIndex < currentIndex;
        final isActive = stepIndex == currentIndex;

        return Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutCubic,
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: isCompleted
                    ? AppTheme.primary
                    : isActive
                    ? AppTheme.primaryContainer
                    : AppTheme.surfaceVariantDark,
                shape: BoxShape.circle,
                border: Border.all(
                  color: isActive ? AppTheme.primary : Colors.transparent,
                  width: 2,
                ),
              ),
              child: Center(
                child: isCompleted
                    ? const Icon(
                        Icons.check_rounded,
                        size: 16,
                        color: Color(0xFF003322),
                      )
                    : Text(
                        '${stepIndex + 1}',
                        style: TextStyle(
                          fontFamily: 'Manrope',
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: isActive
                              ? AppTheme.primary
                              : AppTheme.textMutedDark,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              step.label,
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                color: isActive ? AppTheme.primary : AppTheme.textMutedDark,
              ),
            ),
          ],
        );
      }),
    );
  }
}

class _StepData {
  final String label;
  final SendStep step;
  const _StepData({required this.label, required this.step});
}
