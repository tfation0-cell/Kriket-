import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import '../../providers/app_providers.dart';
import '../../l10n/app_strings.dart';

import '../../theme/app_theme.dart';
import './widgets/send_amount_step_widget.dart';
import './widgets/send_confirm_step_widget.dart';
import './widgets/send_recipient_step_widget.dart';
import './widgets/send_step_indicator_widget.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/email_service.dart';

enum SendStep { recipient, amount, confirm }

class SendMoneyScreen extends StatefulWidget {
  const SendMoneyScreen({super.key});

  @override
  State<SendMoneyScreen> createState() => _SendMoneyScreenState();
}

class _SendMoneyScreenState extends State<SendMoneyScreen> {
  // TODO: Replace with Riverpod/Bloc for production
  SendStep _currentStep = SendStep.recipient;
  Map<String, dynamic>? _selectedRecipient;
  String _amount = '';
  String _note = '';
  bool _isSending = false;
  bool _sendSuccess = false;

  void _onRecipientSelected(Map<String, dynamic> recipient) {
    setState(() {
      _selectedRecipient = recipient;
      _currentStep = SendStep.amount;
    });
  }

  void _onAmountConfirmed(String amount, String note) {
    setState(() {
      _amount = amount;
      _note = note;
      _currentStep = SendStep.confirm;
    });
  }

  void _onBack() {
    if (_currentStep == SendStep.amount) {
      setState(() => _currentStep = SendStep.recipient);
    } else if (_currentStep == SendStep.confirm) {
      setState(() => _currentStep = SendStep.amount);
    } else {
      Navigator.of(context).pop();
    }
  }

  Future<void> _onSend() async {
    setState(() => _isSending = true);
    await Future.delayed(const Duration(milliseconds: 1600));
    setState(() {
      _isSending = false;
      _sendSuccess = true;
    });

    // Send transfer confirmation email (non-blocking)
    try {
      final user = Supabase.instance.client.auth.currentUser;
      final userEmail = user?.email;
      final userName = user?.userMetadata?['full_name'] as String? ?? 'there';
      if (userEmail != null) {
        EmailService.instance.sendTransferEmail(
          to: userEmail,
          name: userName,
          amount: _amount,
          recipient: _selectedRecipient?['name'] as String? ?? 'recipient',
        );
      }
    } catch (_) {}

    await Future.delayed(const Duration(milliseconds: 1800));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: SafeArea(
        child: Column(
          children: [
            // Custom AppBar
            _SendMoneyAppBar(onBack: _onBack),

            // Step indicator
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: SendStepIndicatorWidget(currentStep: _currentStep),
            ),

            // Step content
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                transitionBuilder: (child, animation) => SlideTransition(
                  position:
                      Tween<Offset>(
                        begin: const Offset(0.05, 0),
                        end: Offset.zero,
                      ).animate(
                        CurvedAnimation(
                          parent: animation,
                          curve: Curves.easeOutCubic,
                        ),
                      ),
                  child: FadeTransition(opacity: animation, child: child),
                ),
                child: _buildCurrentStep(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentStep() {
    if (_sendSuccess) {
      return _SendSuccessWidget(
        key: const ValueKey('success'),
        recipient: _selectedRecipient!,
        amount: _amount,
      );
    }

    switch (_currentStep) {
      case SendStep.recipient:
        return SendRecipientStepWidget(
          key: const ValueKey('recipient'),
          onRecipientSelected: _onRecipientSelected,
        );
      case SendStep.amount:
        return SendAmountStepWidget(
          key: const ValueKey('amount'),
          recipient: _selectedRecipient!,
          onConfirmed: _onAmountConfirmed,
        );
      case SendStep.confirm:
        return SendConfirmStepWidget(
          key: const ValueKey('confirm'),
          recipient: _selectedRecipient!,
          amount: _amount,
          note: _note,
          isSending: _isSending,
          onSend: _onSend,
        );
    }
  }
}

// ── AppBar ────────────────────────────────────────────────────────
class _SendMoneyAppBar extends StatelessWidget {
  final VoidCallback onBack;

  const _SendMoneyAppBar({required this.onBack});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final locale = context.watch<LocaleProvider>().languageCode;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: onBack,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(13),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: AppTheme.textPrimaryDark,
              ),
            ),
          ),
          Expanded(
            child: Text(
              AppStrings.get('send_money', locale),
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium?.copyWith(
                color: AppTheme.textPrimaryDark,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 40),
        ],
      ),
    );
  }
}

// ── Success screen ────────────────────────────────────────────────
class _SendSuccessWidget extends StatefulWidget {
  final Map<String, dynamic> recipient;
  final String amount;

  const _SendSuccessWidget({
    super.key,
    required this.recipient,
    required this.amount,
  });

  @override
  State<_SendSuccessWidget> createState() => _SendSuccessWidgetState();
}

class _SendSuccessWidgetState extends State<_SendSuccessWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                color: AppTheme.successContainer,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.success.withAlpha(77),
                    blurRadius: 32,
                    spreadRadius: 4,
                  ),
                ],
              ),
              child: const Icon(
                Icons.check_rounded,
                color: AppTheme.success,
                size: 44,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Money Sent!',
              style: theme.textTheme.headlineMedium?.copyWith(
                color: AppTheme.textPrimaryDark,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '\$${widget.amount} sent to ${widget.recipient['name']}',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.textSecondaryDark,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
