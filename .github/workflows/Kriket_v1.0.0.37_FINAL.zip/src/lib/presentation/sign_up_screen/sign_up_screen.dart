import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import '../../services/email_service.dart';
import '../../services/pin_service.dart';
import '../sign_up_login_screen/widgets/particle_background_widget.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _isLoading = false;
  String? _authError;

  late AnimationController _entranceController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Curves.easeOutCubic,
          ),
        );
    _fadeAnimation = CurvedAnimation(
      parent: _entranceController,
      curve: Curves.easeOut,
    );
    _entranceController.forward();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _handleSignUp() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
      _authError = null;
    });

    try {
      final client = Supabase.instance.client;
      final response = await client.auth.signUp(
        email: _emailController.text.trim(),
        password: _passwordController.text,
        data: {'full_name': _nameController.text.trim(), 'phone': _phoneController.text.trim()},
      );

      if (!mounted) return;

      if (response.user != null) {
        // Send welcome email (non-blocking)
        EmailService.instance.sendRegistrationEmail(
          to: _emailController.text.trim(),
          name: _nameController.text.trim(),
        );
        context.go(AppRoutes.pinSetup);
      } else {
        setState(() {
          _isLoading = false;
          _authError = 'Sign-up failed. Please try again.';
        });
      }
    } on AuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _authError = e.message;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _authError = 'An unexpected error occurred. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: Stack(
        children: [
          const ParticleBackgroundWidget(),
          SafeArea(
            child: Column(
              children: [
                // Back button
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 16, top: 8),
                    child: IconButton(
                      onPressed: () => context.pop(),
                      icon: const Icon(
                        Icons.arrow_back_ios_new_rounded,
                        color: AppTheme.textSecondaryDark,
                        size: 20,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 16,
                      ),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 480),
                        child: SlideTransition(
                          position: _slideAnimation,
                          child: FadeTransition(
                            opacity: _fadeAnimation,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                // Logo + title
                                Column(
                                  children: [
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.asset(
                                        'assets/images/kriket_logo.png',
                                        width: 118,
                                        height: 118,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    const SizedBox(height: 20),
                                    Text(
                                      'Create your account',
                                      style: theme.textTheme.bodyMedium?.copyWith(
                                        color: AppTheme.textSecondaryDark,
                                      ),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 32),

                                // Glassmorphism form card
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(28),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(
                                      sigmaX: 16,
                                      sigmaY: 16,
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: AppTheme.surfaceDark.withAlpha(
                                          179,
                                        ),
                                        borderRadius: BorderRadius.circular(28),
                                        border: Border.all(
                                          color: const Color(0xFF2A2A3A),
                                          width: 1,
                                        ),
                                      ),
                                      padding: const EdgeInsets.all(28),
                                      child: Form(
                                        key: _formKey,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            Text(
                                              'Get started',
                                              style: theme.textTheme.titleLarge
                                                  ?.copyWith(
                                                    color: AppTheme
                                                        .textPrimaryDark,
                                                    fontWeight: FontWeight.w700,
                                                  ),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              'Fill in your details to create an account',
                                              style: theme.textTheme.bodyMedium,
                                            ),
                                            const SizedBox(height: 28),

                                            // Full name field
                                            _GlassFormField(
                                              controller: _nameController,
                                              label: 'Full name',
                                              hint: 'John Doe',
                                              prefixIcon:
                                                  Icons.person_outline_rounded,
                                              keyboardType: TextInputType.name,
                                              validator: (v) {
                                                if (v == null ||
                                                    v.trim().isEmpty) {
                                                  return 'Please enter your name';
                                                }
                                                return null;
                                              },
                                            ),

                                            const SizedBox(height: 16),

                                            // Email field
                                            _GlassFormField(
                                              controller: _emailController,
                                              label: 'Email address',
                                              hint: 'your@email.com',
                                              prefixIcon: Icons.email_outlined,
                                              keyboardType:
                                                  TextInputType.emailAddress,
                                              validator: (v) {
                                                if (v == null || v.isEmpty) {
                                                  return 'Please enter your email';
                                                }
                                                if (!v.contains('@')) {
                                                  return 'Enter a valid email address';
                                                }
                                                return null;
                                              },
                                            ),

                                            const SizedBox(height: 16),

                                            // Phone number field
                                            _GlassFormField(
                                              controller: _phoneController,
                                              label: 'Phone number',
                                              hint: '+30 69XXXXXXXX',
                                              prefixIcon: Icons.phone_outlined,
                                              keyboardType: TextInputType.phone,
                                              validator: (v) {
                                                if (v == null || v.trim().isEmpty) {
                                                  return 'Please enter your phone number';
                                                }
                                                if (v.trim().length < 7) {
                                                  return 'Please enter a valid phone number';
                                                }
                                                return null;
                                              },
                                            ),

                                            const SizedBox(height: 16),

                                            // Password field
                                            _GlassFormField(
                                              controller: _passwordController,
                                              label: 'Password',
                                              hint: '••••••••',
                                              prefixIcon:
                                                  Icons.lock_outline_rounded,
                                              obscureText: _obscurePassword,
                                              suffixIcon: IconButton(
                                                icon: Icon(
                                                  _obscurePassword
                                                      ? Icons
                                                            .visibility_outlined
                                                      : Icons
                                                            .visibility_off_outlined,
                                                  color: AppTheme
                                                      .textSecondaryDark,
                                                  size: 20,
                                                ),
                                                onPressed: () => setState(
                                                  () => _obscurePassword =
                                                      !_obscurePassword,
                                                ),
                                              ),
                                              validator: (v) {
                                                if (v == null || v.isEmpty) {
                                                  return 'Please enter a password';
                                                }
                                                if (v.length < 6) {
                                                  return 'Password must be at least 6 characters';
                                                }
                                                return null;
                                              },
                                            ),

                                            const SizedBox(height: 16),

                                            // Confirm password field
                                            _GlassFormField(
                                              controller:
                                                  _confirmPasswordController,
                                              label: 'Confirm password',
                                              hint: '••••••••',
                                              prefixIcon:
                                                  Icons.lock_outline_rounded,
                                              obscureText:
                                                  _obscureConfirmPassword,
                                              suffixIcon: IconButton(
                                                icon: Icon(
                                                  _obscureConfirmPassword
                                                      ? Icons
                                                            .visibility_outlined
                                                      : Icons
                                                            .visibility_off_outlined,
                                                  color: AppTheme
                                                      .textSecondaryDark,
                                                  size: 20,
                                                ),
                                                onPressed: () => setState(
                                                  () => _obscureConfirmPassword =
                                                      !_obscureConfirmPassword,
                                                ),
                                              ),
                                              validator: (v) {
                                                if (v == null || v.isEmpty) {
                                                  return 'Please confirm your password';
                                                }
                                                if (v !=
                                                    _passwordController.text) {
                                                  return 'Passwords do not match';
                                                }
                                                return null;
                                              },
                                            ),

                                            // Auth error
                                            if (_authError != null) ...[
                                              const SizedBox(height: 16),
                                              Container(
                                                padding: const EdgeInsets.all(
                                                  12,
                                                ),
                                                decoration: BoxDecoration(
                                                  color:
                                                      AppTheme.errorContainer,
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                  border: Border.all(
                                                    color: AppTheme.error
                                                        .withAlpha(77),
                                                  ),
                                                ),
                                                child: Row(
                                                  children: [
                                                    const Icon(
                                                      Icons
                                                          .error_outline_rounded,
                                                      color: AppTheme.error,
                                                      size: 16,
                                                    ),
                                                    const SizedBox(width: 8),
                                                    Expanded(
                                                      child: Text(
                                                        _authError!,
                                                        style: theme
                                                            .textTheme
                                                            .bodySmall
                                                            ?.copyWith(
                                                              color: AppTheme
                                                                  .error,
                                                            ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],

                                            const SizedBox(height: 24),

                                            // Create account button
                                            SizedBox(
                                              height: 52,
                                              child: ElevatedButton(
                                                onPressed:
                                                    _isLoading ? null
                                                    : _handleSignUp,
                                                child: _isLoading
                                                    ? const SizedBox(
                                                        width: 20,
                                                        height: 20,
                                                        child:
                                                            CircularProgressIndicator(
                                                              strokeWidth: 2.5,
                                                              color: Color(
                                                                0xFF003322,
                                                              ),
                                                            ),
                                                      )
                                                    : const Text(
                                                        'Create Account',
                                                      ),
                                              ),
                                            ),

                                            const SizedBox(height: 16),

                                            // Sign in link
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  'Already have an account? ',
                                                  style: theme
                                                      .textTheme
                                                      .bodySmall
                                                      ?.copyWith(
                                                        color: AppTheme
                                                            .textSecondaryDark,
                                                      ),
                                                ),
                                                GestureDetector(
                                                  onTap: () => context.pop(),
                                                  child: Text(
                                                    'Sign in',
                                                    style: theme
                                                        .textTheme
                                                        .bodySmall
                                                        ?.copyWith(
                                                          color:
                                                              AppTheme.primary,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _GlassFormField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData prefixIcon;
  final TextInputType? keyboardType;
  final bool obscureText;
  final Widget? suffixIcon;
  final String? Function(String?)? validator;

  const _GlassFormField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.prefixIcon,
    this.keyboardType,
    this.obscureText = false,
    this.suffixIcon,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      validator: validator,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(prefixIcon),
        suffixIcon: suffixIcon,
        filled: true,
        fillColor: const Color(0xFF111820),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    );
  }
}

