import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../services/supabase_service.dart';
import '../models/payment_request_model.dart';

class RequestTrackerWidget extends StatefulWidget {
  const RequestTrackerWidget({super.key});

  @override
  State<RequestTrackerWidget> createState() => _RequestTrackerWidgetState();
}

class _RequestTrackerWidgetState extends State<RequestTrackerWidget> {
  late Future<List<PaymentRequestModel>> _requestsFuture;

  @override
  void initState() {
    super.initState();
    _requestsFuture = _fetchRequests();
  }

  Future<List<PaymentRequestModel>> _fetchRequests() async {
    final userId = SupabaseService.instance.client.auth.currentUser?.id;
    if (userId == null) return [];

    final response = await SupabaseService.instance.client
        .from('payment_requests')
        .select()
        .eq('requester_id', userId)
        .order('created_at', ascending: false)
        .limit(30);

    return (response as List)
        .map((e) => PaymentRequestModel.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  void _refresh() {
    setState(() => _requestsFuture = _fetchRequests());
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return FutureBuilder<List<PaymentRequestModel>>(
      future: _requestsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return _buildSkeleton();
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.wifi_off_rounded,
                  size: 40,
                  color: AppTheme.textMutedDark,
                ),
                const SizedBox(height: 12),
                Text(
                  'Could not load requests',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textSecondaryDark,
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: _refresh,
                  child: const Text(
                    'Retry',
                    style: TextStyle(color: AppTheme.primary),
                  ),
                ),
              ],
            ),
          );
        }

        final requests = snapshot.data ?? [];

        if (requests.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceVariantDark,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.inbox_outlined,
                    size: 28,
                    color: AppTheme.textMutedDark,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  'No requests yet',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.textPrimaryDark,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Requests you send will appear here',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.textMutedDark,
                  ),
                ),
              ],
            ),
          );
        }

        // Group by status
        final pending = requests
            .where((r) => r.requestStatus == PaymentRequestStatus.pending)
            .toList();
        final others = requests
            .where((r) => r.requestStatus != PaymentRequestStatus.pending)
            .toList();

        return RefreshIndicator(
          color: AppTheme.primary,
          backgroundColor: AppTheme.surfaceDark,
          onRefresh: () async => _refresh(),
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              if (pending.isNotEmpty) ...[
                _SectionHeader(
                  title: 'Awaiting Payment',
                  count: pending.length,
                ),
                const SizedBox(height: 8),
                ...pending.map((r) => _RequestCard(request: r)),
                const SizedBox(height: 20),
              ],
              if (others.isNotEmpty) ...[
                _SectionHeader(title: 'Past Requests', count: others.length),
                const SizedBox(height: 8),
                ...others.map((r) => _RequestCard(request: r)),
              ],
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSkeleton() {
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      itemCount: 5,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, __) => Container(
        height: 76,
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final int count;

  const _SectionHeader({required this.title, required this.count});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Text(
          title,
          style: theme.textTheme.titleSmall?.copyWith(
            color: AppTheme.textPrimaryDark,
            fontWeight: FontWeight.w600,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: AppTheme.surfaceVariantDark,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '$count',
            style: theme.textTheme.labelSmall?.copyWith(
              color: AppTheme.textSecondaryDark,
            ),
          ),
        ),
      ],
    );
  }
}

class _RequestCard extends StatelessWidget {
  final PaymentRequestModel request;

  const _RequestCard({required this.request});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final status = request.requestStatus;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E1E2A)),
      ),
      child: Row(
        children: [
          // Avatar
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Color(request.recipientAvatarColor).withAlpha(51),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                request.recipientInitials,
                style: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Color(request.recipientAvatarColor),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request.recipientName,
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.textPrimaryDark,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  request.note.isNotEmpty
                      ? request.note
                      : request.recipientHandle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.textMutedDark,
                    fontSize: 11,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
          ),

          const SizedBox(width: 10),

          // Amount + status
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                request.formattedAmount,
                style: theme.textTheme.titleSmall?.copyWith(
                  color: AppTheme.textPrimaryDark,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: status.color.withAlpha(30),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  status.label,
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: status.color,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
