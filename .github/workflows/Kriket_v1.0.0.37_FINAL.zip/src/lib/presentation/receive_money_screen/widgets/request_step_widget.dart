import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../services/supabase_service.dart';
import '../models/payment_request_model.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RequestStepWidget extends StatefulWidget {
  final void Function(Map<String, dynamic> contact, double amount, String note)
  onRequestCreated;

  const RequestStepWidget({super.key, required this.onRequestCreated});

  @override
  State<RequestStepWidget> createState() => _RequestStepWidgetState();
}

class _RequestStepWidgetState extends State<RequestStepWidget> {
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();
  final _searchController = TextEditingController();
  Map<String, dynamic>? _selectedContact;
  List<Map<String, dynamic>> _allContacts = [];
  List<Map<String, dynamic>> _filteredContacts = [];
  bool _isLoading = false;
  bool _loadingContacts = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadContacts();
    _searchController.addListener(_onSearch);
  }

  Future<void> _loadContacts() async {
    try {
      final currentUserId = Supabase.instance.client.auth.currentUser?.id;
      if (currentUserId == null) {
        if (mounted) setState(() => _loadingContacts = false);
        return;
      }

      final response = await Supabase.instance.client
          .from('user_profiles')
          .select('id, full_name, email, avatar_color')
          .neq('id', currentUserId)
          .order('full_name', ascending: true)
          .limit(50);

      final contacts = (response as List).map((row) {
        final map = row as Map<String, dynamic>;
        final name =
            (map['full_name'] as String? ??
                    map['email'] as String? ??
                    'Unknown')
                .trim();
        final email = map['email'] as String? ?? '';
        final initials = _initials(name);
        final color = (map['avatar_color'] as int?) ?? 0xFF6C5CE7;
        return {
          'id': map['id'] as String,
          'name': name,
          'handle': email.isNotEmpty ? '@${email.split('@').first}' : '',
          'avatarColor': color,
          'initials': initials,
        };
      }).toList();

      if (mounted) {
        setState(() {
          _allContacts = contacts;
          _filteredContacts = contacts;
          _loadingContacts = false;
        });
      }
    } catch (e) {
      debugPrint('[RequestStep] Failed to load contacts: $e');
      if (mounted) setState(() => _loadingContacts = false);
    }
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }

  void _onSearch() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredContacts = query.isEmpty
          ? _allContacts
          : _allContacts.where((c) {
              return (c['name'] as String).toLowerCase().contains(query) ||
                  (c['handle'] as String).toLowerCase().contains(query);
            }).toList();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _noteController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _ensureUserProfileExists(String userId) async {
    try {
      final client = SupabaseService.instance.client;
      final user = client.auth.currentUser;

      await client
          .from('user_profiles')
          .upsert(
            {
              'id': userId,
              'email': user?.email ?? '',
              'full_name':
                  (user?.userMetadata?['full_name'] as String?) ??
                  (user?.email?.split('@').first ?? ''),
            },
            onConflict: 'id',
            ignoreDuplicates: true,
          );
    } catch (e) {
      debugPrint('[RequestStep] ensure_user_profile upsert: $e');
    }
  }

  Future<void> _onSendRequest() async {
    final amountText = _amountController.text.trim();
    if (_selectedContact == null) {
      setState(() => _error = 'Please select a contact');
      return;
    }
    final amount = double.tryParse(amountText);
    if (amount == null || amount <= 0) {
      setState(() => _error = 'Enter a valid amount');
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final client = SupabaseService.instance.client;
      final userId = client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not authenticated');

      await _ensureUserProfileExists(userId);

      final link =
          'https://kriket7980.builtwithrocket.new/pay/${DateTime.now().millisecondsSinceEpoch}';
      final contact = _selectedContact!;

      final rawColor = contact['avatarColor'] as int;

      final model = PaymentRequestModel(
        id: '',
        requesterId: userId,
        recipientName: contact['name'] as String,
        recipientHandle: contact['handle'] as String,
        recipientAvatarColor: rawColor,
        recipientInitials: contact['initials'] as String,
        amount: amount,
        note: _noteController.text.trim(),
        requestStatus: PaymentRequestStatus.pending,
        receiveLink: link,
        createdAt: DateTime.now(),
        expiresAt: DateTime.now().add(const Duration(days: 7)),
      );

      final insertData = model.toInsertMap();
      debugPrint('[RequestStep] Inserting payment_request: $insertData');

      final response = await client
          .from('payment_requests')
          .insert(insertData)
          .select()
          .single();

      debugPrint('[RequestStep] Insert success: $response');

      if (mounted) {
        widget.onRequestCreated(contact, amount, _noteController.text.trim());
      }
    } on Exception catch (e) {
      debugPrint('[RequestStep] Send request error: $e');
      if (mounted) {
        final msg = _friendlyError(e.toString());
        setState(() => _error = msg);
      }
    } catch (e) {
      debugPrint('[RequestStep] Send request unexpected error: $e');
      if (mounted) {
        setState(() => _error = 'Failed to send request. Try again.');
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  String _friendlyError(String raw) {
    if (raw.contains('not authenticated') ||
        raw.contains('JWT') ||
        raw.contains('auth')) {
      return 'Session expired. Please log in again.';
    }
    if (raw.contains('foreign key') || raw.contains('violates')) {
      return 'Account setup incomplete. Please try again.';
    }
    if (raw.contains('network') ||
        raw.contains('SocketException') ||
        raw.contains('connection')) {
      return 'No internet connection. Check your network.';
    }
    if (raw.contains('timeout')) {
      return 'Request timed out. Try again.';
    }
    return 'Failed to send request. Try again.';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Request from',
            style: theme.textTheme.titleMedium?.copyWith(
              color: AppTheme.textPrimaryDark,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),

          // Search contacts
          Container(
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF2A2A3A)),
            ),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 14,
                color: AppTheme.textPrimaryDark,
              ),
              decoration: const InputDecoration(
                hintText: 'Search contacts',
                hintStyle: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 14,
                  color: AppTheme.textMutedDark,
                ),
                prefixIcon: Icon(
                  Icons.search_rounded,
                  color: AppTheme.textSecondaryDark,
                  size: 20,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Contact list
          SizedBox(
            height: 200,
            child: _loadingContacts
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  )
                : _filteredContacts.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.person_search_outlined,
                          size: 40,
                          color: AppTheme.textMutedDark,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _allContacts.isEmpty
                              ? 'No other users found'
                              : 'No contacts found',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textMutedDark,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.separated(
                    itemCount: _filteredContacts.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 6),
                    itemBuilder: (context, index) {
                      final contact = _filteredContacts[index];
                      final isSelected =
                          _selectedContact?['id'] == contact['id'];
                      return GestureDetector(
                        onTap: () => setState(() => _selectedContact = contact),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppTheme.primary.withAlpha(20)
                                : AppTheme.surfaceDark,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isSelected
                                  ? AppTheme.primary.withAlpha(100)
                                  : const Color(0xFF1E1E2A),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Color(
                                    contact['avatarColor'] as int,
                                  ).withAlpha(51),
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: Text(
                                    contact['initials'] as String,
                                    style: TextStyle(
                                      fontFamily: 'Manrope',
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: Color(
                                        contact['avatarColor'] as int,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      contact['name'] as String,
                                      style: theme.textTheme.titleSmall
                                          ?.copyWith(
                                            color: AppTheme.textPrimaryDark,
                                            fontSize: 13,
                                          ),
                                    ),
                                    Text(
                                      contact['handle'] as String,
                                      style: theme.textTheme.bodySmall
                                          ?.copyWith(
                                            color: AppTheme.textMutedDark,
                                            fontSize: 11,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                              if (isSelected)
                                const Icon(
                                  Icons.check_circle_rounded,
                                  color: AppTheme.primary,
                                  size: 18,
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),

          const SizedBox(height: 20),

          // Amount
          Text(
            'Amount',
            style: theme.textTheme.titleSmall?.copyWith(
              color: AppTheme.textPrimaryDark,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF2A2A3A)),
            ),
            child: TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimaryDark,
              ),
              decoration: const InputDecoration(
                hintText: '0.00',
                hintStyle: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textMutedDark,
                ),
                prefixText: '\$ ',
                prefixStyle: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.primary,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 16,
                ),
              ),
            ),
          ),

          const SizedBox(height: 14),

          // Note
          Text(
            'Note (optional)',
            style: theme.textTheme.titleSmall?.copyWith(
              color: AppTheme.textPrimaryDark,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF2A2A3A)),
            ),
            child: TextField(
              controller: _noteController,
              maxLines: 2,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 14,
                color: AppTheme.textPrimaryDark,
              ),
              decoration: const InputDecoration(
                hintText: 'What is this for?',
                hintStyle: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 14,
                  color: AppTheme.textMutedDark,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
              ),
            ),
          ),

          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(
              _error!,
              style: const TextStyle(
                fontFamily: 'Manrope',
                fontSize: 12,
                color: AppTheme.error,
              ),
            ),
          ],

          const SizedBox(height: 24),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _onSendRequest,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                foregroundColor: const Color(0xFF003322),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xFF003322),
                      ),
                    )
                  : const Text(
                      'Send Request',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
