import 'package:flutter/material.dart';

enum PaymentRequestStatus { pending, paid, declined, expired, cancelled }

extension PaymentRequestStatusExt on PaymentRequestStatus {
  String get label {
    switch (this) {
      case PaymentRequestStatus.pending:
        return 'Pending';
      case PaymentRequestStatus.paid:
        return 'Paid';
      case PaymentRequestStatus.declined:
        return 'Declined';
      case PaymentRequestStatus.expired:
        return 'Expired';
      case PaymentRequestStatus.cancelled:
        return 'Cancelled';
    }
  }

  Color get color {
    switch (this) {
      case PaymentRequestStatus.pending:
        return const Color(0xFFF59E0B);
      case PaymentRequestStatus.paid:
        return const Color(0xFF00C97A);
      case PaymentRequestStatus.declined:
        return const Color(0xFFEF4444);
      case PaymentRequestStatus.expired:
        return const Color(0xFF8888A0);
      case PaymentRequestStatus.cancelled:
        return const Color(0xFF8888A0);
    }
  }

  static PaymentRequestStatus fromString(String? value) {
    switch (value) {
      case 'paid':
        return PaymentRequestStatus.paid;
      case 'declined':
        return PaymentRequestStatus.declined;
      case 'expired':
        return PaymentRequestStatus.expired;
      case 'cancelled':
        return PaymentRequestStatus.cancelled;
      default:
        return PaymentRequestStatus.pending;
    }
  }
}

class PaymentRequestModel {
  final String id;
  final String requesterId;
  final String recipientName;
  final String recipientHandle;
  final int recipientAvatarColor;
  final String recipientInitials;
  final double amount;
  final String note;
  final PaymentRequestStatus requestStatus;
  final String receiveLink;
  final DateTime createdAt;
  final DateTime expiresAt;

  const PaymentRequestModel({
    required this.id,
    required this.requesterId,
    required this.recipientName,
    required this.recipientHandle,
    required this.recipientAvatarColor,
    required this.recipientInitials,
    required this.amount,
    required this.note,
    required this.requestStatus,
    required this.receiveLink,
    required this.createdAt,
    required this.expiresAt,
  });

  factory PaymentRequestModel.fromJson(Map<String, dynamic> json) {
    return PaymentRequestModel(
      id: json['id'] as String,
      requesterId: json['requester_id'] as String,
      recipientName: json['recipient_name'] as String,
      recipientHandle: json['recipient_handle'] as String,
      recipientAvatarColor:
          (json['recipient_avatar_color'] as num?)?.toInt() ?? 0xFF6C5CE7,
      recipientInitials: json['recipient_initials'] as String? ?? '??',
      amount: (json['amount'] as num).toDouble(),
      note: json['note'] as String? ?? '',
      requestStatus: PaymentRequestStatusExt.fromString(
        json['request_status'] as String?,
      ),
      receiveLink: json['receive_link'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      expiresAt: DateTime.parse(json['expires_at'] as String),
    );
  }

  Map<String, dynamic> toInsertMap() {
    return {
      'requester_id': requesterId,
      'recipient_name': recipientName,
      'recipient_handle': recipientHandle,
      'recipient_avatar_color': recipientAvatarColor,
      'recipient_initials': recipientInitials,
      'amount': amount,
      'note': note,
      'request_status': requestStatus.name,
      'receive_link': receiveLink,
      'expires_at': expiresAt.toIso8601String(),
    };
  }

  String get formattedAmount => '\$${amount.toStringAsFixed(2)}';

  String get timeAgo {
    final diff = DateTime.now().difference(createdAt);
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }
}
