class KriketAssetBalance {
  final String asset;
  final String network;
  final double available;
  final double locked;
  final DateTime? updatedAt;
  const KriketAssetBalance({
    required this.asset, required this.network, required this.available,
    this.locked = 0, this.updatedAt,
  });
}

class KriketTransfer {
  final String id;
  final String status;
  final String asset;
  final double amount;
  final String destination;
  final String? txHash;
  const KriketTransfer({
    required this.id, required this.status, required this.asset,
    required this.amount, required this.destination, this.txHash,
  });
}

class KriketExchangeQuote {
  final String from;
  final String to;
  final double amountIn;
  final double amountOut;
  final double fee;
  final DateTime expiresAt;
  const KriketExchangeQuote({
    required this.from, required this.to, required this.amountIn,
    required this.amountOut, required this.fee, required this.expiresAt,
  });
}

class KriketRiskAlert {
  final String id;
  final String severity;
  final String type;
  final String status;
  final String? userId;
  final String? txHash;
  final double? amount;
  final String description;
  const KriketRiskAlert({
    required this.id, required this.severity, required this.type,
    required this.status, required this.description,
    this.userId, this.txHash, this.amount,
  });
}
