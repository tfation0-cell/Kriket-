// App-wide string translations
class AppStrings {
  static const Map<String, Map<String, String>> _strings = {
    'en': {
      // Navigation
      'home': 'Home',
      'savings': 'Savings',
      'profile': 'Profile',
      'cards': 'Cards',

      // Profile screen sections
      'features': 'Features',
      'security': 'Security Settings',
      'notifications': 'Notifications',
      'push_notifications': 'Push Notifications',
      'push_notifications_sub': 'App alerts and updates',
      'transaction_alerts': 'Transaction Alerts',
      'transaction_alerts_sub': 'Get notified on every transaction',
      'savings_reminders': 'Savings Reminders',
      'savings_reminders_sub': 'Weekly savings goal reminders',

      // Feature cards
      'exchange_rates': 'Exchange Rates',
      'analytics': 'Analytics',
      'virtual_card': 'Virtual Card',
      'statements': 'Statements',
      'kyc': 'KYC Verification',
      'support': 'Live Support',

      // Settings
      'dark_mode': 'Dark Mode',
      'dark_theme_active': 'Dark theme active',
      'light_theme_active': 'Light theme active',
      'language': 'Language',
      'biometric': 'Biometric Login',
      'biometric_sub': 'Use fingerprint or Face ID',
      'settings': 'Settings',
      'logout': 'Log Out',

      // Logout dialog
      'log_out_q': 'Log out?',
      'log_out_desc': 'You will be signed out of your account.',
      'cancel': 'Cancel',
      'log_out': 'Log out',
      'logout_failed': 'Logout failed. Please try again.',
      'biometric_mobile_only':
          'Biometric login is available on mobile devices only.',
      'biometric_enabled': 'Biometric login enabled',
      'biometric_disabled': 'Biometric login disabled',

      // Home screen
      'good_morning': 'Good morning 👋',
      'good_afternoon': 'Good afternoon 👋',
      'good_evening': 'Good evening 👋',
      'current_balance': 'Current Balance',
      'add_money': 'Add Money',
      'send': 'Send',
      'receive': 'Receive',
      'swap': 'Swap',
      'balance': 'Total Balance',
      'recent_transactions': 'Recent Transactions',
      'see_all': 'See all',
      'no_transactions': 'No transactions yet',
      'could_not_load': 'Could not load transactions',
      'retry': 'Retry',

      // Savings screen
      'savings_subtitle': 'Track your goals, one pocket at a time',
      'total_saved': 'Total Saved',
      'overall': 'overall',
      'of': 'of',
      'total_goal': 'total goal',
      'my_pockets': 'My Pockets',
      'active': 'active',
      'new_pocket': 'New Pocket',
      'no_pockets': 'No pockets yet',
      'no_pockets_sub':
          'Create your first savings pocket\nto start tracking your goals',
      'failed_load_pockets': 'Failed to load pockets',
      'not_signed_in': 'Not signed in',

      // Send money screen
      'send_money': 'Send Money',
      'send_success': 'Sent Successfully!',
      'money_sent_to': 'Money sent to',

      // Receive money screen
      'receive_money': 'Receive Money',
      'request': 'Request',
      'tracker': 'Tracker',

      // Exchange rates screen
      'exchange_rates_title': 'Exchange Rates',
      'base_currency': 'Base Currency',
      'last_updated': 'Last updated',
      'live': 'LIVE',
      'fallback': 'FALLBACK',
      'refresh': 'Refresh',
      'search_currency': 'Search currency...',
      'no_rates': 'No rates available',

      // Spending analytics screen
      'spending_analytics': 'Spending Analytics',
      'spending_overview': 'Spending Overview',
      'this_month': 'This Month',
      'last_month': 'Last Month',
      'total_spending': 'Total Spending',
      'categories': 'Categories',
      'monthly_trend': 'Monthly Trend',
      'food': 'Food',
      'transport': 'Transport',
      'shopping': 'Shopping',
      'utilities': 'Utilities',
      'entertainment': 'Entertainment',
      'other': 'Other',

      // Virtual card screen
      'virtual_card_title': 'Virtual Card',
      'card_number': 'Card Number',
      'expiry': 'Expiry',
      'cvv': 'CVV',
      'card_holder': 'Card Holder',
      'freeze_card': 'Freeze Card',
      'unfreeze_card': 'Unfreeze Card',
      'card_frozen': 'Card Frozen',
      'card_active': 'Card Active',
      'card_controls': 'Card Controls',
      'online_payments': 'Online Payments',
      'contactless': 'Contactless',
      'international': 'International Payments',
      'tap_to_reveal': 'Tap card to reveal details',
      'copied': 'copied!',
      'spending_limit': 'Spending Limit',
      'daily_limit': 'Daily Limit',
      'monthly_limit': 'Monthly Limit',
      'set_limit': 'Set Limit',

      // PDF Statements screen
      'pdf_statements': 'Statements',
      'statement_ready': 'Statement Ready',
      'statement_generated': 'statement has been generated.',
      'share': 'Share',
      'download': 'Download',
      'generate_statement': 'Generate Statement',
      'download_pdf': 'Download PDF',
      'transactions': 'transactions',

      // KYC screen
      'kyc_title': 'Identity Verification',
      'kyc_sub': 'Verify your identity to unlock all features',
      'upload_id': 'Upload ID Document',
      'upload_selfie': 'Upload Selfie',
      'submit': 'Submit',
      'personal_info': 'Personal Info',
      'id_document': 'ID Document',
      'selfie': 'Selfie',
      'review': 'Review',
      'kyc_submitted': 'Verification Submitted',
      'kyc_submitted_sub':
          'Your documents are under review. We\'ll notify you within 24-48 hours.',
      'id_uploaded': 'ID document uploaded!',
      'selfie_uploaded': 'Selfie uploaded!',
      'upload_id_desc':
          'Upload a clear photo of your national ID, passport, or driver\'s license.',
      'upload_selfie_desc':
          'Take a selfie holding your ID document next to your face.',
      'review_submit': 'Review & Submit',
      'review_desc': 'Please review your uploaded documents before submitting.',
      'id_status': 'ID Document',
      'selfie_status': 'Selfie',
      'uploaded': 'Uploaded',
      'not_uploaded': 'Not uploaded',
      'submit_verification': 'Submit Verification',
      'submitting': 'Submitting...',

      // Security settings screen
      'security_title': 'Security Settings',
      'two_fa': 'Two-Factor Authentication',
      'trusted_devices': 'Trusted Devices',
      'login_history': 'Login History',
      'two_fa_desc': 'Add an extra layer of security to your account',
      'two_fa_enabled': '2FA is enabled',
      'two_fa_disabled': '2FA is disabled',
      'sms_auth': 'SMS Authentication',
      'app_auth': 'Authenticator App',
      'current_device': 'Current Device',
      'remove': 'Remove',
      'success': 'Success',
      'failed': 'Failed',
      'now': 'Now',

      // Live support chat screen
      'support_title': 'Live Support',
      'chat_placeholder': 'Type a message...',
      'type_here': 'Type here...',
      'support_agent': 'Support Agent',
      'welcome_message':
          'Hello! 👋 Welcome to kriket support. How can I help you today?',
      'quick_reply_send': 'How do I send money?',
      'quick_reply_card': 'My card is not working',
      'quick_reply_funds': 'How to add funds?',
      'quick_reply_kyc': 'Account verification help',

      // Status
      'verified': 'Verified',
      'pending': 'Pending',
      'declined': 'Declined',
    },

    'sq': {
      // Navigation
      'home': 'Kryefaqja',
      'savings': 'Kursime',
      'profile': 'Profili',
      'cards': 'Kartat',

      // Profile screen sections
      'features': 'Veçoritë',
      'security': 'Cilësimet e Sigurisë',
      'notifications': 'Njoftimet',
      'push_notifications': 'Njoftimet Push',
      'push_notifications_sub': 'Alarme dhe përditësime të aplikacionit',
      'transaction_alerts': 'Alarme Transaksionesh',
      'transaction_alerts_sub': 'Njoftohuni për çdo transaksion',
      'savings_reminders': 'Kujtues Kursimesh',
      'savings_reminders_sub': 'Kujtues javor për qëllimet e kursimit',

      // Feature cards
      'exchange_rates': 'Kurset e Këmbimit',
      'analytics': 'Analitika',
      'virtual_card': 'Kartë Virtuale',
      'statements': 'Deklarata',
      'kyc': 'Verifikimi KYC',
      'support': 'Mbështetje Live',

      // Settings
      'dark_mode': 'Modaliteti i Errët',
      'dark_theme_active': 'Tema e errët aktive',
      'light_theme_active': 'Tema e ndritshme aktive',
      'language': 'Gjuha',
      'biometric': 'Hyrje Biometrike',
      'biometric_sub': 'Përdor gjurmën e gishtit ose Face ID',
      'settings': 'Cilësimet',
      'logout': 'Dilni',

      // Logout dialog
      'log_out_q': 'Dilni?',
      'log_out_desc': 'Do të dilni nga llogaria juaj.',
      'cancel': 'Anulo',
      'log_out': 'Dil',
      'logout_failed': 'Dalja dështoi. Ju lutemi provoni përsëri.',
      'biometric_mobile_only':
          'Hyrja biometrike është e disponueshme vetëm në pajisjet mobile.',
      'biometric_enabled': 'Hyrja biometrike u aktivizua',
      'biometric_disabled': 'Hyrja biometrike u çaktivizua',

      // Home screen
      'good_morning': 'Mirëmëngjes 👋',
      'good_afternoon': 'Mirëdita 👋',
      'good_evening': 'Mirëmbrëma 👋',
      'current_balance': 'Bilanci Aktual',
      'add_money': 'Shto Para',
      'send': 'Dërgo',
      'receive': 'Merr',
      'swap': 'Këmbej',
      'balance': 'Bilanci Total',
      'recent_transactions': 'Transaksionet e Fundit',
      'see_all': 'Shiko të gjitha',
      'no_transactions': 'Ende nuk ka transaksione',
      'could_not_load': 'Nuk mund të ngarkohen transaksionet',
      'retry': 'Provo Përsëri',

      // Savings screen
      'savings_subtitle': 'Gjurmo qëllimet tuaja, një xhep në një kohë',
      'total_saved': 'Totali i Kursyer',
      'overall': 'gjithsej',
      'of': 'nga',
      'total_goal': 'qëllimi total',
      'my_pockets': 'Xhepat e Mi',
      'active': 'aktiv',
      'new_pocket': 'Xhep i Ri',
      'no_pockets': 'Ende nuk ka xhepa',
      'no_pockets_sub':
          'Krijoni xhepin tuaj të parë të kursimeve\npër të filluar gjurmimin e qëllimeve',
      'failed_load_pockets': 'Dështoi ngarkimi i xhepave',
      'not_signed_in': 'Nuk jeni identifikuar',

      // Send money screen
      'send_money': 'Dërgo Para',
      'send_success': 'U Dërgua me Sukses!',
      'money_sent_to': 'Paratë u dërguan te',

      // Receive money screen
      'receive_money': 'Merr Para',
      'request': 'Kërkesë',
      'tracker': 'Gjurmues',

      // Exchange rates screen
      'exchange_rates_title': 'Kurset e Këmbimit',
      'base_currency': 'Monedha Bazë',
      'last_updated': 'Përditësuar së fundmi',
      'live': 'LIVE',
      'fallback': 'REZERVË',
      'refresh': 'Rifresko',
      'search_currency': 'Kërko monedhë...',
      'no_rates': 'Nuk ka kurse të disponueshme',

      // Spending analytics screen
      'spending_analytics': 'Analitika e Shpenzimeve',
      'spending_overview': 'Pasqyra e Shpenzimeve',
      'this_month': 'Këtë Muaj',
      'last_month': 'Muajin e Kaluar',
      'total_spending': 'Shpenzimet Totale',
      'categories': 'Kategoritë',
      'monthly_trend': 'Tendenca Mujore',
      'food': 'Ushqim',
      'transport': 'Transport',
      'shopping': 'Blerje',
      'utilities': 'Shërbime',
      'entertainment': 'Argëtim',
      'other': 'Tjetër',

      // Virtual card screen
      'virtual_card_title': 'Kartë Virtuale',
      'card_number': 'Numri i Kartës',
      'expiry': 'Skadenca',
      'cvv': 'CVV',
      'card_holder': 'Mbajtësi i Kartës',
      'freeze_card': 'Blloko Kartën',
      'unfreeze_card': 'Zhblloko Kartën',
      'card_frozen': 'Karta e Bllokuar',
      'card_active': 'Karta Aktive',
      'card_controls': 'Kontrollet e Kartës',
      'online_payments': 'Pagesat Online',
      'contactless': 'Pa Kontakt',
      'international': 'Pagesa Ndërkombëtare',
      'tap_to_reveal': 'Prekni kartën për të zbuluar detajet',
      'copied': 'u kopjua!',
      'spending_limit': 'Kufiri i Shpenzimeve',
      'daily_limit': 'Kufiri Ditor',
      'monthly_limit': 'Kufiri Mujor',
      'set_limit': 'Vendos Kufirin',

      // PDF Statements screen
      'pdf_statements': 'Deklarata',
      'statement_ready': 'Deklarata Gati',
      'statement_generated': 'deklarata është gjeneruar.',
      'share': 'Ndaj',
      'download': 'Shkarko',
      'generate_statement': 'Gjenero Deklaratë',
      'download_pdf': 'Shkarko PDF',
      'transactions': 'transaksione',

      // KYC screen
      'kyc_title': 'Verifikimi i Identitetit',
      'kyc_sub':
          'Verifikoni identitetin tuaj për të zhbllokuar të gjitha veçoritë',
      'upload_id': 'Ngarko Dokumentin e ID',
      'upload_selfie': 'Ngarko Selfie',
      'submit': 'Dërgo',
      'personal_info': 'Informacioni Personal',
      'id_document': 'Dokument ID',
      'selfie': 'Selfie',
      'review': 'Rishikim',
      'kyc_submitted': 'Verifikimi u Dërgua',
      'kyc_submitted_sub':
          'Dokumentet tuaja janë duke u shqyrtuar. Do t\'ju njoftojmë brenda 24-48 orëve.',
      'id_uploaded': 'Dokumenti i ID u ngarkua!',
      'selfie_uploaded': 'Selfie u ngarkua!',
      'upload_id_desc':
          'Ngarkoni një foto të qartë të ID-së kombëtare, pasaportës ose patentës.',
      'upload_selfie_desc':
          'Bëni një selfie duke mbajtur dokumentin e ID-së pranë fytyrës.',
      'review_submit': 'Rishiko dhe Dërgo',
      'review_desc':
          'Ju lutemi rishikoni dokumentet e ngarkuara para dërgimit.',
      'id_status': 'Dokument ID',
      'selfie_status': 'Selfie',
      'uploaded': 'Ngarkuar',
      'not_uploaded': 'Nuk është ngarkuar',
      'submit_verification': 'Dërgo Verifikimin',
      'submitting': 'Duke dërguar...',

      // Security settings screen
      'security_title': 'Cilësimet e Sigurisë',
      'two_fa': 'Autentifikimi me Dy Faktorë',
      'trusted_devices': 'Pajisjet e Besuara',
      'login_history': 'Historia e Hyrjeve',
      'two_fa_desc': 'Shtoni një shtresë shtesë sigurie në llogarinë tuaj',
      'two_fa_enabled': '2FA është aktivizuar',
      'two_fa_disabled': '2FA është çaktivizuar',
      'sms_auth': 'Autentifikim me SMS',
      'app_auth': 'Aplikacion Autentifikues',
      'current_device': 'Pajisja Aktuale',
      'remove': 'Hiq',
      'success': 'Sukses',
      'failed': 'Dështoi',
      'now': 'Tani',

      // Live support chat screen
      'support_title': 'Mbështetje Live',
      'chat_placeholder': 'Shkruaj një mesazh...',
      'type_here': 'Shkruaj këtu...',
      'support_agent': 'Agjent Mbështetjeje',
      'welcome_message':
          'Përshëndetje! 👋 Mirë se vini në mbështetjen e kriket. Si mund t\'ju ndihmoj sot?',
      'quick_reply_send': 'Si të dërgoj para?',
      'quick_reply_card': 'Karta ime nuk funksionon',
      'quick_reply_funds': 'Si të shtoj fonde?',
      'quick_reply_kyc': 'Ndihmë për verifikimin e llogarisë',

      // Status
      'verified': 'Verifikuar',
      'pending': 'Në Pritje',
      'declined': 'Refuzuar',
    },

    'el': {
      // Navigation
      'home': 'Αρχική',
      'savings': 'Αποταμιεύσεις',
      'profile': 'Προφίλ',
      'cards': 'Κάρτες',

      // Profile screen sections
      'features': 'Λειτουργίες',
      'security': 'Ρυθμίσεις Ασφαλείας',
      'notifications': 'Ειδοποιήσεις',
      'push_notifications': 'Push Ειδοποιήσεις',
      'push_notifications_sub': 'Ειδοποιήσεις και ενημερώσεις εφαρμογής',
      'transaction_alerts': 'Ειδοποιήσεις Συναλλαγών',
      'transaction_alerts_sub': 'Ενημερωθείτε για κάθε συναλλαγή',
      'savings_reminders': 'Υπενθυμίσεις Αποταμίευσης',
      'savings_reminders_sub': 'Εβδομαδιαίες υπενθυμίσεις στόχων αποταμίευσης',

      // Feature cards
      'exchange_rates': 'Συναλλαγματικές Ισοτιμίες',
      'analytics': 'Αναλυτικά',
      'virtual_card': 'Εικονική Κάρτα',
      'statements': 'Καταστάσεις',
      'kyc': 'Επαλήθευση KYC',
      'support': 'Ζωντανή Υποστήριξη',

      // Settings
      'dark_mode': 'Σκοτεινή Λειτουργία',
      'dark_theme_active': 'Σκοτεινό θέμα ενεργό',
      'light_theme_active': 'Φωτεινό θέμα ενεργό',
      'language': 'Γλώσσα',
      'biometric': 'Βιομετρική Σύνδεση',
      'biometric_sub': 'Χρησιμοποιήστε δακτυλικό αποτύπωμα ή Face ID',
      'settings': 'Ρυθμίσεις',
      'logout': 'Αποσύνδεση',

      // Logout dialog
      'log_out_q': 'Αποσύνδεση;',
      'log_out_desc': 'Θα αποσυνδεθείτε από τον λογαριασμό σας.',
      'cancel': 'Ακύρωση',
      'log_out': 'Αποσύνδεση',
      'logout_failed': 'Η αποσύνδεση απέτυχε. Παρακαλώ δοκιμάστε ξανά.',
      'biometric_mobile_only':
          'Η βιομετρική σύνδεση είναι διαθέσιμη μόνο σε κινητές συσκευές.',
      'biometric_enabled': 'Η βιομετρική σύνδεση ενεργοποιήθηκε',
      'biometric_disabled': 'Η βιομετρική σύνδεση απενεργοποιήθηκε',

      // Home screen
      'good_morning': 'Καλημέρα 👋',
      'good_afternoon': 'Καλό απόγευμα 👋',
      'good_evening': 'Καλησπέρα 👋',
      'current_balance': 'Τρέχον Υπόλοιπο',
      'add_money': 'Προσθήκη Χρημάτων',
      'send': 'Αποστολή',
      'receive': 'Λήψη',
      'swap': 'Ανταλλαγή',
      'balance': 'Συνολικό Υπόλοιπο',
      'recent_transactions': 'Πρόσφατες Συναλλαγές',
      'see_all': 'Δείτε όλα',
      'no_transactions': 'Δεν υπάρχουν συναλλαγές ακόμα',
      'could_not_load': 'Δεν ήταν δυνατή η φόρτωση συναλλαγών',
      'retry': 'Επανάληψη',

      // Savings screen
      'savings_subtitle': 'Παρακολουθήστε τους στόχους σας, μία τσέπη τη φορά',
      'total_saved': 'Συνολικά Αποταμιευμένα',
      'overall': 'συνολικά',
      'of': 'από',
      'total_goal': 'συνολικός στόχος',
      'my_pockets': 'Οι Τσέπες Μου',
      'active': 'ενεργές',
      'new_pocket': 'Νέα Τσέπη',
      'no_pockets': 'Δεν υπάρχουν τσέπες ακόμα',
      'no_pockets_sub':
          'Δημιουργήστε την πρώτη σας τσέπη αποταμίευσης\nγια να ξεκινήσετε την παρακολούθηση στόχων',
      'failed_load_pockets': 'Αποτυχία φόρτωσης τσεπών',
      'not_signed_in': 'Δεν είστε συνδεδεμένοι',

      // Send money screen
      'send_money': 'Αποστολή Χρημάτων',
      'send_success': 'Εστάλη Επιτυχώς!',
      'money_sent_to': 'Τα χρήματα εστάλησαν στον',

      // Receive money screen
      'receive_money': 'Λήψη Χρημάτων',
      'request': 'Αίτημα',
      'tracker': 'Παρακολούθηση',

      // Exchange rates screen
      'exchange_rates_title': 'Συναλλαγματικές Ισοτιμίες',
      'base_currency': 'Βασικό Νόμισμα',
      'last_updated': 'Τελευταία ενημέρωση',
      'live': 'ΖΩΝΤΑΝΑ',
      'fallback': 'ΕΦΕΔΡΙΚΟ',
      'refresh': 'Ανανέωση',
      'search_currency': 'Αναζήτηση νομίσματος...',
      'no_rates': 'Δεν υπάρχουν διαθέσιμες ισοτιμίες',

      // Spending analytics screen
      'spending_analytics': 'Αναλυτικά Δαπανών',
      'spending_overview': 'Επισκόπηση Δαπανών',
      'this_month': 'Αυτόν τον Μήνα',
      'last_month': 'Προηγούμενο Μήνα',
      'total_spending': 'Συνολικές Δαπάνες',
      'categories': 'Κατηγορίες',
      'monthly_trend': 'Μηνιαία Τάση',
      'food': 'Τρόφιμα',
      'transport': 'Μεταφορές',
      'shopping': 'Αγορές',
      'utilities': 'Υπηρεσίες',
      'entertainment': 'Ψυχαγωγία',
      'other': 'Άλλο',

      // Virtual card screen
      'virtual_card_title': 'Εικονική Κάρτα',
      'card_number': 'Αριθμός Κάρτας',
      'expiry': 'Λήξη',
      'cvv': 'CVV',
      'card_holder': 'Κάτοχος Κάρτας',
      'freeze_card': 'Πάγωμα Κάρτας',
      'unfreeze_card': 'Ξεπάγωμα Κάρτας',
      'card_frozen': 'Κάρτα Παγωμένη',
      'card_active': 'Κάρτα Ενεργή',
      'card_controls': 'Έλεγχοι Κάρτας',
      'online_payments': 'Διαδικτυακές Πληρωμές',
      'contactless': 'Ανέπαφες',
      'international': 'Διεθνείς Πληρωμές',
      'tap_to_reveal': 'Πατήστε κάρτα για αποκάλυψη στοιχείων',
      'copied': 'αντιγράφηκε!',
      'spending_limit': 'Όριο Δαπανών',
      'daily_limit': 'Ημερήσιο Όριο',
      'monthly_limit': 'Μηνιαίο Όριο',
      'set_limit': 'Ορισμός Ορίου',

      // PDF Statements screen
      'pdf_statements': 'Καταστάσεις',
      'statement_ready': 'Κατάσταση Έτοιμη',
      'statement_generated': 'η κατάσταση δημιουργήθηκε.',
      'share': 'Κοινοποίηση',
      'download': 'Λήψη',
      'generate_statement': 'Δημιουργία Κατάστασης',
      'download_pdf': 'Λήψη PDF',
      'transactions': 'συναλλαγές',

      // KYC screen
      'kyc_title': 'Επαλήθευση Ταυτότητας',
      'kyc_sub':
          'Επαληθεύστε την ταυτότητά σας για να ξεκλειδώσετε όλες τις λειτουργίες',
      'upload_id': 'Μεταφόρτωση Εγγράφου Ταυτότητας',
      'upload_selfie': 'Μεταφόρτωση Selfie',
      'submit': 'Υποβολή',
      'personal_info': 'Προσωπικές Πληροφορίες',
      'id_document': 'Έγγραφο Ταυτότητας',
      'selfie': 'Selfie',
      'review': 'Επισκόπηση',
      'kyc_submitted': 'Επαλήθευση Υποβλήθηκε',
      'kyc_submitted_sub':
          'Τα έγγραφά σας βρίσκονται υπό εξέταση. Θα σας ειδοποιήσουμε εντός 24-48 ωρών.',
      'id_uploaded': 'Το έγγραφο ταυτότητας μεταφορτώθηκε!',
      'selfie_uploaded': 'Το selfie μεταφορτώθηκε!',
      'upload_id_desc':
          'Μεταφορτώστε μια σαφή φωτογραφία της ταυτότητας, διαβατηρίου ή άδειας οδήγησης.',
      'upload_selfie_desc':
          'Τραβήξτε μια selfie κρατώντας το έγγραφο ταυτότητας δίπλα στο πρόσωπό σας.',
      'review_submit': 'Επισκόπηση και Υποβολή',
      'review_desc':
          'Παρακαλώ ελέγξτε τα μεταφορτωμένα έγγραφα πριν την υποβολή.',
      'id_status': 'Έγγραφο Ταυτότητας',
      'selfie_status': 'Selfie',
      'uploaded': 'Μεταφορτώθηκε',
      'not_uploaded': 'Δεν μεταφορτώθηκε',
      'submit_verification': 'Υποβολή Επαλήθευσης',
      'submitting': 'Υποβολή...',

      // Security settings screen
      'security_title': 'Ρυθμίσεις Ασφαλείας',
      'two_fa': 'Έλεγχος Ταυτότητας Δύο Παραγόντων',
      'trusted_devices': 'Αξιόπιστες Συσκευές',
      'login_history': 'Ιστορικό Συνδέσεων',
      'two_fa_desc':
          'Προσθέστε ένα επιπλέον επίπεδο ασφάλειας στον λογαριασμό σας',
      'two_fa_enabled': 'Το 2FA είναι ενεργοποιημένο',
      'two_fa_disabled': 'Το 2FA είναι απενεργοποιημένο',
      'sms_auth': 'Έλεγχος ταυτότητας SMS',
      'app_auth': 'Εφαρμογή Ελέγχου Ταυτότητας',
      'current_device': 'Τρέχουσα Συσκευή',
      'remove': 'Αφαίρεση',
      'success': 'Επιτυχία',
      'failed': 'Αποτυχία',
      'now': 'Τώρα',

      // Live support chat screen
      'support_title': 'Ζωντανή Υποστήριξη',
      'chat_placeholder': 'Πληκτρολογήστε ένα μήνυμα...',
      'type_here': 'Πληκτρολογήστε εδώ...',
      'support_agent': 'Πράκτορας Υποστήριξης',
      'welcome_message':
          'Γεια σας! 👋 Καλώς ήρθατε στην υποστήριξη kriket. Πώς μπορώ να σας βοηθήσω σήμερα;',
      'quick_reply_send': 'Πώς να στείλω χρήματα;',
      'quick_reply_card': 'Η κάρτα μου δεν λειτουργεί',
      'quick_reply_funds': 'Πώς να προσθέσω κεφάλαια;',
      'quick_reply_kyc': 'Βοήθεια επαλήθευσης λογαριασμού',

      // Status
      'verified': 'Επαληθευμένο',
      'pending': 'Εκκρεμεί',
      'declined': 'Απορρίφθηκε',
    },
  };

  static String get(String key, String languageCode) {
    return _strings[languageCode]?[key] ?? _strings['en']?[key] ?? key;
  }
}
