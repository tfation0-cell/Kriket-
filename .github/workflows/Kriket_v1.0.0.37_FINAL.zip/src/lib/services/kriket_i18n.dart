class KriketI18n {
  static const locale = 'en';
  static const Map<String, String> en = {
    'account_center': 'Kriket Account Center',
    'transaction_status': 'Transaction status',
    'my_pockets': 'My Pockets',
    'create_pocket': 'Create pocket',
    'card_iban': 'Card & IBAN',
    'notes': 'Notes / Terms',
    'pending': 'Pending',
    'success': 'Success',
    'failed': 'Failed',
  };

  static String t(String key) => en[key] ?? key;
}
