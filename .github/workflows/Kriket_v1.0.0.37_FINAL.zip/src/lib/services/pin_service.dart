import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Local app PIN (4 or 6 digits). The PIN is stored in platform secure storage.
/// It is an app-unlock credential; Supabase session/authentication remains the
/// source of truth for the user's account.
class PinService {
  PinService._();
  static final PinService instance = PinService._();

  static const _kPin = 'kriket_app_pin';
  static const _kPinLength = 'kriket_app_pin_length';

  FlutterSecureStorage get _storage {
    if (kIsWeb) return const FlutterSecureStorage();
    return const FlutterSecureStorage(
      aOptions: AndroidOptions(encryptedSharedPreferences: true),
      iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
    );
  }

  Future<bool> isSet() async {
    try {
      final pin = await _storage.read(key: _kPin);
      return pin != null && (pin.length == 4 || pin.length == 6);
    } catch (_) {
      return false;
    }
  }

  Future<int> getLength() async {
    final value = await _storage.read(key: _kPinLength);
    final length = int.tryParse(value ?? '');
    return length == 4 || length == 6 ? length! : 6;
  }

  Future<void> setPin(String pin) async {
    if (pin.length != 4 && pin.length != 6 || !RegExp(r'^\d+$').hasMatch(pin)) {
      throw ArgumentError('PIN must contain exactly 4 or 6 digits.');
    }
    await _storage.write(key: _kPin, value: pin);
    await _storage.write(key: _kPinLength, value: pin.length.toString());
  }

  Future<bool> verify(String pin) async {
    final stored = await _storage.read(key: _kPin);
    return stored != null && stored == pin;
  }

  Future<void> clear() async {
    await _storage.delete(key: _kPin);
    await _storage.delete(key: _kPinLength);
  }
}
