
import 'kriket_financial_core.dart';

class KriketTransactionCenterService {
  final KriketFinancialCore core;
  KriketTransactionCenterService({KriketFinancialCore? core})
      : core = core ?? KriketFinancialCore.instance;

  Future<Map<String,dynamic>> savingsHistory() => core.savings(action:'history');
  Future<Map<String,dynamic>> transferStatus(String id) => core.transferStatus(id);
  Future<Map<String,dynamic>> transferSync(String id) => core.transferSync(id);
}
