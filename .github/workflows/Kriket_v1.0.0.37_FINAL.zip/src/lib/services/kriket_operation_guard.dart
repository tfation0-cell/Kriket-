/// Shared rules for money-moving operations. This is a client-side guard only;
/// authoritative authorization, limits, KYC and compliance checks belong on
/// the server/provider before a transaction is signed.
class KriketOperationGuard {
  static void validateAmount(double amount) {
    if (!amount.isFinite || amount <= 0) throw Exception('Invalid amount');
  }

  static void validateDestination(String value) {
    final v = value.trim();
    if (v.isEmpty || v.length < 8) throw Exception('Invalid destination');
  }

  static void validateAsset(String value) {
    if (value.trim().isEmpty) throw Exception('Asset required');
  }
}
