import 'dart:convert';
import 'package:http/http.dart' as http;
import '../supabase_service.dart';
import '../kriket_mfa_service.dart';

class KriketMorphoUsdcData {
  final double? apy;
  final double balance;
  final String vault;
  final String vaultName;
  final String? walletAddress;
  const KriketMorphoUsdcData({
    required this.apy,
    required this.balance,
    required this.vault,
    required this.vaultName,
    required this.walletAddress,
  });
}

class KriketMorphoUsdcApi {
  static String get _url =>
      SupabaseService.supabaseUrl + '/functions/v1/morpho-usdc-api';

  Map<String, String> _headers(String token) => {
        'Authorization': 'Bearer ' + token,
        'apikey': SupabaseService.supabaseAnonKey,
        'Content-Type': 'application/json',
      };

  Future<KriketMorphoUsdcData> getLive() async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.get(
      Uri.parse(_url),
      headers: _headers(session.accessToken),
    );
    final data = _decode(response);

    double? number(dynamic value) {

      if (value is num) return value.toDouble();
      return double.tryParse(value?.toString() ?? '');
    }

    // Prefer the live Morpho V2 realized APY endpoint. If the Edge Function
    // returns no APY, query Morpho directly so a stale function version cannot
    // leave the card stuck at "APY —".
    var liveData = data;
    if (number(data['apy']) == null) {
      try {
        final direct = await http.get(
          Uri.parse(
            'https://api.morpho.org/v1/vaults-v2/8453:'
            '0xbeef0e0834849aCC03f0089F01f4F1Eeb06873C9/apy-averages'
            '?lookback=six_hours',
          ),
          headers: {'Accept': 'application/json'},
        );
        if (direct.statusCode >= 200 && direct.statusCode < 300) {
          final decoded = jsonDecode(direct.body);
          if (decoded is Map) {
            final root = decoded['data'];
            if (root is Map && number(root['apy']) != null) {
              liveData = <String, dynamic>{
                ...data,
                'apy': root['apy'],
              };
            }
          }
        }
      } catch (_) {
        // Keep the Edge Function result if the direct fallback is unavailable.
      }
    }

    // Supabase financial_products is the app's catalog source of truth.
    // Read APY directly so the card is not dependent on the legacy
    // Morpho Edge Function APY field.
    double? catalogApy;
    try {
      final row = await SupabaseService.instance.client
          .from('financial_products')
          .select('apy')
          .eq('slug', 'usdc-savings')
          .eq('enabled', true)
          .maybeSingle();
      catalogApy = number(row?['apy']);
    } catch (_) {
      catalogApy = null;
    }
    final resolvedApy = number(liveData['apy']) ?? catalogApy;

    final position = data['position'];
    final p = position is Map
        ? Map<String, dynamic>.from(position)
        : <String, dynamic>{};
    final nested = p['state'] is Map
        ? Map<String, dynamic>.from(p['state'])
        : p;
    final balance = number(
          nested['assets'] ??
              nested['assetsUsd'] ??
              p['assets'] ??
              p['assetsUsd'],
        ) ??
        0;

    return KriketMorphoUsdcData(
      apy: resolvedApy,
      balance: balance,
      vault: data['vault']?.toString() ?? '',
      vaultName:
          data['vault_name']?.toString() ?? 'Steakhouse Prime Instant USDC',
      walletAddress: data['wallet_address']?.toString(),
    );
  }

  Future<Map<String, dynamic>> execute(String action, double amount) async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.post(
      Uri.parse(_url + '?action=' + Uri.encodeQueryComponent(action)),
      headers: _headers(session.accessToken),
      body: jsonEncode({'amount': amount}),
    );
    return _decode(response);
  }

  Future<String> sync(String transactionId) async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.post(
      Uri.parse(_url + '?action=sync'),
      headers: _headers(session.accessToken),
      body: jsonEncode({'transaction_id': transactionId}),
    );
    final data = _decode(response);
    final tx = data['transaction'];
    return tx is Map ? (tx['status']?.toString() ?? 'pending') : 'pending';
  }

  Map<String, dynamic> _decode(http.Response response) {
    final decoded = jsonDecode(response.body);
    final data = decoded is Map
        ? Map<String, dynamic>.from(decoded)
        : <String, dynamic>{};
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError(data['error']?.toString() ?? 'Morpho API error');
    }
    return data;
  }
}
