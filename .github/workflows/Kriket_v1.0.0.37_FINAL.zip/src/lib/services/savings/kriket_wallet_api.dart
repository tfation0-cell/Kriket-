import 'dart:convert';
import 'package:http/http.dart' as http;
import '../supabase_service.dart';

class KriketWallet {
  final String address;
  final String chainName;
  final int chainId;
  final String status;
  const KriketWallet({required this.address, required this.chainName, required this.chainId, required this.status});
}

class KriketWalletApi {
  static String get _url => SupabaseService.supabaseUrl + '/functions/v1/create-wallet';

  Future<KriketWallet> getOrCreateWallet() async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.post(Uri.parse(_url), headers: {
      'Authorization': 'Bearer ' + session.accessToken,
      'apikey': SupabaseService.supabaseAnonKey,
      'Content-Type': 'application/json',
    });
    final decoded = jsonDecode(response.body);
    final data = decoded is Map ? Map<String, dynamic>.from(decoded) : <String, dynamic>{};
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError(data['error']?.toString() ?? 'Wallet API error');
    }
    final raw = Map<String, dynamic>.from(data['wallet'] as Map);
    return KriketWallet(
      address: raw['wallet_address']?.toString() ?? '',
      chainName: raw['chain_name']?.toString() ?? 'Base',
      chainId: raw['chain_id'] is num ? (raw['chain_id'] as num).toInt() : 8453,
      status: raw['status']?.toString() ?? 'active',
    );
  }
}
