import 'dart:convert';
import 'package:http/http.dart' as http;

class AaveBaseReserve {
  final String symbol;
  final String address;
  final int decimals;
  final double supplyApy;
  final double borrowApy;
  final double liquidityUsd;
  final bool isFrozen;
  final bool isPaused;

  const AaveBaseReserve({
    required this.symbol,
    required this.address,
    required this.decimals,
    required this.supplyApy,
    required this.borrowApy,
    required this.liquidityUsd,
    required this.isFrozen,
    required this.isPaused,
  });

  bool get isActive => !isFrozen && !isPaused;
}

class AaveBaseApi {
  static const _endpoint = 'https://api.v3.aave.com/graphql';

  Future<List<AaveBaseReserve>> getReserves() async {
    const query = r'''
      query BaseReserves($chainIds: [Int!]!) {
        markets(request: { chainIds: $chainIds }) {
          reserves {
            underlyingToken { symbol address decimals }
            supplyInfo { apy { formatted } }
            borrowInfo {
              apy { formatted }
              availableLiquidity { amount { usd } }
            }
            isFrozen
            isPaused
          }
        }
      }
    ''';

    final response = await http.post(
      Uri.parse(_endpoint),
      headers: const {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: jsonEncode({
        'query': query,
        'variables': {'chainIds': [8453]},
      }),
    ).timeout(const Duration(seconds: 12));

    if (response.statusCode != 200) {
      throw Exception('Aave API HTTP ' + response.statusCode.toString());
    }

    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final errors = body['errors'];
    if (errors is List && errors.isNotEmpty) {
      throw Exception('Aave API returned an error');
    }

    final data = body['data'] as Map<String, dynamic>?;
    final markets = data?['markets'] as List<dynamic>?;
    if (markets == null || markets.isEmpty) return const [];

    final reserves = markets.first['reserves'] as List<dynamic>? ?? const [];
    return reserves.map((raw) {
      final r = raw as Map<String, dynamic>;
      final token = (r['underlyingToken'] as Map<String, dynamic>?) ?? const {};
      final supply = (r['supplyInfo'] as Map<String, dynamic>?) ?? const {};
      final borrow = (r['borrowInfo'] as Map<String, dynamic>?) ?? const {};
      final liquidity = (borrow['availableLiquidity'] as Map<String, dynamic>?) ?? const {};
      final amount = (liquidity['amount'] as Map<String, dynamic>?) ?? const {};

      double number(dynamic value) {
        if (value is num) return value.toDouble();
        return double.tryParse(value.toString()) ?? 0;
      }

      return AaveBaseReserve(
        symbol: token['symbol']?.toString() ?? '',
        address: token['address']?.toString() ?? '',
        decimals: (token['decimals'] as num?)?.toInt() ?? 0,
        supplyApy: number((supply['apy'] as Map<String, dynamic>?)?['formatted']),
        borrowApy: number((borrow['apy'] as Map<String, dynamic>?)?['formatted']),
        liquidityUsd: number(amount['usd']),
        isFrozen: r['isFrozen'] == true,
        isPaused: r['isPaused'] == true,
      );
    }).toList();
  }
}
