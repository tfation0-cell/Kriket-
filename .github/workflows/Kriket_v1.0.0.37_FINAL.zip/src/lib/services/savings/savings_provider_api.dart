/// Abstraction for future real savings-provider integrations.
///
/// Keep provider credentials on the server/backend, never inside the mobile app.
/// Implementations can later connect to Aave, Morpho, Spark and banking partners.
abstract class SavingsProviderApi {
  Future<List<SavingsRate>> getRates();

  Future<SavingsPosition?> getPosition(String userId);

  Future<String> createDeposit({
    required String userId,
    required String providerId,
    required double amount,
    required String asset,
  });

  Future<String> createWithdraw({
    required String userId,
    required String providerId,
    required double amount,
    required String asset,
  });
}

class SavingsRate {
  final String providerId;
  final String providerName;
  final String asset;
  final double apy;
  final DateTime updatedAt;

  const SavingsRate({
    required this.providerId,
    required this.providerName,
    required this.asset,
    required this.apy,
    required this.updatedAt,
  });
}

class SavingsPosition {
  final String providerId;
  final String asset;
  final double balance;
  final double apy;
  final DateTime updatedAt;

  const SavingsPosition({
    required this.providerId,
    required this.asset,
    required this.balance,
    required this.apy,
    required this.updatedAt,
  });
}
