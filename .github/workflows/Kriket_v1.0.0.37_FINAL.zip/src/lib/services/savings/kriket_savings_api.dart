import 'dart:convert';
import 'package:http/http.dart' as http;
import '../supabase_service.dart';

class KriketSavingsPosition {
  final double balance;
  final double accruedYield;
  final double apy;
  final String status;
  final double walletEurcBalance;
  final double walletEthBalance;

  const KriketSavingsPosition({
    required this.balance,
    required this.accruedYield,
    required this.apy,
    required this.status,
    required this.walletEurcBalance,
    required this.walletEthBalance,
  });
}

class KriketSavingsApi {
  static String get _url =>
      SupabaseService.supabaseUrl + '/functions/v1/savings-api';

  Map<String, String> _headers(String token) => {
        'Authorization': 'Bearer ' + token,
        'apikey': SupabaseService.supabaseAnonKey,
        'Content-Type': 'application/json',
      };

  Future<KriketSavingsPosition> getPosition() async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.get(
      Uri.parse(_url + '?action=position'),
      headers: _headers(session.accessToken),
    );
    final data = _decode(response);
    final raw = Map<String, dynamic>.from(data['savings'] as Map);
    double number(dynamic value) =>
        value is num ? value.toDouble() : double.tryParse(value.toString()) ?? 0;
    return KriketSavingsPosition(
      balance: number(raw['balance']),
      accruedYield: number(raw['accrued_yield']),
      apy: number(raw['apy']),
      status: raw['status']?.toString() ?? 'active',
      walletEurcBalance: number((data['wallet'] as Map?)?['eurc_balance']),
      walletEthBalance: number((data['wallet'] as Map?)?['base_eth_balance']),
    );
  }

  Future<List<Map<String, dynamic>>> getHistory() async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.get(Uri.parse(_url + '?action=history'), headers: _headers(session.accessToken));
    final data = _decode(response);
    final raw = (data['history'] as List? ?? const []);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> syncDetailed(String transactionId) async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.post(Uri.parse(_url + '?action=sync'), headers: _headers(session.accessToken), body: jsonEncode({'transaction_id': transactionId}));
    final data = _decode(response);
    return Map<String, dynamic>.from(data['transaction'] as Map);
  }

  Future<String> execute(String action, double amount) async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.post(
      Uri.parse(_url + '?action=' + action),
      headers: _headers(session.accessToken),
      body: jsonEncode({'amount': amount}),
    );
    final data = _decode(response);
    return data['transaction_id']?.toString() ?? (throw StateError('No transaction id returned'));
  }

  Future<String> sync(String transactionId) async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) throw StateError('Not signed in');
    final response = await http.post(
      Uri.parse(_url + '?action=sync'),
      headers: _headers(session.accessToken),
      body: jsonEncode({'transaction_id': transactionId}),
    );
    final data = _decode(response);
    final tx = Map<String, dynamic>.from(data['transaction'] as Map);
    return tx['status']?.toString() ?? 'pending';
  }

  Map<String, dynamic> _decode(http.Response response) {
    final decoded = jsonDecode(response.body);
    final data = decoded is Map
        ? Map<String, dynamic>.from(decoded)
        : <String, dynamic>{};
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError(data['error']?.toString() ?? 'Savings API error');
    }
    return data;
  }
}
