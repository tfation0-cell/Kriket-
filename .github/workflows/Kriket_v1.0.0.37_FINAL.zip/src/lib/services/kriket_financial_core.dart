import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_service.dart';

/// Shared financial API layer. Confirmed balances should be sourced from
/// blockchain/regulated partners; Supabase stores application state.
class KriketFinancialCore {
  static final KriketFinancialCore instance = KriketFinancialCore._();
  KriketFinancialCore._();

  String get _base => SupabaseService.supabaseUrl + '/functions/v1';

  Future<Map<String, dynamic>> _call(
    String functionName, {
    String method = 'GET',
    String? action,
    Map<String, dynamic>? body,
    Map<String, String>? query,
  }) async {
    final session = Supabase.instance.client.auth.currentSession;
    if (session == null) throw Exception('Session required');
    final params = <String, String>{};
    if (action != null) params['action'] = action;
    if (query != null) params.addAll(query);
    final uri = Uri.parse(_base + '/' + functionName).replace(
      queryParameters: params.isEmpty ? null : params,
    );
    final response = method == 'POST'
        ? await http.post(uri, headers: _headers(session.accessToken), body: jsonEncode(body ?? {}))
        : await http.get(uri, headers: _headers(session.accessToken));
    final decoded = response.body.isEmpty ? <String, dynamic>{} : jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception((decoded is Map ? decoded['error'] : null) ?? 'Financial operation failed');
    }
    return Map<String, dynamic>.from(decoded as Map);
  }

  Map<String, String> _headers(String token) => {
    'Authorization': 'Bearer ' + token,
    'apikey': SupabaseService.supabaseAnonKey,
    'Content-Type': 'application/json',
  };

  Future<Map<String, dynamic>> wallet() => _call('create-wallet', method: 'POST', body: {});
  Future<Map<String, dynamic>> savings({String action = 'position'}) =>
      _call('savings-api', action: action);

  Future<Map<String, dynamic>> savingsAction(String action, double amount) =>
      _call('savings-api', method: 'POST', action: action, body: {'amount': amount});

  Future<Map<String, dynamic>> transferStatus(String operationId) =>
      _call('transfer-api', action: 'status', query: {'id': operationId});

  Future<Map<String, dynamic>> transferSync(String operationId) =>
      _call('transfer-api', action: 'sync', query: {'id': operationId});

  Future<Map<String, dynamic>> transfer({
    required String destination,
    required double amount,
    String asset = 'EURC',
    String network = 'base',
  }) => _call('transfer-api', method: 'POST', action: 'create', body: {
        'destination': destination, 'amount': amount, 'asset': asset, 'network': network,
      });

  Future<Map<String, dynamic>> exchangeQuote({
    required String from, required String to, required double amount,
  }) => _call('exchange-api', method: 'POST', action: 'quote', body: {
        'from': from, 'to': to, 'amount': amount,
      });

  Future<Map<String, dynamic>> exchangeExecute({
    required String from, required String to, required double amount,
  }) => _call('exchange-api', method: 'POST', action: 'execute', body: {
        'from': from, 'to': to, 'amount': amount,
      });

  Future<Map<String, dynamic>> cardSummary() => _call('card-api', action: 'summary');

  Future<Map<String, dynamic>> cardAction(String action, {Map<String, dynamic>? body}) =>
      _call('card-api', method: 'POST', action: action, body: body);

  Future<Map<String, dynamic>> adminRisk() => _call('admin-risk-api', action: 'review');
}
