/// Features can be activated per market/partner without changing the wallet core.
class KriketFeatureFlags {
  static const wallet = true;
  static const savings = true;
  static const transfers = true;
  static const exchange = true;
  static const cards = true;
  static const investing = false;
  static const merchant = false;
  static const openFinance = false;
  static const aiFinance = false;
  static const cryptoTrading = false;
  static const identityKyc = true;
  static const notifications = true;
  static const fraudMonitoring = true;
  static const analytics = true;
  static const support = true;
  static const compliance = true;
}
