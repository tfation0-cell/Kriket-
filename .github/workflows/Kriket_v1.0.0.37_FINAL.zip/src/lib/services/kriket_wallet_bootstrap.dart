import 'dart:convert';
import 'package:http/http.dart' as http;
import 'supabase_service.dart';

class KriketWalletBootstrap {
  static bool _started = false;

  static Future<void> initialize() async {
    if (_started) return;
    _started = true;

    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) return;

    try {
      final response = await http.post(
        Uri.parse(SupabaseService.supabaseUrl + '/functions/v1/create-wallet'),
        headers: {
          'Authorization': 'Bearer ' + session.accessToken,
          'apikey': SupabaseService.supabaseAnonKey,
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode < 200 || response.statusCode >= 300) return;
      final decoded = jsonDecode(response.body);
      if (decoded is Map && decoded['wallet'] is Map) {
        // Wallet creation is persisted by the Supabase Edge Function.
        // No private key is returned or stored by the app.
      }
    } catch (_) {
      // Wallet creation is retried on the next authenticated app start.
    }
  }
}
