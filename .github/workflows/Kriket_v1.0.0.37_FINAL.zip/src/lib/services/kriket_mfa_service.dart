import 'package:supabase_flutter/supabase_flutter.dart';

class KriketMfaService {
  static final _auth = Supabase.instance.client.auth;

  static AuthenticatorAssuranceLevels? assuranceLevel() {
    return _auth.mfa.getAuthenticatorAssuranceLevel().currentLevel;
  }

  static Future<bool> isAal2() async =>
      assuranceLevel() == AuthenticatorAssuranceLevels.aal2;

  static Future<AuthMFAEnrollResponse> enroll() {
    return _auth.mfa.enroll(
      factorType: FactorType.totp,
      issuer: 'Kriket',
      friendlyName: 'Kriket Authenticator',
    );
  }

  static Future<void> verifyEnrollment({
    required String factorId,
    required String code,
  }) async {
    final challenge = await _auth.mfa.challenge(factorId: factorId);
    await _auth.mfa.verify(
      factorId: factorId,
      challengeId: challenge.id,
      code: code,
    );
  }

  static Future<List<Factor>> verifiedTotpFactors() async {
    final r = await _auth.mfa.listFactors();
    return r.totp.where((f) => f.status == FactorStatus.verified).toList();
  }

  static Future<void> verifyCode(String code) async {
    final factors = await verifiedTotpFactors();
    if (factors.isEmpty) throw const AuthException('No verified authenticator factor');
    final challenge = await _auth.mfa.challenge(factorId: factors.first.id);
    await _auth.mfa.verify(
      factorId: factors.first.id,
      challengeId: challenge.id,
      code: code,
    );
  }

  static Future<void> unenroll(String factorId) async {
    await _auth.mfa.unenroll(factorId);
  }
}
