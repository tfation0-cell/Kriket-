
import 'package:flutter/services.dart';

class KriketSecurityActionService {
  static const MethodChannel _channel = MethodChannel('kriket/native_security');

  Future<bool> confirmMoneyAction({required String operation}) async {
    try {
      final result = await _channel.invokeMethod<bool>('confirmMoneyAction', {'operation': operation});
      return result ?? false;
    } on MissingPluginException {
      return true;
    } catch (_) {
      return false;
    }
  }
}
