import 'package:flutter/services.dart';

class KriketNativeSecurityStatus {
  final bool keystoreAvailable;
  final bool debuggerAttached;
  final bool rootLikely;
  final bool emulatorLikely;
  final bool developerOptions;
  final String signatureSha256;

  const KriketNativeSecurityStatus({
    required this.keystoreAvailable,
    required this.debuggerAttached,
    required this.rootLikely,
    required this.emulatorLikely,
    required this.developerOptions,
    required this.signatureSha256,
  });

  factory KriketNativeSecurityStatus.fromMap(Map<dynamic, dynamic> map) {
    return KriketNativeSecurityStatus(
      keystoreAvailable: map['keystoreAvailable'] == true,
      debuggerAttached: map['debuggerAttached'] == true,
      rootLikely: map['rootLikely'] == true,
      emulatorLikely: map['emulatorLikely'] == true,
      developerOptions: map['developerOptions'] == true,
      signatureSha256: map['signatureSha256']?.toString() ?? '',
    );
  }
}

class KriketNativeSecurityService {
  static const MethodChannel _channel = MethodChannel('kriket/native_security');

  static Future<void> initialize() async {
    try {
      await _channel.invokeMethod<bool>('initializeSecureKey');
    } catch (_) {
      // Native security is defense-in-depth; never block normal app startup.
    }
  }

  static Future<KriketNativeSecurityStatus?> getStatus() async {
    try {
      final raw = await _channel.invokeMethod<dynamic>('getSecurityStatus');
      if (raw is Map) {
        return KriketNativeSecurityStatus.fromMap(raw);
      }
    } catch (_) {}
    return null;
  }

  static Future<String?> getInitialDeepLink() async {
    try {
      return await _channel.invokeMethod<String>('getInitialDeepLink');
    } catch (_) {
      return null;
    }
  }

  static Future<bool> isDeviceLocked() async {
    try {
      return await _channel.invokeMethod<bool>('isDeviceLocked') ?? false;
    } catch (_) {
      return false;
    }
  }
}
