/// Single registry for the Kriket financial platform. Provider-specific
/// execution is intentionally separated from the app so regulated partners
/// can be swapped without rewriting Wallet/Savings.
enum KriketModule {
  wallet, identityKyc, savings, transfers, cards, exchange, investing,
  stablecoins, merchant, openFinance, aiFinance, fraudMonitoring,
  notifications, analytics, support, compliance,
}

class KriketModuleRegistry {
  static const all = <KriketModule>[
    KriketModule.wallet,
    KriketModule.identityKyc,
    KriketModule.savings,
    KriketModule.transfers,
    KriketModule.cards,
    KriketModule.exchange,
    KriketModule.investing,
    KriketModule.stablecoins,
    KriketModule.merchant,
    KriketModule.openFinance,
    KriketModule.aiFinance,
    KriketModule.fraudMonitoring,
    KriketModule.notifications,
    KriketModule.analytics,
    KriketModule.support,
    KriketModule.compliance,
  ];
}
