import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

@pragma('vm:entry-point')
Future<void> kriketFirebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  await PushNotificationService.showBackgroundDataNotification(message);
}

class PushNotificationService {
  PushNotificationService._();
  static final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  static Timer? _retryTimer;
  static String? _token;
  static bool _initialized = false;

  static const AndroidNotificationChannel _channel =
      AndroidNotificationChannel(
    'kriket_notifications',
    'Kriket Notifications',
    description: 'Kriket account and transaction notifications',
    importance: Importance.high,
    playSound: true,
  );

  static Future<bool> _saveToken(String token) async {
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      if (user == null) return false;
      final existing = await client
          .from('push_tokens')
          .select('id')
          .eq('user_id', user.id)
          .eq('token', token)
          .maybeSingle();
      if (existing == null) {
        await client.from('push_tokens').insert({
          'user_id': user.id,
          'token': token,
          'platform': 'android',
          'is_active': true,
        });
      } else {
        await client.from('push_tokens').update({
          'is_active': true,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }).eq('id', existing['id']);
      }
      debugPrint('[FCM] Token saved to Supabase');
      return true;
    } catch (e) {
      debugPrint('[FCM] Token save failed: $e');
      return false;
    }
  }

  static void _startRetry() {
    _retryTimer?.cancel();
    _retryTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      final token = _token;
      if (token == null || token!.isEmpty) return;
      if (await _saveToken(token!)) timer.cancel();
    });
  }

  static Future<void> _ensureLocalNotificationsReady() async {
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@drawable/ic_stat_kriket'),
    );
    await _localNotifications.initialize(settings);
    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_channel);
  }

  static Future<void> showBackgroundDataNotification(RemoteMessage message) async {
    // FCM notification messages are displayed by Android automatically while
    // the app is in the background. Only show a local notification here for
    // data-only messages, avoiding duplicates.
    if (message.notification != null) return;
    final title = message.data['title']?.toString();
    final body = message.data['body']?.toString();
    if ((title == null || title.isEmpty) && (body == null || body.isEmpty)) return;
    if (!kIsWeb) {
      try {
        await FirebaseMessaging.instance.requestPermission(
          alert: true,
          badge: true,
          sound: true,
          provisional: false,
        );
      } catch (_) {}
    }

    await _ensureLocalNotificationsReady();
    await _localNotifications.show(
      message.hashCode,
      title ?? 'Kriket',
      body ?? '',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'kriket_notifications',
          'Kriket Notifications',
          channelDescription: 'Kriket account and transaction notifications',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@drawable/ic_stat_kriket',
          playSound: true,
        ),
      ),
      payload: message.data.toString(),
    );
  }

  static Future<void> _showForegroundNotification(RemoteMessage message) async {
    final notification = message.notification;
    final title = notification?.title ?? message.data['title']?.toString();
    final body = notification?.body ?? message.data['body']?.toString();
    if ((title == null || title.isEmpty) && (body == null || body.isEmpty)) return;

    await _localNotifications.show(
      message.hashCode,
      title ?? 'Kriket',
      body ?? '',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'kriket_notifications',
          'Kriket Notifications',
          channelDescription: 'Kriket account and transaction notifications',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@drawable/ic_stat_kriket',
        ),
      ),
      payload: message.data.toString(),
    );
  }

  static Future<void> initialize() async {
    if (kIsWeb || _initialized) return;
    _initialized = true;
    FirebaseMessaging.onBackgroundMessage(
      kriketFirebaseMessagingBackgroundHandler,
    );

    await _ensureLocalNotificationsReady();
    await _messaging.setAutoInitEnabled(true);

    final settingsResult = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );
    debugPrint('[FCM] Authorization: ${settingsResult.authorizationStatus}');

    final token = await _messaging.getToken();
    if (token != null && token.isNotEmpty) {
      _token = token;
      if (!await _saveToken(token)) _startRetry();
    }

    _messaging.onTokenRefresh.listen((newToken) async {
      _token = newToken;
      if (!await _saveToken(newToken)) _startRetry();
    });

    Supabase.instance.client.auth.onAuthStateChange.listen((data) async {
      if (data.event == AuthChangeEvent.signedIn ||
          data.event == AuthChangeEvent.tokenRefreshed ||
          data.event == AuthChangeEvent.userUpdated) {
        final currentToken = _token;
        if (currentToken != null && currentToken.isNotEmpty) {
          if (!await _saveToken(currentToken)) _startRetry();
        }
      }
    });

    FirebaseMessaging.onMessage.listen((message) async {
      debugPrint('[FCM] Foreground message: ${message.messageId}');
      await _showForegroundNotification(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      debugPrint('[FCM] Opened from notification: ${message.messageId}');
    });
  }
}
