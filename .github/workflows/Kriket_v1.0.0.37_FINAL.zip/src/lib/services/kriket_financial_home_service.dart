
import 'dart:async';
import 'kriket_financial_core.dart';

/// Unified read/sync layer for the main Account experience.
/// Money-moving actions still go through the server/provider APIs.
class KriketFinancialHomeService {
  final KriketFinancialCore core;
  KriketFinancialHomeService({KriketFinancialCore? core})
      : core = core ?? KriketFinancialCore.instance;

  Future<Map<String,dynamic>> wallet() => core.wallet();
  Future<Map<String,dynamic>> savings() => core.savings(action:'position');
  Future<Map<String,dynamic>> savingsHistory() => core.savings(action:'history');
  Future<Map<String,dynamic>> savingsSync() => core.savings(action:'sync');
  Future<Map<String,dynamic>> cardSummary() => core.cardSummary();

  Future<Map<String,dynamic>> refreshAll() async {
    final walletResult = await _safe('wallet', wallet);
    final savingsResult = await _safe('savings', savings);
    final cardResult = await _safe('card', cardSummary);

    final errors = <String, String>{};
    for (final entry in <String, dynamic>{
      'wallet': walletResult,
      'savings': savingsResult,
      'card': cardResult,
    }.entries) {
      if (entry.value is Map && entry.value['__error'] != null) {
        errors[entry.key] = entry.value['__error'].toString();
      }
    }

    return {
      'wallet': walletResult,
      'savings': savingsResult,
      'card': cardResult,
      'errors': errors,
      'refreshed_at': DateTime.now().toIso8601String(),
    };
  }

  Future<Map<String, dynamic>> _safe(
    String name,
    Future<Map<String, dynamic>> Function() call,
  ) async {
    try {
      return await call();
    } catch (e) {
      return {'__error': e.toString(), '__service': name};
    }
  }
}
