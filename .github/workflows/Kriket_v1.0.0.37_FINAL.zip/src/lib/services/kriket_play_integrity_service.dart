import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'supabase_service.dart';

class KriketPlayIntegrityService {
  static const MethodChannel _native = MethodChannel('kriket/native_security');
  static const String cloudProjectNumber =
      String.fromEnvironment('KRIKET_GOOGLE_CLOUD_PROJECT_NUMBER');

  static Future<bool> prepare() async {
    if (cloudProjectNumber.isEmpty) return false;
    try {
      return await _native.invokeMethod<bool>('preparePlayIntegrity', {
        'cloudProjectNumber': int.parse(cloudProjectNumber),
      }) ?? false;
    } catch (_) {
      return false;
    }
  }

  static String requestHash(String action, Map<String, dynamic> payload) {
    final canonical = jsonEncode({'action': action, 'payload': payload});
    return sha256.convert(utf8.encode(canonical)).toString();
  }

  static Future<String?> tokenFor(String action, Map<String, dynamic> payload) async {
    final hash = requestHash(action, payload);
    try {
      return await _native.invokeMethod<String>('requestPlayIntegrity', {
        'requestHash': hash,
      });
    } catch (_) {
      return null;
    }
  }

  static Future<bool> verifyWithServer({
    required String action,
    required Map<String, dynamic> payload,
  }) async {
    final session = SupabaseService.instance.client.auth.currentSession;
    if (session == null) return false;
    final token = await tokenFor(action, payload);
    if (token == null || token.isEmpty) return false;
    final response = await http.post(
      Uri.parse(SupabaseService.supabaseUrl + '/functions/v1/play-integrity'),
      headers: {
        'Authorization': 'Bearer ' + session.accessToken,
        'apikey': SupabaseService.supabaseAnonKey,
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'token': token,
        'request_hash': requestHash(action, payload),
        'action': action,
        'payload': payload,
      }),
    );
    return response.statusCode >= 200 && response.statusCode < 300;
  }
}
